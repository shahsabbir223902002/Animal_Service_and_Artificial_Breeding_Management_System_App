package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.util.DateUtils
import org.junit.Assert.assertEquals
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

  @Test
  fun `read string from context`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val appName = context.getString(R.string.app_name)
    assertEquals("Rabby Animals", appName)
  }

  @Test
  fun `verify ai date calculations`() {
    val aiDate = "2026-08-01"
    val checkDate = DateUtils.calculatePregnancyCheckDate(aiDate, 60)
    // 60 days after August 1 is September 30
    assertEquals("2026-09-30", checkDate)

    val calvingDate = DateUtils.calculateExpectedCalvingDate(aiDate, 280)
    assertEquals("2027-05-08", calvingDate)
  }
}
