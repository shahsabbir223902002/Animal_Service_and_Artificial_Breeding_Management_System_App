package com.example.data.database

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.sqlite.db.SupportSQLiteDatabase
import com.example.data.dao.*
import com.example.data.entity.*
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

@Database(
    entities = [
        OwnerEntity::class,
        AnimalEntity::class,
        TreatmentEntity::class,
        AIRecordEntity::class,
        VaccinationEntity::class,
        DewormingEntity::class,
        AppointmentEntity::class,
        ReminderEntity::class,
        ActivityLogEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun ownerDao(): OwnerDao
    abstract fun animalDao(): AnimalDao
    abstract fun treatmentDao(): TreatmentDao
    abstract fun aiRecordDao(): AIRecordDao
    abstract fun vaccinationDao(): VaccinationDao
    abstract fun dewormingDao(): DewormingDao
    abstract fun appointmentDao(): AppointmentDao
    abstract fun reminderDao(): ReminderDao
    abstract fun activityLogDao(): ActivityLogDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getDatabase(context: Context, scope: CoroutineScope): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "rabby_animals_database"
                )
                    .addCallback(DatabaseCallback(scope))
                    .build()
                INSTANCE = instance
                instance
            }
        }
    }

    private class DatabaseCallback(
        private val scope: CoroutineScope
    ) : RoomDatabase.Callback() {
        override fun onCreate(db: SupportSQLiteDatabase) {
            super.onCreate(db)
            INSTANCE?.let { database ->
                scope.launch(Dispatchers.IO) {
                    populateInitialData(database)
                }
            }
        }

        private suspend fun populateInitialData(db: AppDatabase) {
            // Seed sample owners
            val owner1Id = db.ownerDao().insertOwner(
                OwnerEntity(
                    ownerCode = "OWN-101",
                    name = "Abdul Karim",
                    phone = "01712-345678",
                    altPhone = "01811-223344",
                    address = "Near Amratali Bazar, Ward 3",
                    village = "Amratali",
                    unionName = "Amratali",
                    upazila = "Adarsha Sadar",
                    district = "Cumilla",
                    nid = "1985191234567890",
                    latitude = 23.4682,
                    longitude = 91.1735,
                    notes = "Progressive dairy farmer, maintains 3 milking cows",
                    registrationDate = "2026-01-15"
                )
            )

            val owner2Id = db.ownerDao().insertOwner(
                OwnerEntity(
                    ownerCode = "OWN-102",
                    name = "Md. Rafiqul Islam",
                    phone = "01823-456789",
                    address = "Ramamala Road, Post Office Para",
                    village = "Ramamala",
                    unionName = "Amratali",
                    upazila = "Adarsha Sadar",
                    district = "Cumilla",
                    latitude = 23.4611,
                    longitude = 91.1824,
                    notes = "Goat rearing and small poultry",
                    registrationDate = "2026-02-10"
                )
            )

            val owner3Id = db.ownerDao().insertOwner(
                OwnerEntity(
                    ownerCode = "OWN-103",
                    name = "Abul Kashem Master",
                    phone = "01934-567890",
                    address = "Shimpur High School Para",
                    village = "Shimpur",
                    unionName = "Amratali",
                    upazila = "Adarsha Sadar",
                    district = "Cumilla",
                    latitude = 23.4750,
                    longitude = 91.1910,
                    notes = "Local retired teacher, has 2 high-yield Shahiwal cows",
                    registrationDate = "2026-03-01"
                )
            )

            val owner4Id = db.ownerDao().insertOwner(
                OwnerEntity(
                    ownerCode = "OWN-104",
                    name = "Jahangir Alam",
                    phone = "01745-678901",
                    address = "East Jagannathpur, canal side",
                    village = "Jagannathpur",
                    unionName = "Jagannathpur",
                    upazila = "Adarsha Sadar",
                    district = "Cumilla",
                    latitude = 23.4530,
                    longitude = 91.1980,
                    notes = "Buffalo dairy farm owner",
                    registrationDate = "2026-04-18"
                )
            )

            // Seed sample animals
            val animal1Id = db.animalDao().insertAnimal(
                AnimalEntity(
                    tagNumber = "COW-023",
                    name = "Rani (রাণী)",
                    species = "Cow",
                    breed = "Friesian Cross 75%",
                    gender = "Female",
                    birthDate = "2023-04-12",
                    age = "3.5 Years",
                    color = "Black & White (সাদা-কালো)",
                    weight = "320 kg",
                    ownerId = owner1Id,
                    ownerName = "Abdul Karim",
                    healthStatus = "Under Treatment",
                    pregnancyStatus = "Suspected Pregnant",
                    notes = "High-milk production cow, 14 L/day"
                )
            )

            val animal2Id = db.animalDao().insertAnimal(
                AnimalEntity(
                    tagNumber = "COW-045",
                    name = "Lalbahadur (লালবাহাদুর)",
                    species = "Cow",
                    breed = "Red Chittagong (RCC)",
                    gender = "Male",
                    birthDate = "2024-06-10",
                    age = "2 Years",
                    color = "Deep Red (গাঢ় লাল)",
                    weight = "260 kg",
                    ownerId = owner1Id,
                    ownerName = "Abdul Karim",
                    healthStatus = "Healthy",
                    pregnancyStatus = "Not Pregnant",
                    notes = "Indigenous quality bull calf"
                )
            )

            val animal3Id = db.animalDao().insertAnimal(
                AnimalEntity(
                    tagNumber = "GOAT-012",
                    name = "Tuni (টুনি)",
                    species = "Goat",
                    breed = "Black Bengal",
                    gender = "Female",
                    birthDate = "2025-02-14",
                    age = "1.5 Years",
                    color = "Pure Black",
                    weight = "22 kg",
                    ownerId = owner2Id,
                    ownerName = "Md. Rafiqul Islam",
                    healthStatus = "Under Treatment",
                    pregnancyStatus = "Not Pregnant",
                    notes = "Very active, fast grower"
                )
            )

            val animal4Id = db.animalDao().insertAnimal(
                AnimalEntity(
                    tagNumber = "COW-109",
                    name = "Manik (মানিক)",
                    species = "Cow",
                    breed = "Shahiwal 50%",
                    gender = "Female",
                    birthDate = "2022-09-05",
                    age = "4 Years",
                    color = "Brownish Grey",
                    weight = "380 kg",
                    ownerId = owner3Id,
                    ownerName = "Abul Kashem Master",
                    healthStatus = "Healthy",
                    pregnancyStatus = "Confirmed Pregnant",
                    notes = "Docile temperament, confirmed 2.5 months pregnant"
                )
            )

            val animal5Id = db.animalDao().insertAnimal(
                AnimalEntity(
                    tagNumber = "BUFF-004",
                    name = "Kalu (কালু)",
                    species = "Buffalo",
                    breed = "Murrah Cross",
                    gender = "Female",
                    birthDate = "2021-11-20",
                    age = "5 Years",
                    color = "Black",
                    weight = "460 kg",
                    ownerId = owner4Id,
                    ownerName = "Jahangir Alam",
                    healthStatus = "Healthy",
                    pregnancyStatus = "Not Pregnant",
                    notes = "Good fat percentage milk"
                )
            )

            // Seed treatments across months (August, September, October 2026)
            db.treatmentDao().insertTreatment(
                TreatmentEntity(
                    visitCode = "VIS-2026-081",
                    date = "2026-10-02",
                    time = "09:30 AM",
                    ownerId = owner1Id,
                    ownerName = "Abdul Karim",
                    ownerPhone = "01712-345678",
                    ownerAddress = "Near Amratali Bazar, Ward 3",
                    village = "Amratali",
                    animalId = animal1Id,
                    animalTag = "COW-023",
                    animalName = "Rani (রাণী)",
                    species = "Cow",
                    breed = "Friesian Cross 75%",
                    problem = "Loss of appetite & mild ruminal bloat (খাবার অরুচি ও পেট ফাঁপা)",
                    symptoms = "Off-feed since morning, mild left flank distension, sluggish ruminal motility",
                    examination = "Body temperature 101.8°F (normal), ruminal contractions 1 per 2 mins",
                    diagnosis = "Simple Indigestion with acute ruminal hypomotility",
                    treatment = "Oral carminative & stomachic bolus with antacid buffer",
                    medicineInfo = "1. Digevet Bolus - 2 bolus twice daily for 3 days\n2. Zimvet powder - 1 sachet in warm water\n3. Vitamin B-complex injection 10ml IM",
                    advice = "Provide succulent green grass in small amounts. Avoid excess mustard oil cake or stale mash for 3 days.",
                    followUpDate = "2026-10-05",
                    technicianName = "Md. Shah Walimullah Rabby",
                    isFollowUpCompleted = false
                )
            )

            db.treatmentDao().insertTreatment(
                TreatmentEntity(
                    visitCode = "VIS-2026-077",
                    date = "2026-09-28",
                    time = "11:15 AM",
                    ownerId = owner2Id,
                    ownerName = "Md. Rafiqul Islam",
                    ownerPhone = "01823-456789",
                    ownerAddress = "Ramamala Road, Post Office Para",
                    village = "Ramamala",
                    animalId = animal3Id,
                    animalTag = "GOAT-012",
                    animalName = "Tuni (টুনি)",
                    species = "Goat",
                    breed = "Black Bengal",
                    problem = "Nasal discharge & occasional coughing (সর্দি ও কাশি)",
                    symptoms = "Mild pyrexia (103.5°F), serous nasal exudate",
                    examination = "Lungs clear on auscultation, lymph nodes not swollen",
                    diagnosis = "Upper respiratory tract infection (ঋতু পরিবর্তনজনিত ঠাণ্ডা)",
                    treatment = "Antihistaminic & supportive antipyretic",
                    medicineInfo = "1. Astavet injection 1ml IM\n2. Paracetamol vet tab 1/2 tab BID\n3. Warm clean shelter at night",
                    advice = "Keep goat warm at night on wooden slatted floor. Ensure dry bedding.",
                    followUpDate = "2026-10-03",
                    technicianName = "Md. Shah Walimullah Rabby",
                    isFollowUpCompleted = false
                )
            )

            db.treatmentDao().insertTreatment(
                TreatmentEntity(
                    visitCode = "VIS-2026-064",
                    date = "2026-09-15",
                    time = "03:45 PM",
                    ownerId = owner3Id,
                    ownerName = "Abul Kashem Master",
                    ownerPhone = "01934-567890",
                    ownerAddress = "Shimpur High School Para",
                    village = "Shimpur",
                    animalId = animal4Id,
                    animalTag = "COW-109",
                    animalName = "Manik (মানিক)",
                    species = "Cow",
                    breed = "Shahiwal 50%",
                    problem = "Pregnancy check & mineral deficiency check",
                    symptoms = "Calm, healthy appetite, licking walls occasionally",
                    examination = "Per-rectal examination reveals asymmetric uterine horn, fetal membrane slip positive (60-day pregnancy confirmed)",
                    diagnosis = "Healthy early gestation (গর্ভাবস্থা নিশ্চিত)",
                    treatment = "Mineral mixture supplement & Vitamin AD3E",
                    medicineInfo = "1. Rena-Cal-P powder 50g daily in feed\n2. Inj. Vital E-Selenium 10ml IM",
                    advice = "Maintain balanced diet, provide ad libitum clean drinking water.",
                    followUpDate = "2026-10-20",
                    technicianName = "Md. Shah Walimullah Rabby",
                    isFollowUpCompleted = true
                )
            )

            db.treatmentDao().insertTreatment(
                TreatmentEntity(
                    visitCode = "VIS-2026-042",
                    date = "2026-08-22",
                    time = "10:00 AM",
                    ownerId = owner1Id,
                    ownerName = "Abdul Karim",
                    ownerPhone = "01712-345678",
                    ownerAddress = "Near Amratali Bazar, Ward 3",
                    village = "Amratali",
                    animalId = animal2Id,
                    animalTag = "COW-045",
                    animalName = "Lalbahadur (লালবাহাদুর)",
                    species = "Cow",
                    breed = "Red Chittagong (RCC)",
                    problem = "Right hoof minor cut & limping",
                    symptoms = "Superficial cut on interdigital space, mild tenderness",
                    examination = "Clean wound, no maggot infestation",
                    diagnosis = "Mechanical interdigital abrasion",
                    treatment = "Antiseptic cleaning with Povidone iodine + fly repellent aerosol",
                    medicineInfo = "Povidone iodine 10% wash + Vet Aerosol spray",
                    advice = "Keep animal in dry yard for 2 days.",
                    followUpDate = "2026-08-26",
                    technicianName = "Md. Shah Walimullah Rabby",
                    isFollowUpCompleted = true
                )
            )

            db.treatmentDao().insertTreatment(
                TreatmentEntity(
                    visitCode = "VIS-2026-035",
                    date = "2026-08-10",
                    time = "04:30 PM",
                    ownerId = owner4Id,
                    ownerName = "Jahangir Alam",
                    ownerPhone = "01745-678901",
                    ownerAddress = "East Jagannathpur",
                    village = "Jagannathpur",
                    animalId = animal5Id,
                    animalTag = "BUFF-004",
                    animalName = "Kalu (কালু)",
                    species = "Buffalo",
                    breed = "Murrah Cross",
                    problem = "Deworming & liver tonic administration",
                    symptoms = "Rough hair coat, sub-optimal weight gain",
                    examination = "Mucous membrane slightly pale",
                    diagnosis = "Gastrointestinal helminthiasis",
                    treatment = "Broad spectrum anthelmintic bolus + Liver extract",
                    medicineInfo = "1. Albendazole 2.5g bolus oral single dose\n2. Hepavet syrup 50ml daily for 7 days",
                    advice = "Repeat deworming every 3 months.",
                    followUpDate = "2026-08-17",
                    technicianName = "Md. Shah Walimullah Rabby",
                    isFollowUpCompleted = true
                )
            )

            // Seed AI Records
            db.aiRecordDao().insertAIRecord(
                AIRecordEntity(
                    aiCode = "AI-2026-104",
                    ownerId = owner1Id,
                    ownerName = "Abdul Karim",
                    animalId = animal1Id,
                    animalTag = "COW-023",
                    aiDate = "2026-08-01",
                    heatDetectionDate = "2026-07-31",
                    breed = "100% Holstein Friesian",
                    semenBullInfo = "Bull #FR-402, CCBD Central Bull Station (Rajabari)",
                    technicianName = "Md. Shah Walimullah Rabby",
                    notes = "Clear standing heat, good cervical mucus, deep cervical deposition",
                    expectedPregnancyCheckDate = "2026-10-01",
                    pregnancyCheckResult = "Pending",
                    expectedCalvingDate = "2027-05-08",
                    followUpDate = "2026-10-02",
                    status = "Pregnancy Check Pending"
                )
            )

            db.aiRecordDao().insertAIRecord(
                AIRecordEntity(
                    aiCode = "AI-2026-092",
                    ownerId = owner3Id,
                    ownerName = "Abul Kashem Master",
                    animalId = animal4Id,
                    animalTag = "COW-109",
                    aiDate = "2026-07-15",
                    heatDetectionDate = "2026-07-14",
                    breed = "50% Shahiwal",
                    semenBullInfo = "Bull #SH-108, Central AI Station Savar",
                    technicianName = "Md. Shah Walimullah Rabby",
                    notes = "Natural estrus, second service, conception confirmed",
                    expectedPregnancyCheckDate = "2026-09-15",
                    pregnancyCheckResult = "Pregnant",
                    pregnancyCheckDate = "2026-09-15",
                    expectedCalvingDate = "2027-04-21",
                    followUpDate = "2026-10-20",
                    status = "Pregnant"
                )
            )

            db.aiRecordDao().insertAIRecord(
                AIRecordEntity(
                    aiCode = "AI-2026-118",
                    ownerId = owner1Id,
                    ownerName = "Abdul Karim",
                    animalId = animal2Id,
                    animalTag = "COW-045",
                    aiDate = "2026-09-20",
                    heatDetectionDate = "2026-09-19",
                    breed = "100% Holstein Friesian",
                    semenBullInfo = "Bull #FR-610, CCBD Bull Station",
                    technicianName = "Md. Shah Walimullah Rabby",
                    notes = "Excellent heat signs, inseminated mid-morning",
                    expectedPregnancyCheckDate = "2026-11-20",
                    pregnancyCheckResult = "Pending",
                    expectedCalvingDate = "2027-06-27",
                    followUpDate = "2026-11-20",
                    status = "AI Completed"
                )
            )

            // Seed Vaccinations
            db.vaccinationDao().insertVaccination(
                VaccinationEntity(
                    animalId = animal1Id,
                    animalTag = "COW-023",
                    ownerId = owner1Id,
                    ownerName = "Abdul Karim",
                    vaccineName = "FMD (ক্ষুরারোগ ভ্যাকসিন)",
                    dateGiven = "2026-05-10",
                    nextDueDate = "2026-11-10",
                    doseInfo = "3ml Subcutaneous",
                    notes = "Government subsidized campaign vaccine"
                )
            )

            db.vaccinationDao().insertVaccination(
                VaccinationEntity(
                    animalId = animal3Id,
                    animalTag = "GOAT-012",
                    ownerId = owner2Id,
                    ownerName = "Md. Rafiqul Islam",
                    vaccineName = "PPR Vaccine (ছাগলের পি.পি.আর)",
                    dateGiven = "2026-04-12",
                    nextDueDate = "2027-04-12",
                    doseInfo = "1ml Subcutaneous",
                    notes = "Annual immunity provided"
                )
            )

            db.vaccinationDao().insertVaccination(
                VaccinationEntity(
                    animalId = animal4Id,
                    animalTag = "COW-109",
                    ownerId = owner3Id,
                    ownerName = "Abul Kashem Master",
                    vaccineName = "Anthrax (তড়কা ভ্যাকসিন)",
                    dateGiven = "2026-06-01",
                    nextDueDate = "2027-06-01",
                    doseInfo = "1ml Subcutaneous",
                    notes = "Pre-monsoon booster"
                )
            )

            // Seed Dewormings
            db.dewormingDao().insertDeworming(
                DewormingEntity(
                    animalId = animal1Id,
                    animalTag = "COW-023",
                    ownerId = owner1Id,
                    ownerName = "Abdul Karim",
                    productName = "Triclabendazole + Levamisole (Endex-Vet)",
                    doseInfo = "1 Bolus per 150kg",
                    dateGiven = "2026-07-10",
                    nextDueDate = "2026-10-10",
                    notes = "Liver fluke & roundworm broad spectrum"
                )
            )

            // Seed Appointments
            db.appointmentDao().insertAppointment(
                AppointmentEntity(
                    date = "2026-10-02",
                    time = "11:30 AM",
                    ownerId = owner1Id,
                    ownerName = "Abdul Karim",
                    animalId = animal1Id,
                    animalTag = "COW-023",
                    phone = "01712-345678",
                    location = "Amratali Bazar yard",
                    reason = "AI inquiry for newly purchased heifer",
                    status = "Confirmed"
                )
            )

            db.appointmentDao().insertAppointment(
                AppointmentEntity(
                    date = "2026-10-03",
                    time = "09:00 AM",
                    ownerId = owner2Id,
                    ownerName = "Md. Rafiqul Islam",
                    animalId = animal3Id,
                    animalTag = "GOAT-012",
                    phone = "01823-456789",
                    location = "Ramamala Road",
                    reason = "Cold and cough recovery re-evaluation",
                    status = "Pending"
                )
            )

            // Seed Reminders
            db.reminderDao().insertReminder(
                ReminderEntity(
                    title = "Pregnancy check is due today for Cow-023",
                    description = "60-day per-rectal check due for Abdul Karim's Friesian cow (AI Date: 2026-08-01)",
                    dueDate = "2026-10-02",
                    category = "Pregnancy Check",
                    targetOwnerName = "Abdul Karim",
                    targetAnimalTag = "COW-023",
                    priority = "High"
                )
            )

            db.reminderDao().insertReminder(
                ReminderEntity(
                    title = "Follow-up visit for Md. Rafiqul Islam (Goat Tuni)",
                    description = "Check response to Astavet and antipyretic for respiratory infection",
                    dueDate = "2026-10-03",
                    category = "Treatment Follow-up",
                    targetOwnerName = "Md. Rafiqul Islam",
                    targetAnimalTag = "GOAT-012",
                    priority = "Normal"
                )
            )

            db.reminderDao().insertReminder(
                ReminderEntity(
                    title = "Deworming due for Cow COW-023",
                    description = "Quarterly deworming cycle due for Abdul Karim's cow",
                    dueDate = "2026-10-10",
                    category = "Deworming",
                    targetOwnerName = "Abdul Karim",
                    targetAnimalTag = "COW-023",
                    priority = "Normal"
                )
            )

            // Seed Activity Logs
            db.activityLogDao().insertLog(
                ActivityLogEntity(
                    title = "New visit recorded",
                    description = "Recorded treatment visit for Abdul Karim's Cow COW-023",
                    category = "Treatment"
                )
            )
            db.activityLogDao().insertLog(
                ActivityLogEntity(
                    title = "AI Record created",
                    description = "Completed AI service for Cow COW-045 with Bull #FR-610",
                    category = "AI"
                )
            )
            db.activityLogDao().insertLog(
                ActivityLogEntity(
                    title = "Pregnancy confirmed",
                    description = "Pregnancy confirmed for Abul Kashem's Cow COW-109 (Expected Calving: April 2027)",
                    category = "Pregnancy"
                )
            )
        }
    }
}
