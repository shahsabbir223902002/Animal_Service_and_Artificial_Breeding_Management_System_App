package com.example.data.dao

import androidx.room.*
import com.example.data.entity.*
import kotlinx.coroutines.flow.Flow

@Dao
interface OwnerDao {
    @Query("SELECT * FROM owners ORDER BY id DESC")
    fun getAllOwners(): Flow<List<OwnerEntity>>

    @Query("SELECT * FROM owners WHERE id = :id LIMIT 1")
    suspend fun getOwnerById(id: Long): OwnerEntity?

    @Query("SELECT * FROM owners WHERE name LIKE '%' || :query || '%' OR phone LIKE '%' || :query || '%' OR ownerCode LIKE '%' || :query || '%' OR village LIKE '%' || :query || '%' ORDER BY id DESC")
    fun searchOwners(query: String): Flow<List<OwnerEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOwner(owner: OwnerEntity): Long

    @Update
    suspend fun updateOwner(owner: OwnerEntity)

    @Delete
    suspend fun deleteOwner(owner: OwnerEntity)

    @Query("SELECT COUNT(*) FROM owners")
    fun getOwnerCount(): Flow<Int>
}

@Dao
interface AnimalDao {
    @Query("SELECT * FROM animals ORDER BY id DESC")
    fun getAllAnimals(): Flow<List<AnimalEntity>>

    @Query("SELECT * FROM animals WHERE id = :id LIMIT 1")
    suspend fun getAnimalById(id: Long): AnimalEntity?

    @Query("SELECT * FROM animals WHERE ownerId = :ownerId ORDER BY id DESC")
    fun getAnimalsByOwner(ownerId: Long): Flow<List<AnimalEntity>>

    @Query("SELECT * FROM animals WHERE tagNumber LIKE '%' || :query || '%' OR name LIKE '%' || :query || '%' OR breed LIKE '%' || :query || '%' OR ownerName LIKE '%' || :query || '%' ORDER BY id DESC")
    fun searchAnimals(query: String): Flow<List<AnimalEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAnimal(animal: AnimalEntity): Long

    @Update
    suspend fun updateAnimal(animal: AnimalEntity)

    @Delete
    suspend fun deleteAnimal(animal: AnimalEntity)

    @Query("SELECT COUNT(*) FROM animals")
    fun getAnimalCount(): Flow<Int>

    @Query("SELECT COUNT(*) FROM animals WHERE species = :species")
    fun getAnimalCountBySpecies(species: String): Flow<Int>
}

@Dao
interface TreatmentDao {
    @Query("SELECT * FROM treatments ORDER BY date DESC, id DESC")
    fun getAllTreatments(): Flow<List<TreatmentEntity>>

    @Query("SELECT * FROM treatments WHERE id = :id LIMIT 1")
    suspend fun getTreatmentById(id: Long): TreatmentEntity?

    @Query("SELECT * FROM treatments WHERE animalId = :animalId ORDER BY date DESC, id DESC")
    fun getTreatmentsByAnimal(animalId: Long): Flow<List<TreatmentEntity>>

    @Query("SELECT * FROM treatments WHERE ownerId = :ownerId ORDER BY date DESC, id DESC")
    fun getTreatmentsByOwner(ownerId: Long): Flow<List<TreatmentEntity>>

    @Query("SELECT * FROM treatments WHERE date BETWEEN :startDate AND :endDate ORDER BY date DESC, id DESC")
    fun getTreatmentsBetweenDates(startDate: String, endDate: String): Flow<List<TreatmentEntity>>

    @Query("SELECT * FROM treatments WHERE date = :todayDate ORDER BY id DESC")
    fun getTreatmentsForDate(todayDate: String): Flow<List<TreatmentEntity>>

    @Query("SELECT * FROM treatments WHERE ownerName LIKE '%' || :query || '%' OR ownerPhone LIKE '%' || :query || '%' OR animalTag LIKE '%' || :query || '%' OR animalName LIKE '%' || :query || '%' OR village LIKE '%' || :query || '%' OR visitCode LIKE '%' || :query || '%' OR problem LIKE '%' || :query || '%' ORDER BY date DESC")
    fun searchTreatments(query: String): Flow<List<TreatmentEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTreatment(treatment: TreatmentEntity): Long

    @Update
    suspend fun updateTreatment(treatment: TreatmentEntity)

    @Delete
    suspend fun deleteTreatment(treatment: TreatmentEntity)

    @Query("SELECT COUNT(*) FROM treatments")
    fun getTreatmentCount(): Flow<Int>

    @Query("SELECT COUNT(*) FROM treatments WHERE date = :todayDate")
    fun getTodayTreatmentCount(todayDate: String): Flow<Int>

    @Query("SELECT COUNT(*) FROM treatments WHERE isFollowUpCompleted = 0 AND followUpDate != ''")
    fun getPendingFollowUpCount(): Flow<Int>

    @Query("UPDATE treatments SET isFollowUpCompleted = :isCompleted WHERE id = :id")
    suspend fun setFollowUpCompleted(id: Long, isCompleted: Boolean)
}

@Dao
interface AIRecordDao {
    @Query("SELECT * FROM ai_records ORDER BY aiDate DESC, id DESC")
    fun getAllAIRecords(): Flow<List<AIRecordEntity>>

    @Query("SELECT * FROM ai_records WHERE id = :id LIMIT 1")
    suspend fun getAIRecordById(id: Long): AIRecordEntity?

    @Query("SELECT * FROM ai_records WHERE animalId = :animalId ORDER BY aiDate DESC, id DESC")
    fun getAIRecordsByAnimal(animalId: Long): Flow<List<AIRecordEntity>>

    @Query("SELECT * FROM ai_records WHERE ownerId = :ownerId ORDER BY aiDate DESC, id DESC")
    fun getAIRecordsByOwner(ownerId: Long): Flow<List<AIRecordEntity>>

    @Query("SELECT * FROM ai_records WHERE status = 'Pregnancy Check Pending' OR pregnancyCheckResult = 'Pending' ORDER BY expectedPregnancyCheckDate ASC")
    fun getPendingPregnancyChecks(): Flow<List<AIRecordEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAIRecord(record: AIRecordEntity): Long

    @Update
    suspend fun updateAIRecord(record: AIRecordEntity)

    @Delete
    suspend fun deleteAIRecord(record: AIRecordEntity)

    @Query("SELECT COUNT(*) FROM ai_records")
    fun getAICount(): Flow<Int>
}

@Dao
interface VaccinationDao {
    @Query("SELECT * FROM vaccinations ORDER BY dateGiven DESC, id DESC")
    fun getAllVaccinations(): Flow<List<VaccinationEntity>>

    @Query("SELECT * FROM vaccinations WHERE animalId = :animalId ORDER BY dateGiven DESC")
    fun getVaccinationsByAnimal(animalId: Long): Flow<List<VaccinationEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertVaccination(vaccination: VaccinationEntity): Long

    @Delete
    suspend fun deleteVaccination(vaccination: VaccinationEntity)

    @Query("SELECT COUNT(*) FROM vaccinations")
    fun getVaccinationCount(): Flow<Int>
}

@Dao
interface DewormingDao {
    @Query("SELECT * FROM dewormings ORDER BY dateGiven DESC, id DESC")
    fun getAllDewormings(): Flow<List<DewormingEntity>>

    @Query("SELECT * FROM dewormings WHERE animalId = :animalId ORDER BY dateGiven DESC")
    fun getDewormingsByAnimal(animalId: Long): Flow<List<DewormingEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertDeworming(deworming: DewormingEntity): Long

    @Delete
    suspend fun deleteDeworming(deworming: DewormingEntity)

    @Query("SELECT COUNT(*) FROM dewormings")
    fun getDewormingCount(): Flow<Int>
}

@Dao
interface AppointmentDao {
    @Query("SELECT * FROM appointments ORDER BY date ASC, time ASC")
    fun getAllAppointments(): Flow<List<AppointmentEntity>>

    @Query("SELECT * FROM appointments WHERE date = :todayDate ORDER BY time ASC")
    fun getTodayAppointments(todayDate: String): Flow<List<AppointmentEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAppointment(appointment: AppointmentEntity): Long

    @Update
    suspend fun updateAppointment(appointment: AppointmentEntity)

    @Delete
    suspend fun deleteAppointment(appointment: AppointmentEntity)

    @Query("SELECT COUNT(*) FROM appointments WHERE status = 'Pending'")
    fun getPendingAppointmentCount(): Flow<Int>
}

@Dao
interface ReminderDao {
    @Query("SELECT * FROM reminders ORDER BY isCompleted ASC, dueDate ASC")
    fun getAllReminders(): Flow<List<ReminderEntity>>

    @Query("SELECT * FROM reminders WHERE isCompleted = 0 ORDER BY dueDate ASC")
    fun getPendingReminders(): Flow<List<ReminderEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertReminder(reminder: ReminderEntity): Long

    @Query("UPDATE reminders SET isCompleted = :completed WHERE id = :id")
    suspend fun updateCompletion(id: Long, completed: Boolean)

    @Delete
    suspend fun deleteReminder(reminder: ReminderEntity)

    @Query("SELECT COUNT(*) FROM reminders WHERE isCompleted = 0")
    fun getPendingReminderCount(): Flow<Int>
}

@Dao
interface ActivityLogDao {
    @Query("SELECT * FROM activity_logs ORDER BY timestamp DESC LIMIT 30")
    fun getRecentLogs(): Flow<List<ActivityLogEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertLog(log: ActivityLogEntity)
}
