package com.example.data.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "owners")
data class OwnerEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val ownerCode: String,
    val name: String,
    val phone: String,
    val altPhone: String = "",
    val address: String = "",
    val village: String = "",
    val unionName: String = "Amratali",
    val upazila: String = "Adarsha Sadar",
    val district: String = "Cumilla",
    val nid: String = "",
    val latitude: Double = 23.4607,
    val longitude: Double = 91.1809,
    val notes: String = "",
    val registrationDate: String
)

@Entity(tableName = "animals")
data class AnimalEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val tagNumber: String,
    val name: String,
    val species: String, // Cow, Goat, Buffalo, Other
    val breed: String,
    val gender: String, // Female, Male
    val birthDate: String = "",
    val age: String,
    val color: String,
    val weight: String = "",
    val ownerId: Long,
    val ownerName: String,
    val photoUri: String = "",
    val healthStatus: String = "Healthy", // Healthy, Under Treatment, Recovered, Critical
    val pregnancyStatus: String = "Not Pregnant", // Not Pregnant, Suspected Pregnant, Confirmed Pregnant, Calved
    val notes: String = ""
)

@Entity(tableName = "treatments")
data class TreatmentEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val visitCode: String,
    val date: String, // yyyy-MM-dd
    val time: String,
    val ownerId: Long,
    val ownerName: String,
    val ownerPhone: String,
    val ownerAddress: String,
    val village: String,
    val animalId: Long,
    val animalTag: String,
    val animalName: String,
    val species: String,
    val breed: String,
    val problem: String,
    val symptoms: String,
    val examination: String = "",
    val diagnosis: String = "",
    val treatment: String,
    val medicineInfo: String,
    val advice: String = "",
    val followUpDate: String = "",
    val technicianName: String = "Md. Shah Walimullah Rabby",
    val isFollowUpCompleted: Boolean = false,
    val photoUri: String = "",
    val notes: String = ""
)

@Entity(tableName = "ai_records")
data class AIRecordEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val aiCode: String,
    val ownerId: Long,
    val ownerName: String,
    val animalId: Long,
    val animalTag: String,
    val aiDate: String, // yyyy-MM-dd
    val heatDetectionDate: String = "",
    val breed: String,
    val semenBullInfo: String,
    val technicianName: String = "Md. Shah Walimullah Rabby",
    val notes: String = "",
    val expectedPregnancyCheckDate: String = "",
    val pregnancyCheckResult: String = "Pending", // Pending, Pregnant, Not Pregnant
    val pregnancyCheckDate: String = "",
    val expectedCalvingDate: String = "",
    val actualCalvingDate: String = "",
    val followUpDate: String = "",
    val status: String = "AI Completed" // Scheduled, AI Completed, Pregnancy Check Pending, Pregnant, Not Pregnant, Follow-up Required, Completed
)

@Entity(tableName = "vaccinations")
data class VaccinationEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val animalId: Long,
    val animalTag: String,
    val ownerId: Long,
    val ownerName: String,
    val vaccineName: String,
    val dateGiven: String,
    val nextDueDate: String,
    val doseInfo: String = "",
    val notes: String = ""
)

@Entity(tableName = "dewormings")
data class DewormingEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val animalId: Long,
    val animalTag: String,
    val ownerId: Long,
    val ownerName: String,
    val productName: String,
    val doseInfo: String = "",
    val dateGiven: String,
    val nextDueDate: String,
    val notes: String = ""
)

@Entity(tableName = "appointments")
data class AppointmentEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val date: String,
    val time: String,
    val ownerId: Long,
    val ownerName: String,
    val animalId: Long = 0,
    val animalTag: String = "",
    val phone: String,
    val location: String,
    val reason: String,
    val notes: String = "",
    val status: String = "Pending" // Pending, Confirmed, Completed, Cancelled
)

@Entity(tableName = "reminders")
data class ReminderEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val title: String,
    val description: String,
    val dueDate: String,
    val category: String, // Treatment Follow-up, AI Follow-up, Pregnancy Check, Vaccination, Deworming, Appointment, Expected Calving
    val targetOwnerName: String = "",
    val targetAnimalTag: String = "",
    val referenceId: Long = 0,
    val isCompleted: Boolean = false,
    val priority: String = "Normal"
)

@Entity(tableName = "activity_logs")
data class ActivityLogEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val title: String,
    val description: String,
    val timestamp: Long = System.currentTimeMillis(),
    val category: String
)
