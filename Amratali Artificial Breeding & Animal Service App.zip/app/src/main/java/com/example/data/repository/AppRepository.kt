package com.example.data.repository

import android.content.Context
import android.content.SharedPreferences
import com.example.data.dao.*
import com.example.data.database.AppDatabase
import com.example.data.entity.*
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.withContext

enum class SyncState {
    SYNCED,
    SYNCING,
    OFFLINE,
    ERROR
}

class AppRepository(
    private val database: AppDatabase,
    private val context: Context
) {
    private val prefs: SharedPreferences =
        context.getSharedPreferences("rabby_app_prefs", Context.MODE_PRIVATE)

    private val _syncState = MutableStateFlow(SyncState.SYNCED)
    val syncState: StateFlow<SyncState> = _syncState.asStateFlow()

    // Authentication & Profile
    fun isLoggedIn(): Boolean = prefs.getBoolean("is_logged_in", true) // Default logged in for fast field use
    fun setLoggedIn(loggedIn: Boolean) = prefs.edit().putBoolean("is_logged_in", loggedIn).apply()

    fun getUserMobile(): String = prefs.getString("user_mobile", "01845-233917") ?: "01845-233917"
    fun getUserPin(): String = prefs.getString("user_pin", "1234") ?: "1234"
    fun setUserPin(pin: String) = prefs.edit().putString("user_pin", pin).apply()

    fun getFacebookUrl(): String = prefs.getString("facebook_url", "https://web.facebook.com/profile.php?id=100066460841802") ?: "https://web.facebook.com/profile.php?id=100066460841802"
    fun setFacebookUrl(url: String) = prefs.edit().putString("facebook_url", url).apply()

    fun getLanguage(): String = prefs.getString("app_language", "bn") ?: "bn" // Default Bengali/English bilingual
    fun setLanguage(lang: String) = prefs.edit().putString("app_language", lang).apply()

    // Owner Operations
    val allOwners: Flow<List<OwnerEntity>> = database.ownerDao().getAllOwners()
    fun searchOwners(query: String): Flow<List<OwnerEntity>> = database.ownerDao().searchOwners(query)
    suspend fun getOwnerById(id: Long): OwnerEntity? = database.ownerDao().getOwnerById(id)
    suspend fun insertOwner(owner: OwnerEntity): Long {
        val id = database.ownerDao().insertOwner(owner)
        logActivity("New owner registered", "${owner.name} (${owner.village}) added", "Owner")
        return id
    }
    suspend fun updateOwner(owner: OwnerEntity) = database.ownerDao().updateOwner(owner)
    suspend fun deleteOwner(owner: OwnerEntity) = database.ownerDao().deleteOwner(owner)
    val ownerCount: Flow<Int> = database.ownerDao().getOwnerCount()

    // Animal Operations
    val allAnimals: Flow<List<AnimalEntity>> = database.animalDao().getAllAnimals()
    fun getAnimalsByOwner(ownerId: Long): Flow<List<AnimalEntity>> = database.animalDao().getAnimalsByOwner(ownerId)
    fun searchAnimals(query: String): Flow<List<AnimalEntity>> = database.animalDao().searchAnimals(query)
    suspend fun getAnimalById(id: Long): AnimalEntity? = database.animalDao().getAnimalById(id)
    suspend fun insertAnimal(animal: AnimalEntity): Long {
        val id = database.animalDao().insertAnimal(animal)
        logActivity("New animal added", "${animal.species} ${animal.tagNumber} for ${animal.ownerName}", "Animal")
        return id
    }
    suspend fun updateAnimal(animal: AnimalEntity) = database.animalDao().updateAnimal(animal)
    suspend fun deleteAnimal(animal: AnimalEntity) = database.animalDao().deleteAnimal(animal)
    val animalCount: Flow<Int> = database.animalDao().getAnimalCount()

    // Treatment / Visit Operations
    val allTreatments: Flow<List<TreatmentEntity>> = database.treatmentDao().getAllTreatments()
    fun getTreatmentsByAnimal(animalId: Long): Flow<List<TreatmentEntity>> = database.treatmentDao().getTreatmentsByAnimal(animalId)
    fun getTreatmentsByOwner(ownerId: Long): Flow<List<TreatmentEntity>> = database.treatmentDao().getTreatmentsByOwner(ownerId)
    fun searchTreatments(query: String): Flow<List<TreatmentEntity>> = database.treatmentDao().searchTreatments(query)
    fun getTreatmentsBetweenDates(start: String, end: String): Flow<List<TreatmentEntity>> =
        database.treatmentDao().getTreatmentsBetweenDates(start, end)
    fun getTreatmentsForDate(date: String): Flow<List<TreatmentEntity>> =
        database.treatmentDao().getTreatmentsForDate(date)

    suspend fun getTreatmentById(id: Long): TreatmentEntity? = database.treatmentDao().getTreatmentById(id)
    suspend fun insertTreatment(treatment: TreatmentEntity): Long {
        val id = database.treatmentDao().insertTreatment(treatment)
        logActivity("Treatment visit saved", "${treatment.animalTag} (${treatment.ownerName}) - ${treatment.problem}", "Treatment")
        if (treatment.followUpDate.isNotBlank()) {
            database.reminderDao().insertReminder(
                ReminderEntity(
                    title = "Follow-up due for ${treatment.animalTag}",
                    description = "${treatment.ownerName}: ${treatment.problem}",
                    dueDate = treatment.followUpDate,
                    category = "Treatment Follow-up",
                    targetOwnerName = treatment.ownerName,
                    targetAnimalTag = treatment.animalTag,
                    referenceId = id
                )
            )
        }
        return id
    }
    suspend fun updateTreatment(treatment: TreatmentEntity) = database.treatmentDao().updateTreatment(treatment)
    suspend fun deleteTreatment(treatment: TreatmentEntity) = database.treatmentDao().deleteTreatment(treatment)
    suspend fun setFollowUpCompleted(id: Long, completed: Boolean) =
        database.treatmentDao().setFollowUpCompleted(id, completed)

    val treatmentCount: Flow<Int> = database.treatmentDao().getTreatmentCount()
    fun getTodayTreatmentCount(todayDate: String): Flow<Int> = database.treatmentDao().getTodayTreatmentCount(todayDate)
    val pendingFollowUpCount: Flow<Int> = database.treatmentDao().getPendingFollowUpCount()

    // AI Record Operations
    val allAIRecords: Flow<List<AIRecordEntity>> = database.aiRecordDao().getAllAIRecords()
    fun getAIRecordsByAnimal(animalId: Long): Flow<List<AIRecordEntity>> = database.aiRecordDao().getAIRecordsByAnimal(animalId)
    fun getAIRecordsByOwner(ownerId: Long): Flow<List<AIRecordEntity>> = database.aiRecordDao().getAIRecordsByOwner(ownerId)
    val pendingPregnancyChecks: Flow<List<AIRecordEntity>> = database.aiRecordDao().getPendingPregnancyChecks()
    suspend fun getAIRecordById(id: Long): AIRecordEntity? = database.aiRecordDao().getAIRecordById(id)
    suspend fun insertAIRecord(record: AIRecordEntity): Long {
        val id = database.aiRecordDao().insertAIRecord(record)
        logActivity("AI Service recorded", "${record.animalTag} inseminated with ${record.breed}", "AI")
        if (record.expectedPregnancyCheckDate.isNotBlank()) {
            database.reminderDao().insertReminder(
                ReminderEntity(
                    title = "Pregnancy check due for ${record.animalTag}",
                    description = "Insemination check for ${record.ownerName}",
                    dueDate = record.expectedPregnancyCheckDate,
                    category = "Pregnancy Check",
                    targetOwnerName = record.ownerName,
                    targetAnimalTag = record.animalTag,
                    referenceId = id,
                    priority = "High"
                )
            )
        }
        return id
    }
    suspend fun updateAIRecord(record: AIRecordEntity) = database.aiRecordDao().updateAIRecord(record)
    suspend fun deleteAIRecord(record: AIRecordEntity) = database.aiRecordDao().deleteAIRecord(record)
    val aiCount: Flow<Int> = database.aiRecordDao().getAICount()

    // Vaccinations & Dewormings
    val allVaccinations: Flow<List<VaccinationEntity>> = database.vaccinationDao().getAllVaccinations()
    fun getVaccinationsByAnimal(animalId: Long): Flow<List<VaccinationEntity>> = database.vaccinationDao().getVaccinationsByAnimal(animalId)
    suspend fun insertVaccination(v: VaccinationEntity): Long {
        val id = database.vaccinationDao().insertVaccination(v)
        logActivity("Vaccination recorded", "${v.vaccineName} for ${v.animalTag}", "Vaccination")
        if (v.nextDueDate.isNotBlank()) {
            database.reminderDao().insertReminder(
                ReminderEntity(
                    title = "Vaccination due: ${v.vaccineName}",
                    description = "Next dose for ${v.animalTag} (${v.ownerName})",
                    dueDate = v.nextDueDate,
                    category = "Vaccination",
                    targetOwnerName = v.ownerName,
                    targetAnimalTag = v.animalTag,
                    referenceId = id
                )
            )
        }
        return id
    }
    suspend fun deleteVaccination(v: VaccinationEntity) = database.vaccinationDao().deleteVaccination(v)
    val vaccinationCount: Flow<Int> = database.vaccinationDao().getVaccinationCount()

    val allDewormings: Flow<List<DewormingEntity>> = database.dewormingDao().getAllDewormings()
    fun getDewormingsByAnimal(animalId: Long): Flow<List<DewormingEntity>> = database.dewormingDao().getDewormingsByAnimal(animalId)
    suspend fun insertDeworming(d: DewormingEntity): Long {
        val id = database.dewormingDao().insertDeworming(d)
        logActivity("Deworming recorded", "${d.productName} for ${d.animalTag}", "Deworming")
        if (d.nextDueDate.isNotBlank()) {
            database.reminderDao().insertReminder(
                ReminderEntity(
                    title = "Deworming due for ${d.animalTag}",
                    description = "Repeat cycle for ${d.ownerName}",
                    dueDate = d.nextDueDate,
                    category = "Deworming",
                    targetOwnerName = d.ownerName,
                    targetAnimalTag = d.animalTag,
                    referenceId = id
                )
            )
        }
        return id
    }
    suspend fun deleteDeworming(d: DewormingEntity) = database.dewormingDao().deleteDeworming(d)
    val dewormingCount: Flow<Int> = database.dewormingDao().getDewormingCount()

    // Appointments
    val allAppointments: Flow<List<AppointmentEntity>> = database.appointmentDao().getAllAppointments()
    fun getTodayAppointments(today: String): Flow<List<AppointmentEntity>> = database.appointmentDao().getTodayAppointments(today)
    suspend fun insertAppointment(app: AppointmentEntity): Long {
        val id = database.appointmentDao().insertAppointment(app)
        logActivity("Appointment scheduled", "${app.ownerName} at ${app.time} (${app.reason})", "Appointment")
        return id
    }
    suspend fun updateAppointment(app: AppointmentEntity) = database.appointmentDao().updateAppointment(app)
    suspend fun deleteAppointment(app: AppointmentEntity) = database.appointmentDao().deleteAppointment(app)
    val pendingAppointmentCount: Flow<Int> = database.appointmentDao().getPendingAppointmentCount()

    // Reminders
    val allReminders: Flow<List<ReminderEntity>> = database.reminderDao().getAllReminders()
    val pendingReminders: Flow<List<ReminderEntity>> = database.reminderDao().getPendingReminders()
    suspend fun insertReminder(reminder: ReminderEntity): Long = database.reminderDao().insertReminder(reminder)
    suspend fun setReminderCompleted(id: Long, completed: Boolean) = database.reminderDao().updateCompletion(id, completed)
    suspend fun deleteReminder(reminder: ReminderEntity) = database.reminderDao().deleteReminder(reminder)
    val pendingReminderCount: Flow<Int> = database.reminderDao().getPendingReminderCount()

    // Activity Logs
    val recentLogs: Flow<List<ActivityLogEntity>> = database.activityLogDao().getRecentLogs()
    suspend fun logActivity(title: String, desc: String, category: String) {
        database.activityLogDao().insertLog(
            ActivityLogEntity(
                title = title,
                description = desc,
                category = category
            )
        )
    }

    // Cloud Sync simulation
    suspend fun triggerSync() = withContext(Dispatchers.IO) {
        _syncState.value = SyncState.SYNCING
        kotlinx.coroutines.delay(1200)
        _syncState.value = SyncState.SYNCED
    }
}
