package com.example.util

import java.text.SimpleDateFormat
import java.util.*

object DateUtils {
    private val isoFormat = SimpleDateFormat("yyyy-MM-dd", Locale.US)
    private val displayFormat = SimpleDateFormat("dd MMMM yyyy", Locale.US)
    private val monthYearFormat = SimpleDateFormat("MMMM yyyy", Locale.US)

    fun getTodayIso(): String = isoFormat.format(Date())

    fun getCurrentTime(): String {
        val timeFormat = SimpleDateFormat("hh:mm a", Locale.US)
        return timeFormat.format(Date())
    }

    fun formatDisplayDate(isoDate: String): String {
        return try {
            val date = isoFormat.parse(isoDate) ?: return isoDate
            displayFormat.format(date)
        } catch (e: Exception) {
            isoDate
        }
    }

    fun getMonthYear(isoDate: String): String {
        return try {
            val date = isoFormat.parse(isoDate) ?: return ""
            monthYearFormat.format(date)
        } catch (e: Exception) {
            ""
        }
    }

    fun addDaysToDate(isoDate: String, days: Int): String {
        return try {
            val date = isoFormat.parse(isoDate) ?: Date()
            val cal = Calendar.getInstance()
            cal.time = date
            cal.add(Calendar.DAY_OF_YEAR, days)
            isoFormat.format(cal.time)
        } catch (e: Exception) {
            isoDate
        }
    }

    // AI calculations:
    // Pregnancy check is typically ~60 to 90 days after AI (default 60 days)
    fun calculatePregnancyCheckDate(aiDateIso: String, days: Int = 60): String =
        addDaysToDate(aiDateIso, days)

    // Expected calving for cow is ~280-283 days after successful AI
    fun calculateExpectedCalvingDate(aiDateIso: String, days: Int = 280): String =
        addDaysToDate(aiDateIso, days)

    fun getStartOfMonth(monthOffset: Int = 0): String {
        val cal = Calendar.getInstance()
        cal.add(Calendar.MONTH, monthOffset)
        cal.set(Calendar.DAY_OF_MONTH, 1)
        return isoFormat.format(cal.time)
    }

    fun getEndOfMonth(monthOffset: Int = 0): String {
        val cal = Calendar.getInstance()
        cal.add(Calendar.MONTH, monthOffset)
        cal.set(Calendar.DAY_OF_MONTH, cal.getActualMaximum(Calendar.DAY_OF_MONTH))
        return isoFormat.format(cal.time)
    }

    fun getStartOfWeek(): String {
        val cal = Calendar.getInstance()
        cal.set(Calendar.DAY_OF_WEEK, cal.firstDayOfWeek)
        return isoFormat.format(cal.time)
    }

    fun getStartOfYear(): String {
        val cal = Calendar.getInstance()
        cal.set(Calendar.DAY_OF_YEAR, 1)
        return isoFormat.format(cal.time)
    }

    fun getMonthName(monthOffset: Int = 0): String {
        val cal = Calendar.getInstance()
        cal.add(Calendar.MONTH, monthOffset)
        return monthYearFormat.format(cal.time)
    }
}
