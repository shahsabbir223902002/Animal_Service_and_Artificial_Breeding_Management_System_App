package com.example.util

import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import android.net.Uri
import android.widget.Toast
import androidx.core.content.FileProvider
import com.example.data.entity.TreatmentEntity
import java.io.File
import java.io.FileOutputStream

object PdfReportGenerator {

    fun generateTreatmentReport(
        context: Context,
        treatments: List<TreatmentEntity>,
        reportTitle: String,
        periodName: String
    ): File? {
        val document = PdfDocument()
        val pageInfo = PdfDocument.PageInfo.Builder(595, 842, 1).create() // A4 dimensions in points (595 x 842)
        val page = document.startPage(pageInfo)
        val canvas = page.canvas

        val paint = Paint().apply {
            isAntiAlias = true
        }

        // Header Background
        paint.color = Color.parseColor("#1B5E20")
        canvas.drawRect(0f, 0f, 595f, 105f, paint)

        // Title text
        paint.color = Color.WHITE
        paint.textSize = 18f
        paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        canvas.drawText("RABBY ANIMALS OFFICIAL", 24f, 32f, paint)

        paint.textSize = 11f
        paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.NORMAL)
        canvas.drawText("Amratali Artificial Breeding Center | Upazila Veterinary Hospital", 24f, 50f, paint)
        canvas.drawText("Md. Shah Walimullah Rabby - Government AI Technician", 24f, 66f, paint)
        canvas.drawText("Mobile: 01845-233917 | Adarsha Sadar, Cumilla, Bangladesh", 24f, 82f, paint)

        // Report Subheader
        paint.color = Color.parseColor("#191C1A")
        paint.textSize = 15f
        paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        canvas.drawText(reportTitle, 24f, 130f, paint)

        paint.textSize = 10f
        paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.NORMAL)
        paint.color = Color.parseColor("#555555")
        canvas.drawText("Period: $periodName   |   Generated on: ${DateUtils.getTodayIso()}", 24f, 146f, paint)

        // Summary Statistics Box
        paint.color = Color.parseColor("#E8F5E9")
        canvas.drawRoundRect(24f, 160f, 571f, 215f, 8f, 8f, paint)

        val totalTreatments = treatments.size
        val totalOwners = treatments.map { it.ownerId }.distinct().size
        val cows = treatments.count { it.species.equals("Cow", ignoreCase = true) }
        val goats = treatments.count { it.species.equals("Goat", ignoreCase = true) }
        val buffalos = treatments.count { it.species.equals("Buffalo", ignoreCase = true) }
        val pendingFollowUps = treatments.count { !it.isFollowUpCompleted && it.followUpDate.isNotBlank() }

        paint.color = Color.parseColor("#1B5E20")
        paint.textSize = 11f
        paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        canvas.drawText("Summary: Total Visits: $totalTreatments  |  Owners Served: $totalOwners  |  Pending Follow-ups: $pendingFollowUps", 36f, 182f, paint)

        paint.color = Color.parseColor("#333333")
        paint.textSize = 10f
        paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.NORMAL)
        canvas.drawText("Species Breakdown -> Cows: $cows | Goats: $goats | Buffaloes: $buffalos | Others: ${totalTreatments - (cows + goats + buffalos)}", 36f, 200f, paint)

        // Table Header
        var yPos = 240f
        paint.color = Color.parseColor("#EEEEEE")
        canvas.drawRect(24f, yPos - 15f, 571f, yPos + 8f, paint)

        paint.color = Color.BLACK
        paint.textSize = 9f
        paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        canvas.drawText("Date", 30f, yPos, paint)
        canvas.drawText("Owner / Village", 95f, yPos, paint)
        canvas.drawText("Animal Tag", 215f, yPos, paint)
        canvas.drawText("Problem / Symptoms", 295f, yPos, paint)
        canvas.drawText("Treatment / Meds", 435f, yPos, paint)

        paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.NORMAL)
        paint.textSize = 8.5f
        yPos += 20f

        val linePaint = Paint().apply {
            color = Color.parseColor("#E0E0E0")
            strokeWidth = 1f
        }

        for (item in treatments.take(15)) {
            paint.color = Color.parseColor("#222222")
            canvas.drawText(item.date, 30f, yPos, paint)

            val ownerText = if (item.ownerName.length > 18) item.ownerName.take(17) + ".." else item.ownerName
            canvas.drawText("$ownerText (${item.village})", 95f, yPos, paint)

            canvas.drawText("${item.species}: ${item.animalTag}", 215f, yPos, paint)

            val problemText = if (item.problem.length > 24) item.problem.take(22) + ".." else item.problem
            canvas.drawText(problemText, 295f, yPos, paint)

            val treatmentText = if (item.treatment.length > 25) item.treatment.take(23) + ".." else item.treatment
            canvas.drawText(treatmentText, 435f, yPos, paint)

            canvas.drawLine(24f, yPos + 6f, 571f, yPos + 6f, linePaint)
            yPos += 24f
            if (yPos > 740f) break
        }

        // Signature section
        val sigY = 780f
        paint.color = Color.parseColor("#444444")
        paint.textSize = 9f
        canvas.drawLine(400f, sigY, 550f, sigY, linePaint)
        canvas.drawText("Md. Shah Walimullah Rabby", 410f, sigY + 14f, paint)
        canvas.drawText("Government AI Technician", 415f, sigY + 26f, paint)

        document.finishPage(page)

        return try {
            val fileDir = File(context.cacheDir, "reports")
            if (!fileDir.exists()) fileDir.mkdirs()
            val file = File(fileDir, "treatment_report_${System.currentTimeMillis()}.pdf")
            val outputStream = FileOutputStream(file)
            document.writeTo(outputStream)
            outputStream.flush()
            outputStream.close()
            document.close()
            file
        } catch (e: Exception) {
            e.printStackTrace()
            document.close()
            null
        }
    }

    fun sharePdf(context: Context, file: File) {
        try {
            val authority = "${context.packageName}.fileprovider"
            val uri: Uri = FileProvider.getUriForFile(context, authority, file)
            val intent = Intent(Intent.ACTION_SEND).apply {
                type = "application/pdf"
                putExtra(Intent.EXTRA_STREAM, uri)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            context.startActivity(Intent.createChooser(intent, "Share Treatment Report PDF"))
        } catch (e: Exception) {
            Toast.makeText(context, "Could not share PDF: ${e.message}", Toast.LENGTH_SHORT).show()
        }
    }

    fun generateCsvReport(treatments: List<TreatmentEntity>): String {
        val sb = StringBuilder()
        sb.append("Visit ID,Date,Time,Owner,Phone,Village,Animal Tag,Species,Breed,Problem,Treatment,Follow-up Date,Follow-up Completed\n")
        for (t in treatments) {
            sb.append("\"${t.visitCode}\",")
            sb.append("\"${t.date}\",")
            sb.append("\"${t.time}\",")
            sb.append("\"${t.ownerName}\",")
            sb.append("\"${t.ownerPhone}\",")
            sb.append("\"${t.village}\",")
            sb.append("\"${t.animalTag}\",")
            sb.append("\"${t.species}\",")
            sb.append("\"${t.breed}\",")
            sb.append("\"${t.problem.replace("\"", "'")}\",")
            sb.append("\"${t.treatment.replace("\"", "'")}\",")
            sb.append("\"${t.followUpDate}\",")
            sb.append("\"${if (t.isFollowUpCompleted) "Yes" else "No"}\"\n")
        }
        return sb.toString()
    }
}
