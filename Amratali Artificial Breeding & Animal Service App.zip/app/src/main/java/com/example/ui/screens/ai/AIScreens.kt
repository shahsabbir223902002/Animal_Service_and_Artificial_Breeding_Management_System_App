package com.example.ui.screens.ai

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.entity.AIRecordEntity
import com.example.ui.MainViewModel
import com.example.ui.components.AppHeader
import com.example.ui.components.EmptyView
import com.example.ui.components.StatusBadge
import com.example.ui.screens.owners.DetailRow
import com.example.ui.theme.*
import com.example.util.DateUtils

@Composable
fun AIRecordListScreen(
    viewModel: MainViewModel,
    onNavigateBack: () -> Unit,
    onAIClick: (Long) -> Unit,
    onAddAI: () -> Unit,
    onProfileClick: () -> Unit
) {
    val aiRecords by viewModel.filteredAIRecords.collectAsStateWithLifecycle()
    val searchQuery by viewModel.aiSearchQuery.collectAsStateWithLifecycle()
    val statusFilter by viewModel.aiStatusFilter.collectAsStateWithLifecycle()
    val syncState by viewModel.syncState.collectAsStateWithLifecycle()

    val statusOptions = listOf("All", "AI Completed", "Pregnancy Check Pending", "Pregnant", "Not Pregnant", "Completed")

    BackHandler { onNavigateBack() }

    Scaffold(
        topBar = {
            AppHeader(
                title = "Artificial Insemination (AI)",
                subtitle = "${aiRecords.size} AI Insemination Services",
                showBack = true,
                onBack = onNavigateBack,
                syncState = syncState,
                onSyncClick = { viewModel.triggerSync() },
                onProfileClick = onProfileClick
            )
        },
        floatingActionButton = {
            FloatingActionButton(
                onClick = onAddAI,
                containerColor = Color(0xFF7E22CE),
                contentColor = Color.White,
                modifier = Modifier.testTag("add_ai_fab")
            ) {
                Icon(Icons.Default.Add, contentDescription = "New AI Record")
            }
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .background(MaterialTheme.colorScheme.background)
        ) {
            // Search Input
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { viewModel.aiSearchQuery.value = it },
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 6.dp)
                    .testTag("ai_search_field"),
                placeholder = { Text("Search by Animal Tag, Owner, Breed, Bull...") },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = "Search") },
                trailingIcon = {
                    if (searchQuery.isNotEmpty()) {
                        IconButton(onClick = { viewModel.aiSearchQuery.value = "" }) {
                            Icon(Icons.Default.Clear, contentDescription = "Clear")
                        }
                    }
                },
                singleLine = true,
                shape = RoundedCornerShape(12.dp)
            )

            // Status Filter Chips
            LazyRow(
                modifier = Modifier.fillMaxWidth(),
                contentPadding = PaddingValues(horizontal = 16.dp, vertical = 4.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(statusOptions) { status ->
                    FilterChip(
                        selected = statusFilter == status,
                        onClick = { viewModel.aiStatusFilter.value = status },
                        label = { Text(status, fontSize = 11.sp) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = Color(0xFFF3E8FF),
                            selectedLabelColor = Color(0xFF7E22CE)
                        )
                    )
                }
            }

            if (aiRecords.isEmpty()) {
                EmptyView(
                    icon = Icons.Default.Biotech,
                    title = if (searchQuery.isNotBlank()) "No AI records matching query" else "No AI Records",
                    subtitle = "Log artificial inseminations, bull semen details, and automatic pregnancy check reminders.",
                    actionButtonText = "+ New AI Record",
                    onActionClick = onAddAI
                )
            } else {
                LazyColumn(
                    contentPadding = PaddingValues(16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    items(aiRecords, key = { it.id }) { record ->
                        AICardItem(
                            record = record,
                            onClick = { onAIClick(record.id) }
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun AICardItem(
    record: AIRecordEntity,
    onClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() }
            .testTag("ai_card_${record.id}"),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(34.dp)
                            .clip(CircleShape)
                            .background(Color(0xFFF3E8FF)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Biotech,
                            contentDescription = null,
                            tint = Color(0xFF7E22CE),
                            modifier = Modifier.size(18.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "AI Date: ${DateUtils.formatDisplayDate(record.aiDate)}",
                        style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold)
                    )
                }

                StatusBadge(
                    text = record.status,
                    color = when (record.status) {
                        "Pregnant" -> VetGreenPrimary
                        "Pregnancy Check Pending" -> VetAmberSecondary
                        else -> Color(0xFF7E22CE)
                    },
                    containerColor = when (record.status) {
                        "Pregnant" -> VetGreenContainer
                        "Pregnancy Check Pending" -> VetAmberContainer
                        else -> Color(0xFFF3E8FF)
                    }
                )
            }

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = "Cow/Tag: ${record.animalTag} • Owner: ${record.ownerName}",
                style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold)
            )

            Text(
                text = "Breed: ${record.breed} • Semen/Bull: ${record.semenBullInfo}",
                style = MaterialTheme.typography.bodySmall.copy(color = Color.DarkGray)
            )

            Spacer(modifier = Modifier.height(6.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = "Check Due: ${DateUtils.formatDisplayDate(record.expectedPregnancyCheckDate)}",
                    style = MaterialTheme.typography.labelSmall.copy(color = VetAmberSecondary, fontWeight = FontWeight.Bold)
                )
                if (record.expectedCalvingDate.isNotBlank()) {
                    Text(
                        text = "Calving: ${DateUtils.formatDisplayDate(record.expectedCalvingDate)}",
                        style = MaterialTheme.typography.labelSmall.copy(color = VetGreenPrimary, fontWeight = FontWeight.Bold)
                    )
                }
            }
        }
    }
}

@Composable
fun AIDetailScreen(
    aiId: Long,
    viewModel: MainViewModel,
    onNavigateBack: () -> Unit,
    onEditAI: (Long) -> Unit,
    onAnimalClick: (Long) -> Unit,
    onOwnerClick: (Long) -> Unit
) {
    val aiRecords by viewModel.allAIRecords.collectAsStateWithLifecycle()
    val record = aiRecords.find { it.id == aiId }

    var showDeleteDialog by remember { mutableStateOf(false) }

    BackHandler { onNavigateBack() }

    if (record == null) {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Text("AI record not found")
        }
        return
    }

    if (showDeleteDialog) {
        AlertDialog(
            onDismissRequest = { showDeleteDialog = false },
            title = { Text("Delete AI Record?") },
            text = { Text("Are you sure you want to delete this AI service record for ${record.animalTag}?") },
            confirmButton = {
                TextButton(
                    onClick = {
                        viewModel.deleteAIRecord(record) {
                            showDeleteDialog = false
                            onNavigateBack()
                        }
                    }
                ) {
                    Text("Delete", color = StatusAlertRed)
                }
            },
            dismissButton = {
                TextButton(onClick = { showDeleteDialog = false }) { Text("Cancel") }
            }
        )
    }

    Scaffold(
        topBar = {
            AppHeader(
                title = "AI Service: ${record.aiCode}",
                subtitle = "${record.animalTag} • ${record.breed}",
                showBack = true,
                onBack = onNavigateBack,
                actions = {
                    IconButton(onClick = { onEditAI(record.id) }) {
                        Icon(Icons.Default.Edit, contentDescription = "Edit")
                    }
                    IconButton(onClick = { showDeleteDialog = true }) {
                        Icon(Icons.Default.Delete, contentDescription = "Delete", tint = StatusAlertRed)
                    }
                }
            )
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .background(MaterialTheme.colorScheme.background),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Main Overview Card
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(
                                    DateUtils.formatDisplayDate(record.aiDate),
                                    style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold, color = Color(0xFF7E22CE))
                                )
                                Text("Insemination Date", style = MaterialTheme.typography.bodySmall.copy(color = Color.Gray))
                            }
                            StatusBadge(
                                text = record.status,
                                color = Color(0xFF7E22CE),
                                containerColor = Color(0xFFF3E8FF)
                            )
                        }

                        Spacer(modifier = Modifier.height(14.dp))
                        HorizontalDivider(color = VetOutlineVariant)
                        Spacer(modifier = Modifier.height(12.dp))

                        DetailRow(icon = Icons.Default.Pets, label = "Animal", value = record.animalTag)
                        DetailRow(icon = Icons.Default.Person, label = "Owner", value = record.ownerName)
                        DetailRow(icon = Icons.Default.Category, label = "Target Breed", value = record.breed)
                        DetailRow(icon = Icons.Default.Biotech, label = "Bull / Semen Station", value = record.semenBullInfo)
                        DetailRow(icon = Icons.Default.Badge, label = "Technician", value = record.technicianName)
                        if (record.heatDetectionDate.isNotBlank()) {
                            DetailRow(icon = Icons.Default.Whatshot, label = "Heat Signs Observed", value = record.heatDetectionDate)
                        }
                    }
                }
            }

            // Pregnancy & Calving Projections Card
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text("Reproduction & Timeline Projections", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold))
                        Spacer(modifier = Modifier.height(12.dp))

                        DetailRow(
                            icon = Icons.Default.FactCheck,
                            label = "Expected Pregnancy Check Date (+60 Days)",
                            value = "${DateUtils.formatDisplayDate(record.expectedPregnancyCheckDate)} (${record.pregnancyCheckResult})"
                        )

                        if (record.pregnancyCheckDate.isNotBlank()) {
                            DetailRow(
                                icon = Icons.Default.EventAvailable,
                                label = "Actual Check Date",
                                value = DateUtils.formatDisplayDate(record.pregnancyCheckDate)
                            )
                        }

                        DetailRow(
                            icon = Icons.Default.ChildCare,
                            label = "Expected Calving Date (+280 Days)",
                            value = DateUtils.formatDisplayDate(record.expectedCalvingDate)
                        )

                        if (record.notes.isNotBlank()) {
                            Spacer(modifier = Modifier.height(8.dp))
                            DetailRow(icon = Icons.Default.Notes, label = "Technician Field Notes", value = record.notes)
                        }
                    }
                }
            }

            // Quick Status Update (Mark Pregnant / Not Pregnant)
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Text("Update Pregnancy Check Result", fontWeight = FontWeight.Bold)
                        Spacer(modifier = Modifier.height(8.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Button(
                                onClick = {
                                    val updated = record.copy(
                                        pregnancyCheckResult = "Pregnant",
                                        pregnancyCheckDate = DateUtils.getTodayIso(),
                                        status = "Pregnant"
                                    )
                                    viewModel.updateAIRecord(updated) {}
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = VetGreenPrimary),
                                modifier = Modifier.weight(1f),
                                shape = RoundedCornerShape(10.dp)
                            ) {
                                Text("Mark Pregnant")
                            }

                            FilledTonalButton(
                                onClick = {
                                    val updated = record.copy(
                                        pregnancyCheckResult = "Not Pregnant",
                                        pregnancyCheckDate = DateUtils.getTodayIso(),
                                        status = "Not Pregnant"
                                    )
                                    viewModel.updateAIRecord(updated) {}
                                },
                                colors = ButtonDefaults.filledTonalButtonColors(containerColor = Color(0xFFFFEBEE)),
                                modifier = Modifier.weight(1f),
                                shape = RoundedCornerShape(10.dp)
                            ) {
                                Text("Not Pregnant", color = StatusAlertRed)
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun AddEditAIRecordScreen(
    aiId: Long? = null,
    preselectedAnimalId: Long? = null,
    viewModel: MainViewModel,
    onNavigateBack: () -> Unit,
    onSaved: (Long) -> Unit
) {
    val aiRecords by viewModel.allAIRecords.collectAsStateWithLifecycle()
    val animals by viewModel.allAnimals.collectAsStateWithLifecycle()
    val owners by viewModel.allOwners.collectAsStateWithLifecycle()
    val existing = aiRecords.find { it.id == aiId }

    var selectedAnimalId by remember { mutableStateOf(existing?.animalId ?: preselectedAnimalId ?: (animals.firstOrNull()?.id ?: 0L)) }
    val selectedAnimal = animals.find { it.id == selectedAnimalId }

    var aiDate by remember { mutableStateOf(existing?.aiDate ?: DateUtils.getTodayIso()) }
    var heatDate by remember { mutableStateOf(existing?.heatDetectionDate ?: aiDate) }
    var breed by remember { mutableStateOf(existing?.breed ?: "100% Holstein Friesian") }
    var semenBullInfo by remember { mutableStateOf(existing?.semenBullInfo ?: "Bull #FR-402, CCBD Central Bull Station") }
    var expectedPregnancyCheckDate by remember {
        mutableStateOf(existing?.expectedPregnancyCheckDate ?: DateUtils.calculatePregnancyCheckDate(aiDate, 60))
    }
    var expectedCalvingDate by remember {
        mutableStateOf(existing?.expectedCalvingDate ?: DateUtils.calculateExpectedCalvingDate(aiDate, 280))
    }
    var pregnancyResult by remember { mutableStateOf(existing?.pregnancyCheckResult ?: "Pending") }
    var status by remember { mutableStateOf(existing?.status ?: "AI Completed") }
    var notes by remember { mutableStateOf(existing?.notes ?: "") }

    var errorMessage by remember { mutableStateOf<String?>(null) }

    val breedOptions = listOf(
        "100% Holstein Friesian",
        "75% Friesian Cross",
        "50% Shahiwal",
        "100% Shahiwal",
        "Red Chittagong (RCC)",
        "Murrah Buffalo",
        "Black Bengal Goat"
    )

    BackHandler { onNavigateBack() }

    Scaffold(
        topBar = {
            AppHeader(
                title = if (existing == null) "New Artificial Insemination" else "Edit AI Record",
                showBack = true,
                onBack = onNavigateBack
            )
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .background(MaterialTheme.colorScheme.background),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            if (errorMessage != null) {
                item {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = Color(0xFFFFEBEE)),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Text(
                            text = errorMessage ?: "",
                            color = StatusAlertRed,
                            modifier = Modifier.padding(12.dp)
                        )
                    }
                }
            }

            // Animal Selection
            item {
                Text("Select Cow / Animal *", style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold))
                Spacer(modifier = Modifier.height(4.dp))
                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(animals) { animal ->
                        FilterChip(
                            selected = selectedAnimalId == animal.id,
                            onClick = { selectedAnimalId = animal.id },
                            label = { Text("${animal.tagNumber} (${animal.name}) - ${animal.ownerName}") }
                        )
                    }
                }
            }

            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    OutlinedTextField(
                        value = aiDate,
                        onValueChange = {
                            aiDate = it
                            expectedPregnancyCheckDate = DateUtils.calculatePregnancyCheckDate(it, 60)
                            expectedCalvingDate = DateUtils.calculateExpectedCalvingDate(it, 280)
                        },
                        label = { Text("AI Date (yyyy-MM-dd)") },
                        modifier = Modifier.weight(1f),
                        singleLine = true
                    )
                    OutlinedTextField(
                        value = heatDate,
                        onValueChange = { heatDate = it },
                        label = { Text("Heat Detection Date") },
                        modifier = Modifier.weight(1f),
                        singleLine = true
                    )
                }
            }

            // Target Breed
            item {
                Text("Target Breed (বীজের জাত)", style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold))
                Spacer(modifier = Modifier.height(4.dp))
                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(breedOptions) { opt ->
                        FilterChip(
                            selected = breed == opt,
                            onClick = { breed = opt },
                            label = { Text(opt, fontSize = 11.sp) }
                        )
                    }
                }
            }

            item {
                OutlinedTextField(
                    value = semenBullInfo,
                    onValueChange = { semenBullInfo = it; errorMessage = null },
                    label = { Text("Bull / Semen Source & Batch *") },
                    placeholder = { Text("e.g. Bull #FR-402, CCBD Rajabari, Savar AI Lab") },
                    modifier = Modifier.fillMaxWidth().testTag("semen_bull_input"),
                    singleLine = true
                )
            }

            item {
                OutlinedTextField(
                    value = expectedPregnancyCheckDate,
                    onValueChange = { expectedPregnancyCheckDate = it },
                    label = { Text("Expected Pregnancy Check Date (+60 Days)") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )
            }

            item {
                OutlinedTextField(
                    value = expectedCalvingDate,
                    onValueChange = { expectedCalvingDate = it },
                    label = { Text("Expected Calving Date (+280 Days)") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )
            }

            item {
                OutlinedTextField(
                    value = notes,
                    onValueChange = { notes = it },
                    label = { Text("AI Notes (Cervical mucus, ease of insemination)") },
                    placeholder = { Text("e.g. Clear standing heat, high quality semen straw") },
                    modifier = Modifier.fillMaxWidth(),
                    minLines = 2
                )
            }

            item {
                Spacer(modifier = Modifier.height(10.dp))
                Button(
                    onClick = {
                        val animal = selectedAnimal
                        if (animal == null) {
                            errorMessage = "Please select an animal"
                            return@Button
                        }
                        if (semenBullInfo.isBlank()) {
                            errorMessage = "Please enter bull / semen information"
                            return@Button
                        }

                        if (existing != null) {
                            val updated = existing.copy(
                                animalId = animal.id,
                                animalTag = animal.tagNumber,
                                ownerId = animal.ownerId,
                                ownerName = animal.ownerName,
                                aiDate = aiDate,
                                heatDetectionDate = heatDate,
                                breed = breed,
                                semenBullInfo = semenBullInfo.trim(),
                                expectedPregnancyCheckDate = expectedPregnancyCheckDate,
                                expectedCalvingDate = expectedCalvingDate,
                                notes = notes.trim()
                            )
                            viewModel.updateAIRecord(updated) {
                                onSaved(updated.id)
                            }
                        } else {
                            val code = "AI-${(100..999).random()}"
                            val newRecord = AIRecordEntity(
                                aiCode = code,
                                ownerId = animal.ownerId,
                                ownerName = animal.ownerName,
                                animalId = animal.id,
                                animalTag = animal.tagNumber,
                                aiDate = aiDate,
                                heatDetectionDate = heatDate,
                                breed = breed,
                                semenBullInfo = semenBullInfo.trim(),
                                technicianName = "Md. Shah Walimullah Rabby",
                                expectedPregnancyCheckDate = expectedPregnancyCheckDate,
                                expectedCalvingDate = expectedCalvingDate,
                                notes = notes.trim(),
                                status = "AI Completed"
                            )
                            viewModel.addAIRecord(newRecord) { id ->
                                onSaved(id)
                            }
                        }
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(50.dp)
                        .testTag("save_ai_button"),
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF7E22CE)),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Icon(Icons.Default.Save, contentDescription = null)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Save AI Record", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                }
            }
        }
    }
}
