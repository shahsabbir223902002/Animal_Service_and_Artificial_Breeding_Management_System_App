package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.platform.LocalContext

private val DarkColorScheme = darkColorScheme(
    primary = VetGreenPrimaryDark,
    onPrimary = VetGreenOnContainer,
    primaryContainer = VetGreenContainerDark,
    onPrimaryContainer = VetGreenPrimaryDark,
    secondary = VetAmberSecondary,
    onSecondary = VetAmberOnSecondary,
    secondaryContainer = VetAmberContainer,
    onSecondaryContainer = VetAmberOnContainer,
    tertiary = VetTealTertiary,
    background = VetBackgroundDark,
    onBackground = VetOnSurfaceDark,
    surface = VetSurfaceDark,
    onSurface = VetOnSurfaceDark,
    surfaceVariant = VetSurfaceVariant,
    onSurfaceVariant = VetOnSurfaceVariant,
    outline = VetOutline
)

private val LightColorScheme = lightColorScheme(
    primary = VetGreenPrimary,
    onPrimary = VetGreenOnPrimary,
    primaryContainer = VetGreenContainer,
    onPrimaryContainer = VetGreenOnContainer,
    secondary = VetAmberSecondary,
    onSecondary = VetAmberOnSecondary,
    secondaryContainer = VetAmberContainer,
    onSecondaryContainer = VetAmberOnContainer,
    tertiary = VetTealTertiary,
    onTertiary = VetTealOnTertiary,
    tertiaryContainer = VetTealContainer,
    onTertiaryContainer = VetTealOnContainer,
    background = VetBackground,
    onBackground = VetOnBackground,
    surface = VetSurface,
    onSurface = VetOnSurface,
    surfaceVariant = VetSurfaceVariant,
    onSurfaceVariant = VetOnSurfaceVariant,
    outline = VetOutline,
    outlineVariant = VetOutlineVariant
)

@Composable
fun RabbyAnimalsTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    dynamicColor: Boolean = false, // Keep brand veterinary green identity consistent
    content: @Composable () -> Unit
) {
    val colorScheme = when {
        dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> {
            val context = LocalContext.current
            if (darkTheme) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
        }
        darkTheme -> DarkColorScheme
        else -> LightColorScheme
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
