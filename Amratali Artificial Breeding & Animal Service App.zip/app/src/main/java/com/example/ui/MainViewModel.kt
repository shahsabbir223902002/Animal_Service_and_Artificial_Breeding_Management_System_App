package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.database.AppDatabase
import com.example.data.entity.*
import com.example.data.repository.AppRepository
import com.example.data.repository.SyncState
import com.example.util.DateUtils
import com.example.util.NotificationHelper
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

data class TreatmentFilterState(
    val dateFilter: String = "This Month",
    val start: String = "",
    val end: String = "",
    val species: String = "All",
    val village: String = "All",
    val searchQuery: String = "",
    val sortOrder: String = "Newest First"
)

class MainViewModel(application: Application) : AndroidViewModel(application) {
    private val database = AppDatabase.getDatabase(application, viewModelScope)
    val repository = AppRepository(database, application)

    val syncState: StateFlow<SyncState> = repository.syncState

    private val _isLoggedIn = MutableStateFlow(repository.isLoggedIn())
    val isLoggedIn: StateFlow<Boolean> = _isLoggedIn.asStateFlow()

    private val _language = MutableStateFlow(repository.getLanguage())
    val language: StateFlow<String> = _language.asStateFlow()

    // Counts
    val ownerCount: StateFlow<Int> = repository.ownerCount.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0)
    val animalCount: StateFlow<Int> = repository.animalCount.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0)
    val treatmentCount: StateFlow<Int> = repository.treatmentCount.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0)
    val todayTreatmentCount: StateFlow<Int> = repository.getTodayTreatmentCount(DateUtils.getTodayIso())
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0)
    val pendingFollowUpCount: StateFlow<Int> = repository.pendingFollowUpCount.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0)
    val aiCount: StateFlow<Int> = repository.aiCount.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0)
    val vaccinationCount: StateFlow<Int> = repository.vaccinationCount.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0)
    val dewormingCount: StateFlow<Int> = repository.dewormingCount.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0)
    val pendingAppointmentCount: StateFlow<Int> = repository.pendingAppointmentCount.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0)
    val pendingReminderCount: StateFlow<Int> = repository.pendingReminderCount.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0)

    // Base collections
    val allOwners: StateFlow<List<OwnerEntity>> = repository.allOwners.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val allAnimals: StateFlow<List<AnimalEntity>> = repository.allAnimals.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val allTreatments: StateFlow<List<TreatmentEntity>> = repository.allTreatments.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val allAIRecords: StateFlow<List<AIRecordEntity>> = repository.allAIRecords.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val pendingPregnancyChecks: StateFlow<List<AIRecordEntity>> = repository.pendingPregnancyChecks.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val allVaccinations: StateFlow<List<VaccinationEntity>> = repository.allVaccinations.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val allDewormings: StateFlow<List<DewormingEntity>> = repository.allDewormings.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val allAppointments: StateFlow<List<AppointmentEntity>> = repository.allAppointments.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val allReminders: StateFlow<List<ReminderEntity>> = repository.allReminders.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val pendingReminders: StateFlow<List<ReminderEntity>> = repository.pendingReminders.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val recentLogs: StateFlow<List<ActivityLogEntity>> = repository.recentLogs.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Owners Filtering
    val ownerSearchQuery = MutableStateFlow("")
    val filteredOwners: StateFlow<List<OwnerEntity>> = combine(allOwners, ownerSearchQuery) { owners, query ->
        if (query.isBlank()) owners
        else {
            val q = query.trim().lowercase()
            owners.filter {
                it.name.lowercase().contains(q) ||
                it.phone.contains(q) ||
                it.village.lowercase().contains(q) ||
                it.ownerCode.lowercase().contains(q)
            }
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Animals Filtering
    val animalSearchQuery = MutableStateFlow("")
    val animalSpeciesFilter = MutableStateFlow("All")
    val filteredAnimals: StateFlow<List<AnimalEntity>> = combine(allAnimals, animalSearchQuery, animalSpeciesFilter) { animals, query, species ->
        animals.filter {
            val matchesSpecies = species == "All" || it.species.equals(species, ignoreCase = true)
            val matchesQuery = query.isBlank() ||
                it.tagNumber.lowercase().contains(query.trim().lowercase()) ||
                it.name.lowercase().contains(query.trim().lowercase()) ||
                it.breed.lowercase().contains(query.trim().lowercase()) ||
                it.ownerName.lowercase().contains(query.trim().lowercase())
            matchesSpecies && matchesQuery
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Advanced Treatment Filtering & Analytics (Section 33 & 36)
    val treatmentDateFilter = MutableStateFlow("This Month")
    val treatmentCustomStart = MutableStateFlow(DateUtils.getStartOfMonth(-1))
    val treatmentCustomEnd = MutableStateFlow(DateUtils.getTodayIso())
    val treatmentSpeciesFilter = MutableStateFlow("All")
    val treatmentVillageFilter = MutableStateFlow("All")
    val treatmentSearchQuery = MutableStateFlow("")
    val treatmentSortOrder = MutableStateFlow("Newest First")

    private val treatmentFiltersFlow: Flow<TreatmentFilterState> = combine(
        treatmentDateFilter,
        treatmentCustomStart,
        treatmentCustomEnd,
        treatmentSpeciesFilter
    ) { date, start, end, species ->
        TreatmentFilterState(dateFilter = date, start = start, end = end, species = species)
    }.combine(
        combine(treatmentVillageFilter, treatmentSearchQuery, treatmentSortOrder) { village, search, sort ->
            Triple(village, search, sort)
        }
    ) { partial, (village, search, sort) ->
        partial.copy(village = village, searchQuery = search, sortOrder = sort)
    }

    val filteredTreatments: StateFlow<List<TreatmentEntity>> = combine(allTreatments, treatmentFiltersFlow) { treatments, filter ->
        val today = DateUtils.getTodayIso()
        val startOfWeek = DateUtils.getStartOfWeek()
        val startOfThisMonth = DateUtils.getStartOfMonth(0)
        val startOfLastMonth = DateUtils.getStartOfMonth(-1)
        val endOfLastMonth = DateUtils.getEndOfMonth(-1)
        val startOf2MonthsAgo = DateUtils.getStartOfMonth(-2)
        val startOf3MonthsAgo = DateUtils.getStartOfMonth(-3)
        val startOf6MonthsAgo = DateUtils.getStartOfMonth(-6)
        val startOfYear = DateUtils.getStartOfYear()

        val filtered = treatments.filter { t ->
            val matchesDate = when (filter.dateFilter) {
                "Today" -> t.date == today
                "This Week" -> t.date >= startOfWeek && t.date <= today
                "This Month" -> t.date >= startOfThisMonth && t.date <= today
                "Last Month" -> t.date in startOfLastMonth..endOfLastMonth
                "Last 2 Months" -> t.date >= startOf2MonthsAgo && t.date <= today
                "Last 3 Months" -> t.date >= startOf3MonthsAgo && t.date <= today
                "Last 6 Months" -> t.date >= startOf6MonthsAgo && t.date <= today
                "This Year" -> t.date >= startOfYear && t.date <= today
                "Custom Range" -> t.date in filter.start..filter.end
                else -> true
            }

            val matchesSpecies = filter.species == "All" || t.species.equals(filter.species, ignoreCase = true)
            val matchesVillage = filter.village == "All" || t.village.equals(filter.village, ignoreCase = true)

            val matchesQuery = if (filter.searchQuery.isBlank()) true else {
                val q = filter.searchQuery.trim().lowercase()
                t.ownerName.lowercase().contains(q) ||
                t.ownerPhone.contains(q) ||
                t.animalTag.lowercase().contains(q) ||
                t.animalName.lowercase().contains(q) ||
                t.village.lowercase().contains(q) ||
                t.visitCode.lowercase().contains(q) ||
                t.problem.lowercase().contains(q) ||
                t.treatment.lowercase().contains(q) ||
                t.date.contains(q)
            }

            matchesDate && matchesSpecies && matchesVillage && matchesQuery
        }

        when (filter.sortOrder) {
            "Oldest First" -> filtered.sortedWith(compareBy({ it.date }, { it.id }))
            "Owner Name" -> filtered.sortedBy { it.ownerName }
            "Animal Tag" -> filtered.sortedBy { it.animalTag }
            else -> filtered.sortedWith(compareByDescending<TreatmentEntity> { it.date }.thenByDescending { it.id })
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // AI Records Filtering
    val aiSearchQuery = MutableStateFlow("")
    val aiStatusFilter = MutableStateFlow("All")
    val filteredAIRecords: StateFlow<List<AIRecordEntity>> = combine(allAIRecords, aiSearchQuery, aiStatusFilter) { list, query, status ->
        list.filter {
            val matchesStatus = status == "All" || it.status.equals(status, ignoreCase = true)
            val matchesQuery = query.isBlank() ||
                it.animalTag.lowercase().contains(query.trim().lowercase()) ||
                it.ownerName.lowercase().contains(query.trim().lowercase()) ||
                it.aiCode.lowercase().contains(query.trim().lowercase()) ||
                it.breed.lowercase().contains(query.trim().lowercase()) ||
                it.semenBullInfo.lowercase().contains(query.trim().lowercase())
            matchesStatus && matchesQuery
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    init {
        NotificationHelper.createNotificationChannel(application)
    }

    // Auth actions
    fun login(pin: String): Boolean {
        if (pin == repository.getUserPin()) {
            repository.setLoggedIn(true)
            _isLoggedIn.value = true
            return true
        }
        return false
    }

    fun logout() {
        repository.setLoggedIn(false)
        _isLoggedIn.value = false
    }

    fun changePin(newPin: String) {
        repository.setUserPin(newPin)
    }

    fun setLanguage(lang: String) {
        repository.setLanguage(lang)
        _language.value = lang
    }

    fun triggerSync() {
        viewModelScope.launch {
            repository.triggerSync()
        }
    }

    // Owner CRUD
    fun addOwner(owner: OwnerEntity, onDone: (Long) -> Unit = {}) {
        viewModelScope.launch {
            val id = repository.insertOwner(owner)
            onDone(id)
        }
    }

    fun updateOwner(owner: OwnerEntity, onDone: () -> Unit = {}) {
        viewModelScope.launch {
            repository.updateOwner(owner)
            onDone()
        }
    }

    fun deleteOwner(owner: OwnerEntity, onDone: () -> Unit = {}) {
        viewModelScope.launch {
            repository.deleteOwner(owner)
            onDone()
        }
    }

    // Animal CRUD
    fun addAnimal(animal: AnimalEntity, onDone: (Long) -> Unit = {}) {
        viewModelScope.launch {
            val id = repository.insertAnimal(animal)
            onDone(id)
        }
    }

    fun updateAnimal(animal: AnimalEntity, onDone: () -> Unit = {}) {
        viewModelScope.launch {
            repository.updateAnimal(animal)
            onDone()
        }
    }

    fun deleteAnimal(animal: AnimalEntity, onDone: () -> Unit = {}) {
        viewModelScope.launch {
            repository.deleteAnimal(animal)
            onDone()
        }
    }

    // Treatment CRUD
    fun addTreatment(treatment: TreatmentEntity, onDone: (Long) -> Unit = {}) {
        viewModelScope.launch {
            val id = repository.insertTreatment(treatment)
            onDone(id)
        }
    }

    fun updateTreatment(treatment: TreatmentEntity, onDone: () -> Unit = {}) {
        viewModelScope.launch {
            repository.updateTreatment(treatment)
            onDone()
        }
    }

    fun deleteTreatment(treatment: TreatmentEntity, onDone: () -> Unit = {}) {
        viewModelScope.launch {
            repository.deleteTreatment(treatment)
            onDone()
        }
    }

    fun toggleFollowUpCompleted(id: Long, completed: Boolean) {
        viewModelScope.launch {
            repository.setFollowUpCompleted(id, completed)
        }
    }

    // AI Record CRUD
    fun addAIRecord(record: AIRecordEntity, onDone: (Long) -> Unit = {}) {
        viewModelScope.launch {
            val id = repository.insertAIRecord(record)
            onDone(id)
        }
    }

    fun updateAIRecord(record: AIRecordEntity, onDone: () -> Unit = {}) {
        viewModelScope.launch {
            repository.updateAIRecord(record)
            onDone()
        }
    }

    fun deleteAIRecord(record: AIRecordEntity, onDone: () -> Unit = {}) {
        viewModelScope.launch {
            repository.deleteAIRecord(record)
            onDone()
        }
    }

    // Vaccination & Deworming
    fun addVaccination(vaccination: VaccinationEntity, onDone: () -> Unit = {}) {
        viewModelScope.launch {
            repository.insertVaccination(vaccination)
            onDone()
        }
    }

    fun deleteVaccination(vaccination: VaccinationEntity) {
        viewModelScope.launch {
            repository.deleteVaccination(vaccination)
        }
    }

    fun addDeworming(deworming: DewormingEntity, onDone: () -> Unit = {}) {
        viewModelScope.launch {
            repository.insertDeworming(deworming)
            onDone()
        }
    }

    fun deleteDeworming(deworming: DewormingEntity) {
        viewModelScope.launch {
            repository.deleteDeworming(deworming)
        }
    }

    // Appointments
    fun addAppointment(app: AppointmentEntity, onDone: () -> Unit = {}) {
        viewModelScope.launch {
            repository.insertAppointment(app)
            onDone()
        }
    }

    fun updateAppointment(app: AppointmentEntity) {
        viewModelScope.launch {
            repository.updateAppointment(app)
        }
    }

    fun deleteAppointment(app: AppointmentEntity) {
        viewModelScope.launch {
            repository.deleteAppointment(app)
        }
    }

    // Reminders
    fun toggleReminderCompleted(id: Long, completed: Boolean) {
        viewModelScope.launch {
            repository.setReminderCompleted(id, completed)
        }
    }

    fun addReminder(reminder: ReminderEntity, onDone: () -> Unit = {}) {
        viewModelScope.launch {
            repository.insertReminder(reminder)
            onDone()
        }
    }

    fun deleteReminder(reminder: ReminderEntity) {
        viewModelScope.launch {
            repository.deleteReminder(reminder)
        }
    }

    fun testReminderNotification(title: String, message: String) {
        NotificationHelper.showReminderNotification(getApplication(), 101, title, message)
    }
}
