package com.example.ui.screens.profile

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.ui.MainViewModel
import com.example.ui.components.AppHeader
import com.example.ui.screens.owners.DetailRow
import com.example.ui.theme.*
import com.example.util.ActionUtils

@Composable
fun RabbyProfileScreen(
    viewModel: MainViewModel,
    onNavigateBack: () -> Unit
) {
    val context = LocalContext.current
    val mobileNumber = viewModel.repository.getUserMobile()
    val facebookUrl = viewModel.repository.getFacebookUrl()

    BackHandler { onNavigateBack() }

    Scaffold(
        topBar = {
            AppHeader(
                title = "Professional Profile",
                subtitle = "About Md. Shah Walimullah Rabby",
                showBack = true,
                onBack = onNavigateBack
            )
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .background(MaterialTheme.colorScheme.background),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Hero Profile Banner
            item {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("rabby_profile_card"),
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    elevation = CardDefaults.cardElevation(defaultElevation = 3.dp)
                ) {
                    Column(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        // Header photo background with animal cover picture (cow, goat, ox)
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(190.dp)
                        ) {
                            Image(
                                painter = painterResource(id = R.drawable.livestock_cover),
                                contentDescription = "Livestock animals cow, goat and ox in farm pasture",
                                contentScale = ContentScale.Crop,
                                modifier = Modifier.fillMaxSize()
                            )
                        }

                        // Circular Avatar with animal care emblem
                        Box(
                            modifier = Modifier
                                .offset(y = (-48).dp)
                                .size(100.dp)
                                .clip(CircleShape)
                                .background(Color.White)
                                .padding(3.dp)
                                .clip(CircleShape)
                                .background(VetGreenContainer),
                            contentAlignment = Alignment.Center
                        ) {
                            Image(
                                painter = painterResource(id = R.drawable.ic_app_logo),
                                contentDescription = "Animal Care Emblem",
                                contentScale = ContentScale.Crop,
                                modifier = Modifier.fillMaxSize()
                            )
                        }

                        Column(
                            modifier = Modifier
                                .offset(y = (-36).dp)
                                .padding(horizontal = 16.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Text(
                                text = "Md. Shah Walimullah Rabby",
                                style = MaterialTheme.typography.titleLarge.copy(
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 20.sp
                                ),
                                textAlign = TextAlign.Center
                            )
                            Text(
                                text = "সরকারি এ.আই টেকনিশিয়ান (Govt. AI Technician)",
                                style = MaterialTheme.typography.bodyMedium.copy(
                                    color = VetGreenPrimary,
                                    fontWeight = FontWeight.SemiBold
                                ),
                                textAlign = TextAlign.Center
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "আমড়াতলী কৃত্রিম প্রজনন কেন্দ্র (Amratali AI Center)",
                                style = MaterialTheme.typography.bodySmall.copy(color = MaterialTheme.colorScheme.onSurfaceVariant),
                                textAlign = TextAlign.Center
                            )
                            Text(
                                text = "উপজেলা প্রাণিসম্পদ দপ্তর ও ভেটেরিনারি হাসপাতাল\nআদর্শ সদর, রামালা, কুমিল্লা",
                                style = MaterialTheme.typography.bodySmall.copy(color = Color.Gray),
                                textAlign = TextAlign.Center
                            )

                            Spacer(modifier = Modifier.height(18.dp))

                            // Large Contact Action Buttons (Section 34)
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                Button(
                                    onClick = { ActionUtils.callPhone(context, mobileNumber) },
                                    colors = ButtonDefaults.buttonColors(containerColor = VetGreenPrimary),
                                    modifier = Modifier.weight(1f),
                                    shape = RoundedCornerShape(12.dp)
                                ) {
                                    Icon(Icons.Default.Call, contentDescription = null, modifier = Modifier.size(18.dp))
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("Call Rabby")
                                }

                                OutlinedButton(
                                    onClick = { ActionUtils.sendSms(context, mobileNumber, "Hello Rabby Sir, ") },
                                    modifier = Modifier.weight(1f),
                                    shape = RoundedCornerShape(12.dp)
                                ) {
                                    Icon(Icons.Default.Message, contentDescription = null, modifier = Modifier.size(18.dp))
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("Message")
                                }
                            }

                            Spacer(modifier = Modifier.height(8.dp))

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                FilledTonalButton(
                                    onClick = { ActionUtils.openFacebook(context, facebookUrl) },
                                    colors = ButtonDefaults.filledTonalButtonColors(containerColor = Color(0xFFE0F2FE)),
                                    modifier = Modifier.weight(1f),
                                    shape = RoundedCornerShape(12.dp)
                                ) {
                                    Icon(Icons.Default.Public, contentDescription = null, tint = Color(0xFF0284C7), modifier = Modifier.size(18.dp))
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("Facebook", color = Color(0xFF0284C7), fontWeight = FontWeight.Bold)
                                }

                                FilledTonalButton(
                                    onClick = {
                                        ActionUtils.openMap(
                                            context,
                                            23.4607,
                                            91.1809,
                                            "Upazila Veterinary Hospital, Ramamala, Cumilla"
                                        )
                                    },
                                    colors = ButtonDefaults.filledTonalButtonColors(containerColor = VetAmberContainer),
                                    modifier = Modifier.weight(1f),
                                    shape = RoundedCornerShape(12.dp)
                                ) {
                                    Icon(Icons.Default.LocationOn, contentDescription = null, tint = VetAmberSecondary, modifier = Modifier.size(18.dp))
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("Hospital Map", color = VetAmberSecondary, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }
                }
            }

            // Official Credentials Card
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text("Official Information & Jurisdiction", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold))
                        Spacer(modifier = Modifier.height(10.dp))

                        DetailRow(icon = Icons.Default.Badge, label = "Official Designation", value = "Government AI Technician (সরকারি কৃত্রিম প্রজনন কর্মী)")
                        DetailRow(icon = Icons.Default.Business, label = "Workplace / Center", value = "Amratali Artificial Breeding Center")
                        DetailRow(icon = Icons.Default.LocalHospital, label = "Supervising Hospital", value = "Upazila Prani Sampad Doptor & Veterinary Hospital")
                        DetailRow(icon = Icons.Default.Map, label = "Service Area Coverage", value = "Amratali, Ramamala, Shimpur, Jagannathpur, Adarsha Sadar, Cumilla")
                        DetailRow(icon = Icons.Default.Phone, label = "Official Hotline / Mobile", value = mobileNumber)
                        DetailRow(icon = Icons.Default.Public, label = "Official Facebook Page", value = facebookUrl)
                    }
                }
            }

            // Veterinary Mission Note
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = VetGreenContainer.copy(alpha = 0.5f))
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Verified, contentDescription = null, tint = VetGreenPrimary)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Professional Commitment", fontWeight = FontWeight.Bold, color = VetGreenPrimary)
                        }
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "Dedicated to breed improvement, dairy genetic development, rapid veterinary medical response, and farmer economic prosperity across Cumilla region.",
                            style = MaterialTheme.typography.bodyMedium.copy(color = VetGreenOnContainer)
                        )
                    }
                }
            }
        }
    }
}

private fun Modifier.alpha(alpha: Float): Modifier = this
