package com.example.ui.screens.appointments

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.entity.AppointmentEntity
import com.example.ui.MainViewModel
import com.example.ui.components.AppHeader
import com.example.ui.components.EmptyView
import com.example.ui.components.StatusBadge
import com.example.ui.theme.*
import com.example.util.ActionUtils
import com.example.util.DateUtils

@Composable
fun AppointmentsScreen(
    viewModel: MainViewModel,
    onNavigateBack: () -> Unit,
    onProfileClick: () -> Unit
) {
    val context = LocalContext.current
    val appointments by viewModel.allAppointments.collectAsStateWithLifecycle()
    val owners by viewModel.allOwners.collectAsStateWithLifecycle()
    val syncState by viewModel.syncState.collectAsStateWithLifecycle()

    var showAddDialog by remember { mutableStateOf(false) }

    BackHandler { onNavigateBack() }

    if (showAddDialog) {
        AddAppointmentDialog(
            owners = owners,
            onDismiss = { showAddDialog = false },
            onSave = { app ->
                viewModel.addAppointment(app) {
                    showAddDialog = false
                }
            }
        )
    }

    Scaffold(
        topBar = {
            AppHeader(
                title = "Field Appointments",
                subtitle = "${appointments.size} Scheduled Visits",
                showBack = true,
                onBack = onNavigateBack,
                syncState = syncState,
                onSyncClick = { viewModel.triggerSync() },
                onProfileClick = onProfileClick
            )
        },
        floatingActionButton = {
            FloatingActionButton(
                onClick = { showAddDialog = true },
                containerColor = VetGreenPrimary,
                contentColor = Color.White
            ) {
                Icon(Icons.Default.Add, contentDescription = "Add Appointment")
            }
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .background(MaterialTheme.colorScheme.background)
        ) {
            if (appointments.isEmpty()) {
                EmptyView(
                    icon = Icons.Default.Event,
                    title = "No scheduled appointments",
                    subtitle = "Schedule AI visits, disease treatment calls, and farm consultations.",
                    actionButtonText = "+ Schedule Appointment",
                    onActionClick = { showAddDialog = true }
                )
            } else {
                LazyColumn(
                    contentPadding = PaddingValues(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    items(appointments, key = { it.id }) { app ->
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(14.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
                        ) {
                            Column(modifier = Modifier.padding(14.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Icon(Icons.Default.Schedule, contentDescription = null, tint = VetGreenPrimary, modifier = Modifier.size(16.dp))
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text("${DateUtils.formatDisplayDate(app.date)} • ${app.time}", fontWeight = FontWeight.Bold)
                                    }

                                    StatusBadge(
                                        text = app.status,
                                        color = when (app.status) {
                                            "Confirmed" -> VetGreenPrimary
                                            "Completed" -> Color(0xFF0369A1)
                                            "Cancelled" -> StatusAlertRed
                                            else -> VetAmberSecondary
                                        },
                                        containerColor = when (app.status) {
                                            "Confirmed" -> VetGreenContainer
                                            "Completed" -> Color(0xFFE0F2FE)
                                            "Cancelled" -> Color(0xFFFFEBEE)
                                            else -> VetAmberContainer
                                        }
                                    )
                                }

                                Spacer(modifier = Modifier.height(8.dp))

                                Text("Farmer: ${app.ownerName}", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold))
                                Text("Reason: ${app.reason}", style = MaterialTheme.typography.bodyMedium.copy(color = MaterialTheme.colorScheme.onSurface))
                                Text("Location: ${app.location}", style = MaterialTheme.typography.bodySmall.copy(color = Color.Gray))

                                Spacer(modifier = Modifier.height(10.dp))
                                HorizontalDivider(color = VetOutlineVariant)
                                Spacer(modifier = Modifier.height(8.dp))

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    OutlinedButton(
                                        onClick = { ActionUtils.callPhone(context, app.phone) },
                                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                                        shape = RoundedCornerShape(8.dp)
                                    ) {
                                        Icon(Icons.Default.Call, contentDescription = null, modifier = Modifier.size(14.dp))
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text("Call Farmer", fontSize = 11.sp)
                                    }

                                    Row {
                                        if (app.status != "Completed") {
                                            TextButton(onClick = {
                                                viewModel.updateAppointment(app.copy(status = "Completed"))
                                            }) {
                                                Text("Mark Done", color = VetGreenPrimary, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                            }
                                        }
                                        IconButton(onClick = { viewModel.deleteAppointment(app) }) {
                                            Icon(Icons.Default.Delete, contentDescription = "Delete", tint = Color.Gray, modifier = Modifier.size(18.dp))
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun AddAppointmentDialog(
    owners: List<com.example.data.entity.OwnerEntity>,
    onDismiss: () -> Unit,
    onSave: (AppointmentEntity) -> Unit
) {
    var selectedOwnerId by remember { mutableStateOf(owners.firstOrNull()?.id ?: 0L) }
    val owner = owners.find { it.id == selectedOwnerId }

    var date by remember { mutableStateOf(DateUtils.getTodayIso()) }
    var time by remember { mutableStateOf("10:00 AM") }
    var reason by remember { mutableStateOf("AI Service Request") }
    var location by remember { mutableStateOf(owner?.village ?: "Amratali") }
    var notes by remember { mutableStateOf("") }

    val commonReasons = listOf("AI Service Request", "Emergency Sick Animal", "Pregnancy Check", "Routine Vaccination", "General Consultation")

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Schedule New Appointment") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("Select Owner", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    items(owners) { o ->
                        FilterChip(
                            selected = selectedOwnerId == o.id,
                            onClick = {
                                selectedOwnerId = o.id
                                location = o.village
                            },
                            label = { Text("${o.name} (${o.village})") }
                        )
                    }
                }

                Text("Purpose / Reason", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    items(commonReasons) { r ->
                        FilterChip(
                            selected = reason == r,
                            onClick = { reason = r },
                            label = { Text(r, fontSize = 11.sp) }
                        )
                    }
                }

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = date,
                        onValueChange = { date = it },
                        label = { Text("Date") },
                        modifier = Modifier.weight(1f),
                        singleLine = true
                    )
                    OutlinedTextField(
                        value = time,
                        onValueChange = { time = it },
                        label = { Text("Time") },
                        modifier = Modifier.weight(1f),
                        singleLine = true
                    )
                }

                OutlinedTextField(
                    value = location,
                    onValueChange = { location = it },
                    label = { Text("Location / Yard") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (owner != null) {
                        onSave(
                            AppointmentEntity(
                                date = date,
                                time = time,
                                ownerId = owner.id,
                                ownerName = owner.name,
                                phone = owner.phone,
                                location = location,
                                reason = reason,
                                notes = notes,
                                status = "Confirmed"
                            )
                        )
                    }
                },
                colors = ButtonDefaults.buttonColors(containerColor = VetGreenPrimary)
            ) {
                Text("Confirm Schedule")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        }
    )
}
