package com.example.ui.screens.treatments

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.entity.TreatmentEntity
import com.example.ui.MainViewModel
import com.example.ui.components.AppHeader
import com.example.ui.components.EmptyView
import com.example.ui.components.MetricStatCard
import com.example.ui.components.StatusBadge
import com.example.ui.screens.owners.DetailRow
import com.example.ui.theme.*
import com.example.util.ActionUtils
import com.example.util.DateUtils
import com.example.util.PdfReportGenerator

@Composable
fun TreatmentHistoryScreen(
    viewModel: MainViewModel,
    onNavigateBack: () -> Unit,
    onTreatmentClick: (Long) -> Unit,
    onAddTreatment: () -> Unit,
    onMonthlySummaryClick: () -> Unit,
    onProfileClick: () -> Unit
) {
    val context = LocalContext.current
    val treatments by viewModel.filteredTreatments.collectAsStateWithLifecycle()
    val allTreatments by viewModel.allTreatments.collectAsStateWithLifecycle()
    val searchQuery by viewModel.treatmentSearchQuery.collectAsStateWithLifecycle()
    val dateFilter by viewModel.treatmentDateFilter.collectAsStateWithLifecycle()
    val speciesFilter by viewModel.treatmentSpeciesFilter.collectAsStateWithLifecycle()
    val sortOrder by viewModel.treatmentSortOrder.collectAsStateWithLifecycle()
    val syncState by viewModel.syncState.collectAsStateWithLifecycle()

    val dateFilterOptions = listOf(
        "Today", "This Week", "This Month", "Last Month", "Last 2 Months", "Last 3 Months", "Last 6 Months", "This Year", "All"
    )
    val speciesOptions = listOf("All", "Cow", "Goat", "Buffalo", "Other")
    val sortOptions = listOf("Newest First", "Oldest First", "Owner Name", "Animal Tag")

    var showExportDialog by remember { mutableStateOf(false) }

    BackHandler { onNavigateBack() }

    if (showExportDialog) {
        AlertDialog(
            onDismissRequest = { showExportDialog = false },
            title = { Text("Export Treatment Report") },
            text = {
                Text("Generate official PDF report or export CSV for the currently filtered ${treatments.size} treatment records ($dateFilter).")
            },
            confirmButton = {
                Button(
                    onClick = {
                        showExportDialog = false
                        val pdfFile = PdfReportGenerator.generateTreatmentReport(
                            context = context,
                            treatments = treatments,
                            reportTitle = "Treatment History Report",
                            periodName = dateFilter
                        )
                        if (pdfFile != null) {
                            PdfReportGenerator.sharePdf(context, pdfFile)
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = VetGreenPrimary)
                ) {
                    Icon(Icons.Default.PictureAsPdf, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Generate PDF")
                }
            },
            dismissButton = {
                TextButton(
                    onClick = {
                        showExportDialog = false
                        val csv = PdfReportGenerator.generateCsvReport(treatments)
                        ActionUtils.shareText(context, csv, "Export Treatment CSV")
                    }
                ) {
                    Text("Share CSV")
                }
            }
        )
    }

    Scaffold(
        topBar = {
            AppHeader(
                title = "Treatment History",
                subtitle = "${treatments.size} Records Found",
                showBack = true,
                onBack = onNavigateBack,
                syncState = syncState,
                onSyncClick = { viewModel.triggerSync() },
                onProfileClick = onProfileClick,
                actions = {
                    IconButton(onClick = onMonthlySummaryClick) {
                        Icon(Icons.Default.Analytics, contentDescription = "Monthly Summary", tint = VetGreenPrimary)
                    }
                    IconButton(onClick = { showExportDialog = true }) {
                        Icon(Icons.Default.Download, contentDescription = "Export Report")
                    }
                }
            )
        },
        floatingActionButton = {
            FloatingActionButton(
                onClick = onAddTreatment,
                containerColor = VetGreenPrimary,
                contentColor = Color.White,
                modifier = Modifier.testTag("add_treatment_fab")
            ) {
                Icon(Icons.Default.Add, contentDescription = "New Visit")
            }
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .background(MaterialTheme.colorScheme.background)
        ) {
            // Search field
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { viewModel.treatmentSearchQuery.value = it },
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 6.dp)
                    .testTag("treatment_search_field"),
                placeholder = { Text("Search by owner, animal tag, problem, village...") },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = "Search") },
                trailingIcon = {
                    if (searchQuery.isNotEmpty()) {
                        IconButton(onClick = { viewModel.treatmentSearchQuery.value = "" }) {
                            Icon(Icons.Default.Clear, contentDescription = "Clear")
                        }
                    }
                },
                singleLine = true,
                shape = RoundedCornerShape(12.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = VetGreenPrimary,
                    unfocusedBorderColor = VetOutline
                )
            )

            // Quick Date Filter (Section 33)
            LazyRow(
                modifier = Modifier.fillMaxWidth(),
                contentPadding = PaddingValues(horizontal = 16.dp, vertical = 2.dp),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                items(dateFilterOptions) { opt ->
                    FilterChip(
                        selected = dateFilter == opt,
                        onClick = { viewModel.treatmentDateFilter.value = opt },
                        label = { Text(opt, fontSize = 12.sp) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = VetGreenPrimary,
                            selectedLabelColor = Color.White
                        )
                    )
                }
            }

            // Species & Sort Row
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 2.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    items(speciesOptions) { sp ->
                        FilterChip(
                            selected = speciesFilter == sp,
                            onClick = { viewModel.treatmentSpeciesFilter.value = sp },
                            label = { Text(sp, fontSize = 11.sp) }
                        )
                    }
                }

                // Clear Filters button if any filter applied
                if (dateFilter != "This Month" || speciesFilter != "All" || searchQuery.isNotEmpty()) {
                    TextButton(
                        onClick = {
                            viewModel.treatmentDateFilter.value = "This Month"
                            viewModel.treatmentSpeciesFilter.value = "All"
                            viewModel.treatmentSearchQuery.value = ""
                        },
                        contentPadding = PaddingValues(horizontal = 8.dp)
                    ) {
                        Text("Reset", color = StatusAlertRed, fontSize = 12.sp)
                    }
                }
            }

            if (treatments.isEmpty()) {
                EmptyView(
                    icon = Icons.Default.MedicalServices,
                    title = "No treatments found for current filter",
                    subtitle = "Try selecting a broader date range or clear search terms.",
                    actionButtonText = "+ New Treatment Visit",
                    onActionClick = onAddTreatment
                )
            } else {
                LazyColumn(
                    contentPadding = PaddingValues(16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    items(treatments, key = { it.id }) { treatment ->
                        TreatmentCardItem(
                            treatment = treatment,
                            onClick = { onTreatmentClick(treatment.id) },
                            onToggleFollowUp = {
                                viewModel.toggleFollowUpCompleted(treatment.id, !treatment.isFollowUpCompleted)
                            }
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun TreatmentCardItem(
    treatment: TreatmentEntity,
    onClick: () -> Unit,
    onToggleFollowUp: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() }
            .testTag("treatment_card_${treatment.id}"),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.CalendarToday,
                        contentDescription = null,
                        tint = VetGreenPrimary,
                        modifier = Modifier.size(15.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = DateUtils.formatDisplayDate(treatment.date),
                        style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold, color = VetGreenPrimary)
                    )
                }

                StatusBadge(
                    text = "${treatment.species} • ${treatment.animalTag}",
                    color = when (treatment.species) {
                        "Cow" -> VetGreenPrimary
                        "Goat" -> VetAmberSecondary
                        else -> Color(0xFF0369A1)
                    },
                    containerColor = when (treatment.species) {
                        "Cow" -> VetGreenContainer
                        "Goat" -> VetAmberContainer
                        else -> Color(0xFFE0F2FE)
                    }
                )
            }

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = "Owner: ${treatment.ownerName} (${treatment.village})",
                style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold)
            )

            Text(
                text = "Problem: ${treatment.problem}",
                style = MaterialTheme.typography.bodyMedium.copy(color = MaterialTheme.colorScheme.onSurface)
            )

            Text(
                text = "Treatment: ${treatment.treatment}",
                style = MaterialTheme.typography.bodySmall.copy(color = Color.DarkGray)
            )

            if (treatment.followUpDate.isNotBlank()) {
                Spacer(modifier = Modifier.height(6.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Follow-up: ${DateUtils.formatDisplayDate(treatment.followUpDate)}",
                        style = MaterialTheme.typography.labelSmall.copy(
                            color = if (treatment.isFollowUpCompleted) VetGreenPrimary else VetAmberSecondary,
                            fontWeight = FontWeight.SemiBold
                        )
                    )

                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.clickable { onToggleFollowUp() }
                    ) {
                        Checkbox(
                            checked = treatment.isFollowUpCompleted,
                            onCheckedChange = { onToggleFollowUp() },
                            modifier = Modifier.size(24.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = if (treatment.isFollowUpCompleted) "Resolved" else "Pending",
                            style = MaterialTheme.typography.labelSmall.copy(fontSize = 11.sp)
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun TreatmentDetailScreen(
    treatmentId: Long,
    viewModel: MainViewModel,
    onNavigateBack: () -> Unit,
    onEditTreatment: (Long) -> Unit,
    onOwnerClick: (Long) -> Unit,
    onAnimalClick: (Long) -> Unit
) {
    val context = LocalContext.current
    val treatments by viewModel.allTreatments.collectAsStateWithLifecycle()
    val treatment = treatments.find { it.id == treatmentId }

    var showDeleteDialog by remember { mutableStateOf(false) }

    BackHandler { onNavigateBack() }

    if (treatment == null) {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Text("Treatment record not found")
        }
        return
    }

    if (showDeleteDialog) {
        AlertDialog(
            onDismissRequest = { showDeleteDialog = false },
            title = { Text("Delete Treatment Visit?") },
            text = { Text("Are you sure you want to delete this treatment record for ${treatment.animalTag}?") },
            confirmButton = {
                TextButton(
                    onClick = {
                        viewModel.deleteTreatment(treatment) {
                            showDeleteDialog = false
                            onNavigateBack()
                        }
                    }
                ) {
                    Text("Delete", color = StatusAlertRed)
                }
            },
            dismissButton = {
                TextButton(onClick = { showDeleteDialog = false }) { Text("Cancel") }
            }
        )
    }

    Scaffold(
        topBar = {
            AppHeader(
                title = "Visit: ${treatment.visitCode}",
                subtitle = "${treatment.animalTag} • ${DateUtils.formatDisplayDate(treatment.date)}",
                showBack = true,
                onBack = onNavigateBack,
                actions = {
                    IconButton(onClick = { onEditTreatment(treatment.id) }) {
                        Icon(Icons.Default.Edit, contentDescription = "Edit")
                    }
                    IconButton(onClick = { showDeleteDialog = true }) {
                        Icon(Icons.Default.Delete, contentDescription = "Delete", tint = StatusAlertRed)
                    }
                }
            )
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .background(MaterialTheme.colorScheme.background),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Main Case Record Card
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(DateUtils.formatDisplayDate(treatment.date), style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold, color = VetGreenPrimary))
                                Text(treatment.time, style = MaterialTheme.typography.bodySmall.copy(color = Color.Gray))
                            }
                            StatusBadge(
                                text = if (treatment.isFollowUpCompleted) "Completed" else "Follow-up Required",
                                color = if (treatment.isFollowUpCompleted) VetGreenPrimary else VetAmberSecondary,
                                containerColor = if (treatment.isFollowUpCompleted) VetGreenContainer else VetAmberContainer
                            )
                        }

                        Spacer(modifier = Modifier.height(14.dp))
                        HorizontalDivider(color = VetOutlineVariant)
                        Spacer(modifier = Modifier.height(12.dp))

                        DetailRow(icon = Icons.Default.Person, label = "Owner", value = "${treatment.ownerName} (${treatment.ownerPhone})")
                        DetailRow(icon = Icons.Default.LocationOn, label = "Village / Area", value = "${treatment.village} • ${treatment.ownerAddress}")
                        DetailRow(icon = Icons.Default.Pets, label = "Animal", value = "${treatment.species} - ${treatment.animalTag} (${treatment.animalName})")
                        DetailRow(icon = Icons.Default.Category, label = "Breed", value = treatment.breed)
                        DetailRow(icon = Icons.Default.Badge, label = "Technician", value = treatment.technicianName)
                    }
                }
            }

            // Clinical & Treatment Details
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text("Clinical Examination & Diagnosis", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold))
                        Spacer(modifier = Modifier.height(10.dp))

                        ClinicalSection(title = "Main Problem", content = treatment.problem)
                        ClinicalSection(title = "Observed Symptoms", content = treatment.symptoms)
                        if (treatment.examination.isNotBlank()) {
                            ClinicalSection(title = "Examination Findings", content = treatment.examination)
                        }
                        if (treatment.diagnosis.isNotBlank()) {
                            ClinicalSection(title = "Diagnosis / Observation", content = treatment.diagnosis)
                        }

                        Spacer(modifier = Modifier.height(10.dp))
                        HorizontalDivider(color = VetOutlineVariant)
                        Spacer(modifier = Modifier.height(10.dp))

                        Text("Treatment & Prescription", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold, color = VetGreenPrimary))
                        Spacer(modifier = Modifier.height(8.dp))

                        ClinicalSection(title = "Treatment Given", content = treatment.treatment)
                        ClinicalSection(title = "Medicine Information & Dosages", content = treatment.medicineInfo)
                        if (treatment.advice.isNotBlank()) {
                            ClinicalSection(title = "Farmer Advice & Feeding Guidelines", content = treatment.advice)
                        }
                        if (treatment.followUpDate.isNotBlank()) {
                            ClinicalSection(
                                title = "Follow-up Date",
                                content = "${DateUtils.formatDisplayDate(treatment.followUpDate)} (${if (treatment.isFollowUpCompleted) "Completed" else "Pending"})"
                            )
                        }
                    }
                }
            }

            // Action Buttons: Print/PDF, Share, Call Owner
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Button(
                        onClick = {
                            val pdf = PdfReportGenerator.generateTreatmentReport(
                                context = context,
                                treatments = listOf(treatment),
                                reportTitle = "Official Veterinary Case Prescription",
                                periodName = treatment.date
                            )
                            if (pdf != null) PdfReportGenerator.sharePdf(context, pdf)
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = VetGreenPrimary),
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Icon(Icons.Default.PictureAsPdf, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Print / PDF")
                    }

                    OutlinedButton(
                        onClick = {
                            val shareBody = """
                                *RABBY ANIMALS OFFICIAL - CASE RECORD*
                                Date: ${treatment.date}
                                Owner: ${treatment.ownerName} (${treatment.ownerPhone})
                                Animal: ${treatment.species} ${treatment.animalTag} (${treatment.animalName})
                                Problem: ${treatment.problem}
                                Treatment: ${treatment.treatment}
                                Medicine: ${treatment.medicineInfo}
                                Follow-up: ${treatment.followUpDate}
                                Technician: ${treatment.technicianName}
                            """.trimIndent()
                            ActionUtils.shareText(context, shareBody, "Share Case Record")
                        },
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Icon(Icons.Default.Share, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Share")
                    }
                }
            }
        }
    }
}

@Composable
fun AddEditTreatmentScreen(
    treatmentId: Long? = null,
    preselectedOwnerId: Long? = null,
    preselectedAnimalId: Long? = null,
    viewModel: MainViewModel,
    onNavigateBack: () -> Unit,
    onSaved: (Long) -> Unit
) {
    val treatments by viewModel.allTreatments.collectAsStateWithLifecycle()
    val owners by viewModel.allOwners.collectAsStateWithLifecycle()
    val animals by viewModel.allAnimals.collectAsStateWithLifecycle()
    val existing = treatments.find { it.id == treatmentId }

    var selectedOwnerId by remember { mutableStateOf(existing?.ownerId ?: preselectedOwnerId ?: (owners.firstOrNull()?.id ?: 0L)) }
    val availableAnimalsForOwner = animals.filter { it.ownerId == selectedOwnerId }
    var selectedAnimalId by remember { mutableStateOf(existing?.animalId ?: preselectedAnimalId ?: (availableAnimalsForOwner.firstOrNull()?.id ?: 0L)) }

    var date by remember { mutableStateOf(existing?.date ?: DateUtils.getTodayIso()) }
    var time by remember { mutableStateOf(existing?.time ?: DateUtils.getCurrentTime()) }
    var problem by remember { mutableStateOf(existing?.problem ?: "") }
    var symptoms by remember { mutableStateOf(existing?.symptoms ?: "") }
    var examination by remember { mutableStateOf(existing?.examination ?: "") }
    var diagnosis by remember { mutableStateOf(existing?.diagnosis ?: "") }
    var treatmentText by remember { mutableStateOf(existing?.treatment ?: "") }
    var medicineInfo by remember { mutableStateOf(existing?.medicineInfo ?: "") }
    var advice by remember { mutableStateOf(existing?.advice ?: "") }
    var followUpDate by remember { mutableStateOf(existing?.followUpDate ?: DateUtils.addDaysToDate(date, 3)) }
    var isFollowUpCompleted by remember { mutableStateOf(existing?.isFollowUpCompleted ?: false) }

    var errorMessage by remember { mutableStateOf<String?>(null) }

    BackHandler { onNavigateBack() }

    Scaffold(
        topBar = {
            AppHeader(
                title = if (existing == null) "New Veterinary Visit" else "Edit Visit Record",
                showBack = true,
                onBack = onNavigateBack
            )
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .background(MaterialTheme.colorScheme.background),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            if (errorMessage != null) {
                item {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = Color(0xFFFFEBEE)),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Text(
                            text = errorMessage ?: "",
                            color = StatusAlertRed,
                            modifier = Modifier.padding(12.dp)
                        )
                    }
                }
            }

            // Step 1: Owner Picker
            item {
                Text("1. Select Owner *", style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold))
                Spacer(modifier = Modifier.height(4.dp))
                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(owners) { owner ->
                        FilterChip(
                            selected = selectedOwnerId == owner.id,
                            onClick = {
                                selectedOwnerId = owner.id
                                val matching = animals.filter { it.ownerId == owner.id }
                                if (matching.isNotEmpty()) selectedAnimalId = matching.first().id
                            },
                            label = { Text("${owner.name} (${owner.village})") }
                        )
                    }
                }
            }

            // Step 2: Animal Picker for selected owner
            item {
                Text("2. Select Animal *", style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold))
                Spacer(modifier = Modifier.height(4.dp))
                if (availableAnimalsForOwner.isEmpty()) {
                    Text("No animals found for this owner. Please register an animal first.", color = Color.Gray, fontSize = 12.sp)
                } else {
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(availableAnimalsForOwner) { animal ->
                            FilterChip(
                                selected = selectedAnimalId == animal.id,
                                onClick = { selectedAnimalId = animal.id },
                                label = { Text("${animal.species} • ${animal.tagNumber} (${animal.name})") }
                            )
                        }
                    }
                }
            }

            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    OutlinedTextField(
                        value = date,
                        onValueChange = { date = it },
                        label = { Text("Visit Date (yyyy-MM-dd)") },
                        modifier = Modifier.weight(1f),
                        singleLine = true
                    )
                    OutlinedTextField(
                        value = time,
                        onValueChange = { time = it },
                        label = { Text("Time") },
                        modifier = Modifier.weight(1f),
                        singleLine = true
                    )
                }
            }

            item {
                OutlinedTextField(
                    value = problem,
                    onValueChange = { problem = it; errorMessage = null },
                    label = { Text("Main Problem / Reason for Visit *") },
                    placeholder = { Text("e.g. Loss of appetite, milk drop, foot rot, fever") },
                    modifier = Modifier.fillMaxWidth().testTag("treatment_problem_input"),
                    minLines = 2
                )
            }

            item {
                OutlinedTextField(
                    value = symptoms,
                    onValueChange = { symptoms = it },
                    label = { Text("Observed Symptoms") },
                    placeholder = { Text("e.g. High fever 104°F, nasal discharge, sluggish rumination") },
                    modifier = Modifier.fillMaxWidth(),
                    minLines = 2
                )
            }

            item {
                OutlinedTextField(
                    value = examination,
                    onValueChange = { examination = it },
                    label = { Text("Clinical Examination / Findings") },
                    placeholder = { Text("e.g. Temperature, pulse, auscultation, lymph node inspection") },
                    modifier = Modifier.fillMaxWidth(),
                    minLines = 2
                )
            }

            item {
                OutlinedTextField(
                    value = treatmentText,
                    onValueChange = { treatmentText = it; errorMessage = null },
                    label = { Text("Treatment Given *") },
                    placeholder = { Text("e.g. Antipyretic injection, fluid therapy, dressing") },
                    modifier = Modifier.fillMaxWidth().testTag("treatment_given_input"),
                    minLines = 2
                )
            }

            item {
                OutlinedTextField(
                    value = medicineInfo,
                    onValueChange = { medicineInfo = it },
                    label = { Text("Medicine Information & Prescription") },
                    placeholder = { Text("e.g. Inj. Astavet 2ml IM, Bolus Digevet 2 BID x 3 days") },
                    modifier = Modifier.fillMaxWidth(),
                    minLines = 2
                )
            }

            item {
                OutlinedTextField(
                    value = advice,
                    onValueChange = { advice = it },
                    label = { Text("Farmer Advice / Feeding Guidelines") },
                    placeholder = { Text("e.g. Keep in dry shelter, give clean lukewarm water") },
                    modifier = Modifier.fillMaxWidth(),
                    minLines = 2
                )
            }

            item {
                OutlinedTextField(
                    value = followUpDate,
                    onValueChange = { followUpDate = it },
                    label = { Text("Follow-up Date (yyyy-MM-dd)") },
                    placeholder = { Text("e.g. 2026-10-05") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )
            }

            item {
                Spacer(modifier = Modifier.height(10.dp))
                Button(
                    onClick = {
                        val owner = owners.find { it.id == selectedOwnerId }
                        val animal = animals.find { it.id == selectedAnimalId }
                        if (owner == null) {
                            errorMessage = "Please select an owner"
                            return@Button
                        }
                        if (animal == null) {
                            errorMessage = "Please select an animal"
                            return@Button
                        }
                        if (problem.isBlank()) {
                            errorMessage = "Please enter the main problem"
                            return@Button
                        }
                        if (treatmentText.isBlank()) {
                            errorMessage = "Please describe the treatment given"
                            return@Button
                        }

                        if (existing != null) {
                            val updated = existing.copy(
                                date = date,
                                time = time,
                                ownerId = owner.id,
                                ownerName = owner.name,
                                ownerPhone = owner.phone,
                                ownerAddress = owner.address,
                                village = owner.village,
                                animalId = animal.id,
                                animalTag = animal.tagNumber,
                                animalName = animal.name,
                                species = animal.species,
                                breed = animal.breed,
                                problem = problem.trim(),
                                symptoms = symptoms.trim(),
                                examination = examination.trim(),
                                diagnosis = diagnosis.trim(),
                                treatment = treatmentText.trim(),
                                medicineInfo = medicineInfo.trim(),
                                advice = advice.trim(),
                                followUpDate = followUpDate.trim(),
                                isFollowUpCompleted = isFollowUpCompleted
                            )
                            viewModel.updateTreatment(updated) {
                                onSaved(updated.id)
                            }
                        } else {
                            val code = "VIS-${(100..999).random()}"
                            val newTreatment = TreatmentEntity(
                                visitCode = code,
                                date = date,
                                time = time,
                                ownerId = owner.id,
                                ownerName = owner.name,
                                ownerPhone = owner.phone,
                                ownerAddress = owner.address,
                                village = owner.village,
                                animalId = animal.id,
                                animalTag = animal.tagNumber,
                                animalName = animal.name,
                                species = animal.species,
                                breed = animal.breed,
                                problem = problem.trim(),
                                symptoms = symptoms.trim(),
                                examination = examination.trim(),
                                diagnosis = diagnosis.trim(),
                                treatment = treatmentText.trim(),
                                medicineInfo = medicineInfo.trim(),
                                advice = advice.trim(),
                                followUpDate = followUpDate.trim(),
                                technicianName = "Md. Shah Walimullah Rabby"
                            )
                            viewModel.addTreatment(newTreatment) { id ->
                                onSaved(id)
                            }
                        }
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(50.dp)
                        .testTag("save_treatment_button"),
                    colors = ButtonDefaults.buttonColors(containerColor = VetGreenPrimary),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Icon(Icons.Default.Save, contentDescription = null)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Save Treatment Record", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                }
            }
        }
    }
}

@Composable
fun MonthlySummaryScreen(
    viewModel: MainViewModel,
    onNavigateBack: () -> Unit,
    onNavigateToHistory: () -> Unit
) {
    val context = LocalContext.current
    val allTreatments by viewModel.allTreatments.collectAsStateWithLifecycle()

    var selectedPeriodOffset by remember { mutableIntStateOf(0) } // 0 = This Month, -1 = Last Month, -2 = 2 Mo, -3 = 3 Mo
    val periodLabels = listOf("Current Month", "Previous Month", "2 Months Ago", "3 Months Ago")

    val startOfSelectedMonth = DateUtils.getStartOfMonth(selectedPeriodOffset)
    val endOfSelectedMonth = DateUtils.getEndOfMonth(selectedPeriodOffset)
    val currentMonthName = DateUtils.getMonthName(selectedPeriodOffset)

    val periodTreatments = allTreatments.filter {
        it.date in startOfSelectedMonth..endOfSelectedMonth
    }

    val totalVisits = periodTreatments.size
    val totalAnimalsTreated = periodTreatments.map { it.animalId }.distinct().size
    val totalOwnersServed = periodTreatments.map { it.ownerId }.distinct().size
    val cowCount = periodTreatments.count { it.species.equals("Cow", ignoreCase = true) }
    val goatCount = periodTreatments.count { it.species.equals("Goat", ignoreCase = true) }
    val buffaloCount = periodTreatments.count { it.species.equals("Buffalo", ignoreCase = true) }
    val otherCount = totalVisits - (cowCount + goatCount + buffaloCount)
    val followUpsCompleted = periodTreatments.count { it.isFollowUpCompleted }
    val followUpsPending = periodTreatments.count { !it.isFollowUpCompleted && it.followUpDate.isNotBlank() }

    BackHandler { onNavigateBack() }

    Scaffold(
        topBar = {
            AppHeader(
                title = "Monthly Treatment Summary",
                subtitle = currentMonthName,
                showBack = true,
                onBack = onNavigateBack,
                actions = {
                    IconButton(
                        onClick = {
                            val pdf = PdfReportGenerator.generateTreatmentReport(
                                context = context,
                                treatments = periodTreatments,
                                reportTitle = "Monthly Veterinary Service Summary - $currentMonthName",
                                periodName = currentMonthName
                            )
                            if (pdf != null) PdfReportGenerator.sharePdf(context, pdf)
                        }
                    ) {
                        Icon(Icons.Default.PictureAsPdf, contentDescription = "PDF Report", tint = VetGreenPrimary)
                    }
                }
            )
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .background(MaterialTheme.colorScheme.background),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Period selector tabs
            item {
                ScrollableTabRow(selectedTabIndex = selectedPeriodOffset * -1, edgePadding = 0.dp) {
                    periodLabels.forEachIndexed { idx, label ->
                        Tab(
                            selected = selectedPeriodOffset == -idx,
                            onClick = { selectedPeriodOffset = -idx },
                            text = { Text(label, fontWeight = if (selectedPeriodOffset == -idx) FontWeight.Bold else FontWeight.Normal) }
                        )
                    }
                }
            }

            // Summary Card (Section 33 example style)
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                ) {
                    Column(modifier = Modifier.padding(18.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = currentMonthName,
                                style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold, color = VetGreenPrimary)
                            )
                            StatusBadge(text = "$totalVisits Visits")
                        }

                        Spacer(modifier = Modifier.height(14.dp))
                        HorizontalDivider(color = VetOutlineVariant)
                        Spacer(modifier = Modifier.height(14.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            MetricStatCard(
                                title = "Animals Treated",
                                count = totalAnimalsTreated.toString(),
                                icon = Icons.Default.Pets,
                                containerColor = VetGreenContainer,
                                contentColor = VetGreenPrimary,
                                modifier = Modifier.weight(1f)
                            )
                            MetricStatCard(
                                title = "Owners Served",
                                count = totalOwnersServed.toString(),
                                icon = Icons.Default.People,
                                containerColor = VetAmberContainer,
                                contentColor = VetAmberSecondary,
                                modifier = Modifier.weight(1f)
                            )
                        }

                        Spacer(modifier = Modifier.height(14.dp))

                        Text("Species Breakdown", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold))
                        Spacer(modifier = Modifier.height(8.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            SpeciesPill("Cow Treatments", cowCount.toString(), VetGreenPrimary)
                            SpeciesPill("Goat Treatments", goatCount.toString(), VetAmberSecondary)
                            SpeciesPill("Buffalo", buffaloCount.toString(), Color(0xFF0369A1))
                            if (otherCount > 0) SpeciesPill("Other", otherCount.toString(), Color.Gray)
                        }

                        Spacer(modifier = Modifier.height(14.dp))
                        HorizontalDivider(color = VetOutlineVariant)
                        Spacer(modifier = Modifier.height(14.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column {
                                Text("Follow-ups Completed", style = MaterialTheme.typography.bodySmall.copy(color = Color.Gray))
                                Text(followUpsCompleted.toString(), style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold, color = VetGreenPrimary))
                            }
                            Column(horizontalAlignment = Alignment.End) {
                                Text("Follow-ups Pending", style = MaterialTheme.typography.bodySmall.copy(color = Color.Gray))
                                Text(followUpsPending.toString(), style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold, color = StatusAlertRed))
                            }
                        }

                        Spacer(modifier = Modifier.height(16.dp))

                        Button(
                            onClick = {
                                val pdf = PdfReportGenerator.generateTreatmentReport(
                                    context = context,
                                    treatments = periodTreatments,
                                    reportTitle = "Monthly Veterinary Service Summary - $currentMonthName",
                                    periodName = currentMonthName
                                )
                                if (pdf != null) PdfReportGenerator.sharePdf(context, pdf)
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = VetGreenPrimary),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Icon(Icons.Default.PictureAsPdf, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Download / Print PDF Report", fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }

            // Treatments in this period
            item {
                Text(
                    text = "Treatments in $currentMonthName (${periodTreatments.size})",
                    style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold)
                )
            }

            if (periodTreatments.isEmpty()) {
                item {
                    Text("No records recorded in this period.", color = Color.Gray, modifier = Modifier.padding(8.dp))
                }
            } else {
                items(periodTreatments) { t ->
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text("${t.species}: ${t.animalTag}", fontWeight = FontWeight.Bold)
                                Text(t.date, color = Color.Gray, style = MaterialTheme.typography.bodySmall)
                            }
                            Text("Owner: ${t.ownerName} • ${t.problem}", style = MaterialTheme.typography.bodyMedium)
                            Text("Rx: ${t.treatment}", style = MaterialTheme.typography.bodySmall.copy(color = Color.DarkGray))
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun SpeciesPill(title: String, count: String, color: Color) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier
            .clip(RoundedCornerShape(8.dp))
            .background(color.copy(alpha = 0.1f))
            .padding(horizontal = 10.dp, vertical = 6.dp)
    ) {
        Text(title, style = MaterialTheme.typography.labelSmall.copy(fontSize = 10.sp, color = color))
        Text(count, style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold, color = color))
    }
}

@Composable
fun ClinicalSection(title: String, content: String) {
    Column(modifier = Modifier.padding(vertical = 4.dp)) {
        Text(title, style = MaterialTheme.typography.labelMedium.copy(color = Color.Gray, fontWeight = FontWeight.SemiBold))
        Text(content, style = MaterialTheme.typography.bodyMedium)
    }
}
