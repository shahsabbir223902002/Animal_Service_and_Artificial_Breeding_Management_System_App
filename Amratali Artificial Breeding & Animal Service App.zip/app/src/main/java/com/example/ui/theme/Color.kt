package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Primary Agriculture / Veterinary Emerald Green
val VetGreenPrimary = Color(0xFF1B5E20)
val VetGreenOnPrimary = Color(0xFFFFFFFF)
val VetGreenContainer = Color(0xFFD8F3DC)
val VetGreenOnContainer = Color(0xFF082B0E)

// Secondary Warm Amber / Livestock Care
val VetAmberSecondary = Color(0xFFB45309)
val VetAmberOnSecondary = Color(0xFFFFFFFF)
val VetAmberContainer = Color(0xFFFEF3C7)
val VetAmberOnContainer = Color(0xFF451A03)

// Tertiary Teal Accent
val VetTealTertiary = Color(0xFF00695C)
val VetTealOnTertiary = Color(0xFFFFFFFF)
val VetTealContainer = Color(0xFFB2DFDB)
val VetTealOnContainer = Color(0xFF00201A)

// Surfaces & Backgrounds (Clean, Professional White & Light Mint-Grey)
val VetBackground = Color(0xFFF8FAF8)
val VetOnBackground = Color(0xFF191C1A)
val VetSurface = Color(0xFFFFFFFF)
val VetOnSurface = Color(0xFF191C1A)
val VetSurfaceVariant = Color(0xFFEDF4EE)
val VetOnSurfaceVariant = Color(0xFF414942)
val VetOutline = Color(0xFFC2CCC4)
val VetOutlineVariant = Color(0xFFE0E5E1)

// Dark Theme Variants
val VetGreenPrimaryDark = Color(0xFF72D98D)
val VetGreenContainerDark = Color(0xFF00531D)
val VetBackgroundDark = Color(0xFF111412)
val VetSurfaceDark = Color(0xFF191C1A)
val VetOnSurfaceDark = Color(0xFFE1E3DF)

// Status colors
val StatusActiveGreen = Color(0xFF2E7D32)
val StatusPendingAmber = Color(0xFFF57F17)
val StatusAlertRed = Color(0xFFD32F2F)
val StatusBlueInfo = Color(0xFF0288D1)
