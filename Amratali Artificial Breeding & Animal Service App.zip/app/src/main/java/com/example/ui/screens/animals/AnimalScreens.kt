package com.example.ui.screens.animals

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.entity.AnimalEntity
import com.example.ui.MainViewModel
import com.example.ui.components.AppHeader
import com.example.ui.components.EmptyView
import com.example.ui.components.StatusBadge
import com.example.ui.screens.owners.DetailRow
import com.example.ui.theme.*
import com.example.util.DateUtils

@Composable
fun AnimalListScreen(
    viewModel: MainViewModel,
    onNavigateBack: () -> Unit,
    onAnimalClick: (Long) -> Unit,
    onAddAnimal: () -> Unit,
    onProfileClick: () -> Unit
) {
    val animals by viewModel.filteredAnimals.collectAsStateWithLifecycle()
    val searchQuery by viewModel.animalSearchQuery.collectAsStateWithLifecycle()
    val selectedSpecies by viewModel.animalSpeciesFilter.collectAsStateWithLifecycle()
    val syncState by viewModel.syncState.collectAsStateWithLifecycle()

    val speciesOptions = listOf("All", "Cow", "Goat", "Buffalo", "Other")

    BackHandler { onNavigateBack() }

    Scaffold(
        topBar = {
            AppHeader(
                title = "Animals & Livestock",
                subtitle = "${animals.size} Animals Registered",
                showBack = true,
                onBack = onNavigateBack,
                syncState = syncState,
                onSyncClick = { viewModel.triggerSync() },
                onProfileClick = onProfileClick
            )
        },
        floatingActionButton = {
            FloatingActionButton(
                onClick = onAddAnimal,
                containerColor = VetGreenPrimary,
                contentColor = Color.White,
                modifier = Modifier.testTag("add_animal_fab")
            ) {
                Icon(Icons.Default.Add, contentDescription = "Add Animal")
            }
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .background(MaterialTheme.colorScheme.background)
        ) {
            // Search Input
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { viewModel.animalSearchQuery.value = it },
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 6.dp)
                    .testTag("animal_search_field"),
                placeholder = { Text("Search by Tag Number, Name, Breed, Owner...") },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = "Search") },
                trailingIcon = {
                    if (searchQuery.isNotEmpty()) {
                        IconButton(onClick = { viewModel.animalSearchQuery.value = "" }) {
                            Icon(Icons.Default.Clear, contentDescription = "Clear")
                        }
                    }
                },
                singleLine = true,
                shape = RoundedCornerShape(12.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = VetGreenPrimary,
                    unfocusedBorderColor = VetOutline
                )
            )

            // Species Filter Chips
            LazyRow(
                modifier = Modifier.fillMaxWidth(),
                contentPadding = PaddingValues(horizontal = 16.dp, vertical = 4.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(speciesOptions) { species ->
                    FilterChip(
                        selected = selectedSpecies == species,
                        onClick = { viewModel.animalSpeciesFilter.value = species },
                        label = { Text(species) },
                        leadingIcon = if (selectedSpecies == species) {
                            { Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(16.dp)) }
                        } else null,
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = VetGreenContainer,
                            selectedLabelColor = VetGreenOnContainer
                        )
                    )
                }
            }

            if (animals.isEmpty()) {
                EmptyView(
                    icon = Icons.Default.Pets,
                    title = if (searchQuery.isNotBlank() || selectedSpecies != "All") "No matching animals found" else "No Animals Registered",
                    subtitle = "Add animals and link them to their owners for treatment and AI records.",
                    actionButtonText = "+ Add Animal",
                    onActionClick = onAddAnimal
                )
            } else {
                LazyColumn(
                    contentPadding = PaddingValues(16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    items(animals, key = { it.id }) { animal ->
                        AnimalCardItem(
                            animal = animal,
                            onClick = { onAnimalClick(animal.id) }
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun AnimalCardItem(
    animal: AnimalEntity,
    onClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() }
            .testTag("animal_card_${animal.id}"),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(48.dp)
                    .clip(CircleShape)
                    .background(
                        when (animal.species) {
                            "Cow" -> VetGreenContainer
                            "Goat" -> VetAmberContainer
                            "Buffalo" -> Color(0xFFE2E8F0)
                            else -> Color(0xFFF1F5F9)
                        }
                    ),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.Pets,
                    contentDescription = animal.species,
                    tint = when (animal.species) {
                        "Cow" -> VetGreenPrimary
                        "Goat" -> VetAmberSecondary
                        "Buffalo" -> Color(0xFF334155)
                        else -> Color.DarkGray
                    },
                    modifier = Modifier.size(24.dp)
                )
            }

            Spacer(modifier = Modifier.width(14.dp))

            Column(modifier = Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = "${animal.species} • ${animal.tagNumber}",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                    )
                }
                Text(
                    text = "${animal.name} (${animal.breed})",
                    style = MaterialTheme.typography.bodyMedium.copy(color = MaterialTheme.colorScheme.onSurface)
                )
                Text(
                    text = "Owner: ${animal.ownerName} • Age: ${animal.age}",
                    style = MaterialTheme.typography.bodySmall.copy(color = Color.Gray)
                )
            }

            Column(horizontalAlignment = Alignment.End) {
                StatusBadge(
                    text = animal.healthStatus,
                    color = when (animal.healthStatus) {
                        "Healthy" -> VetGreenPrimary
                        "Under Treatment" -> StatusAlertRed
                        "Critical" -> StatusAlertRed
                        else -> StatusBlueInfo
                    },
                    containerColor = when (animal.healthStatus) {
                        "Healthy" -> VetGreenContainer
                        "Under Treatment" -> Color(0xFFFFEBEE)
                        "Critical" -> Color(0xFFFFEBEE)
                        else -> Color(0xFFE0F2FE)
                    }
                )
                if (animal.pregnancyStatus.contains("Pregnant")) {
                    Spacer(modifier = Modifier.height(4.dp))
                    StatusBadge(
                        text = animal.pregnancyStatus,
                        color = VetAmberSecondary,
                        containerColor = VetAmberContainer
                    )
                }
            }
        }
    }
}

@Composable
fun AnimalDetailScreen(
    animalId: Long,
    viewModel: MainViewModel,
    onNavigateBack: () -> Unit,
    onEditAnimal: (Long) -> Unit,
    onOwnerClick: (Long) -> Unit,
    onAddTreatment: (animalId: Long, ownerId: Long) -> Unit,
    onAddAI: (animalId: Long) -> Unit,
    onTreatmentClick: (Long) -> Unit
) {
    val animals by viewModel.allAnimals.collectAsStateWithLifecycle()
    val animal = animals.find { it.id == animalId }
    val allTreatments by viewModel.allTreatments.collectAsStateWithLifecycle()
    val allAIRecords by viewModel.allAIRecords.collectAsStateWithLifecycle()
    val allVaccinations by viewModel.allVaccinations.collectAsStateWithLifecycle()
    val allDewormings by viewModel.allDewormings.collectAsStateWithLifecycle()

    val treatments = allTreatments.filter { it.animalId == animalId }
    val aiRecords = allAIRecords.filter { it.animalId == animalId }
    val vaccinations = allVaccinations.filter { it.animalId == animalId }
    val dewormings = allDewormings.filter { it.animalId == animalId }

    var selectedTab by remember { mutableIntStateOf(0) }
    val tabs = listOf(
        "Overview",
        "Treatments (${treatments.size})",
        "AI (${aiRecords.size})",
        "Vaccines (${vaccinations.size})",
        "Deworming (${dewormings.size})"
    )

    var showDeleteDialog by remember { mutableStateOf(false) }

    BackHandler { onNavigateBack() }

    if (animal == null) {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Text("Animal not found")
        }
        return
    }

    if (showDeleteDialog) {
        AlertDialog(
            onDismissRequest = { showDeleteDialog = false },
            title = { Text("Delete Animal?") },
            text = { Text("Are you sure you want to remove animal ${animal.tagNumber} (${animal.name})?") },
            confirmButton = {
                TextButton(
                    onClick = {
                        viewModel.deleteAnimal(animal) {
                            showDeleteDialog = false
                            onNavigateBack()
                        }
                    }
                ) {
                    Text("Delete", color = StatusAlertRed)
                }
            },
            dismissButton = {
                TextButton(onClick = { showDeleteDialog = false }) { Text("Cancel") }
            }
        )
    }

    Scaffold(
        topBar = {
            AppHeader(
                title = "${animal.species}: ${animal.tagNumber}",
                subtitle = "${animal.name} • ${animal.ownerName}",
                showBack = true,
                onBack = onNavigateBack,
                actions = {
                    IconButton(onClick = { onEditAnimal(animal.id) }) {
                        Icon(Icons.Default.Edit, contentDescription = "Edit")
                    }
                    IconButton(onClick = { showDeleteDialog = true }) {
                        Icon(Icons.Default.Delete, contentDescription = "Delete", tint = StatusAlertRed)
                    }
                }
            )
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .background(MaterialTheme.colorScheme.background),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Profile Header Card
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(56.dp)
                                    .clip(CircleShape)
                                    .background(VetGreenContainer),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(Icons.Default.Pets, contentDescription = null, tint = VetGreenPrimary, modifier = Modifier.size(32.dp))
                            }
                            Spacer(modifier = Modifier.width(14.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "${animal.name} (${animal.tagNumber})",
                                    style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold)
                                )
                                Text(
                                    text = "${animal.species} • ${animal.breed} • ${animal.gender}",
                                    style = MaterialTheme.typography.bodyMedium.copy(color = MaterialTheme.colorScheme.onSurfaceVariant)
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(14.dp))
                        HorizontalDivider(color = VetOutlineVariant)
                        Spacer(modifier = Modifier.height(12.dp))

                        DetailRow(icon = Icons.Default.Person, label = "Owner", value = animal.ownerName)
                        DetailRow(icon = Icons.Default.CalendarToday, label = "Age", value = animal.age)
                        if (animal.weight.isNotBlank()) {
                            DetailRow(icon = Icons.Default.FitnessCenter, label = "Weight", value = animal.weight)
                        }
                        DetailRow(icon = Icons.Default.Palette, label = "Color", value = animal.color)
                        DetailRow(icon = Icons.Default.HealthAndSafety, label = "Health Status", value = animal.healthStatus)
                        DetailRow(icon = Icons.Default.ChildCare, label = "Pregnancy Status", value = animal.pregnancyStatus)
                        if (animal.notes.isNotBlank()) {
                            DetailRow(icon = Icons.Default.Notes, label = "Notes", value = animal.notes)
                        }

                        Spacer(modifier = Modifier.height(14.dp))

                        // Quick action buttons for this animal
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Button(
                                onClick = { onAddTreatment(animal.id, animal.ownerId) },
                                colors = ButtonDefaults.buttonColors(containerColor = VetGreenPrimary),
                                shape = RoundedCornerShape(10.dp),
                                modifier = Modifier.weight(1f)
                            ) {
                                Icon(Icons.Default.MedicalServices, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("+ Visit", fontSize = 12.sp)
                            }
                            FilledTonalButton(
                                onClick = { onAddAI(animal.id) },
                                colors = ButtonDefaults.filledTonalButtonColors(containerColor = Color(0xFFF3E8FF)),
                                shape = RoundedCornerShape(10.dp),
                                modifier = Modifier.weight(1f)
                            ) {
                                Icon(Icons.Default.Biotech, contentDescription = null, tint = Color(0xFF7E22CE), modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("+ AI", color = Color(0xFF7E22CE), fontSize = 12.sp)
                            }
                            OutlinedButton(
                                onClick = { onOwnerClick(animal.ownerId) },
                                shape = RoundedCornerShape(10.dp),
                                modifier = Modifier.weight(1f)
                            ) {
                                Text("Owner", fontSize = 12.sp)
                            }
                        }
                    }
                }
            }

            // Tabs for Complete Chronological History
            item {
                ScrollableTabRow(selectedTabIndex = selectedTab, edgePadding = 0.dp) {
                    tabs.forEachIndexed { index, title ->
                        Tab(
                            selected = selectedTab == index,
                            onClick = { selectedTab = index },
                            text = { Text(title, fontWeight = if (selectedTab == index) FontWeight.Bold else FontWeight.Normal) }
                        )
                    }
                }
            }

            when (selectedTab) {
                0 -> {
                    // Overview Summary
                    item {
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(12.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                        ) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                Text("Medical & Breeding Summary", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                                Spacer(modifier = Modifier.height(10.dp))
                                Text("Total Treatment Visits: ${treatments.size}")
                                Text("Artificial Insemination Count: ${aiRecords.size}")
                                Text("Vaccinations Recorded: ${vaccinations.size}")
                                Text("Deworming Cycles: ${dewormings.size}")
                            }
                        }
                    }
                }
                1 -> {
                    // Treatments
                    if (treatments.isEmpty()) {
                        item {
                            EmptyView(
                                icon = Icons.Default.MedicalServices,
                                title = "No medical history recorded",
                                actionButtonText = "+ Add First Visit",
                                onActionClick = { onAddTreatment(animal.id, animal.ownerId) }
                            )
                        }
                    } else {
                        items(treatments) { treatment ->
                            Card(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable { onTreatmentClick(treatment.id) },
                                shape = RoundedCornerShape(12.dp),
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                            ) {
                                Column(modifier = Modifier.padding(14.dp)) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Text(DateUtils.formatDisplayDate(treatment.date), fontWeight = FontWeight.Bold, color = VetGreenPrimary)
                                        StatusBadge(text = if (treatment.isFollowUpCompleted) "Completed" else "Follow-up Pending")
                                    }
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text("Problem: ${treatment.problem}", fontWeight = FontWeight.SemiBold)
                                    Text("Treatment: ${treatment.treatment}", style = MaterialTheme.typography.bodySmall.copy(color = Color.DarkGray))
                                    if (treatment.medicineInfo.isNotBlank()) {
                                        Text("Medicine: ${treatment.medicineInfo}", style = MaterialTheme.typography.bodySmall.copy(color = Color.Gray))
                                    }
                                }
                            }
                        }
                    }
                }
                2 -> {
                    // AI Records
                    if (aiRecords.isEmpty()) {
                        item {
                            EmptyView(
                                icon = Icons.Default.Biotech,
                                title = "No Artificial Insemination records",
                                actionButtonText = "+ Record AI Service",
                                onActionClick = { onAddAI(animal.id) }
                            )
                        }
                    } else {
                        items(aiRecords) { ai ->
                            Card(
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(12.dp),
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                            ) {
                                Column(modifier = Modifier.padding(14.dp)) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Text("Date: ${DateUtils.formatDisplayDate(ai.aiDate)}", fontWeight = FontWeight.Bold)
                                        StatusBadge(text = ai.status, color = Color(0xFF7E22CE), containerColor = Color(0xFFF3E8FF))
                                    }
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text("Breed: ${ai.breed} • Bull: ${ai.semenBullInfo}", fontWeight = FontWeight.Medium)
                                    Text("Expected Pregnancy Check: ${DateUtils.formatDisplayDate(ai.expectedPregnancyCheckDate)}", style = MaterialTheme.typography.bodySmall.copy(color = VetAmberSecondary))
                                    if (ai.expectedCalvingDate.isNotBlank()) {
                                        Text("Expected Calving: ${DateUtils.formatDisplayDate(ai.expectedCalvingDate)}", style = MaterialTheme.typography.bodySmall.copy(color = VetGreenPrimary))
                                    }
                                }
                            }
                        }
                    }
                }
                3 -> {
                    // Vaccinations
                    if (vaccinations.isEmpty()) {
                        item {
                            EmptyView(
                                icon = Icons.Default.Vaccines,
                                title = "No vaccination records"
                            )
                        }
                    } else {
                        items(vaccinations) { v ->
                            Card(
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(12.dp),
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                            ) {
                                Column(modifier = Modifier.padding(14.dp)) {
                                    Text(v.vaccineName, fontWeight = FontWeight.Bold, color = VetGreenPrimary)
                                    Text("Given: ${v.dateGiven} • Next Due: ${v.nextDueDate}")
                                    if (v.notes.isNotBlank()) {
                                        Text("Notes: ${v.notes}", style = MaterialTheme.typography.bodySmall.copy(color = Color.Gray))
                                    }
                                }
                            }
                        }
                    }
                }
                4 -> {
                    // Dewormings
                    if (dewormings.isEmpty()) {
                        item {
                            EmptyView(
                                icon = Icons.Default.Sanitizer,
                                title = "No deworming records"
                            )
                        }
                    } else {
                        items(dewormings) { d ->
                            Card(
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(12.dp),
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                            ) {
                                Column(modifier = Modifier.padding(14.dp)) {
                                    Text(d.productName, fontWeight = FontWeight.Bold, color = VetAmberSecondary)
                                    Text("Administered: ${d.dateGiven} • Next Due: ${d.nextDueDate}")
                                    if (d.doseInfo.isNotBlank()) {
                                        Text("Dose: ${d.doseInfo}", style = MaterialTheme.typography.bodySmall.copy(color = Color.Gray))
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun AddEditAnimalScreen(
    animalId: Long? = null,
    preselectedOwnerId: Long? = null,
    viewModel: MainViewModel,
    onNavigateBack: () -> Unit,
    onSaved: (Long) -> Unit
) {
    val animals by viewModel.allAnimals.collectAsStateWithLifecycle()
    val owners by viewModel.allOwners.collectAsStateWithLifecycle()
    val existing = animals.find { it.id == animalId }

    var selectedOwnerId by remember { mutableStateOf(existing?.ownerId ?: preselectedOwnerId ?: (owners.firstOrNull()?.id ?: 0L)) }
    var tagNumber by remember { mutableStateOf(existing?.tagNumber ?: "") }
    var name by remember { mutableStateOf(existing?.name ?: "") }
    var species by remember { mutableStateOf(existing?.species ?: "Cow") }
    var breed by remember { mutableStateOf(existing?.breed ?: "Friesian Cross") }
    var gender by remember { mutableStateOf(existing?.gender ?: "Female") }
    var age by remember { mutableStateOf(existing?.age ?: "2 Years") }
    var color by remember { mutableStateOf(existing?.color ?: "") }
    var weight by remember { mutableStateOf(existing?.weight ?: "") }
    var healthStatus by remember { mutableStateOf(existing?.healthStatus ?: "Healthy") }
    var pregnancyStatus by remember { mutableStateOf(existing?.pregnancyStatus ?: "Not Pregnant") }
    var notes by remember { mutableStateOf(existing?.notes ?: "") }

    var errorMessage by remember { mutableStateOf<String?>(null) }

    val speciesList = listOf("Cow", "Goat", "Buffalo", "Other")
    val genderList = listOf("Female", "Male")
    val healthList = listOf("Healthy", "Under Treatment", "Critical", "Recovered")
    val pregnancyList = listOf("Not Pregnant", "Suspected Pregnant", "Confirmed Pregnant", "Calved")

    BackHandler { onNavigateBack() }

    Scaffold(
        topBar = {
            AppHeader(
                title = if (existing == null) "Add Animal Profile" else "Edit Animal",
                showBack = true,
                onBack = onNavigateBack
            )
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .background(MaterialTheme.colorScheme.background),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            if (errorMessage != null) {
                item {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = Color(0xFFFFEBEE)),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Text(
                            text = errorMessage ?: "",
                            color = StatusAlertRed,
                            modifier = Modifier.padding(12.dp)
                        )
                    }
                }
            }

            // Owner Selection
            item {
                Text("Select Owner *", style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold))
                Spacer(modifier = Modifier.height(4.dp))
                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(owners) { owner ->
                        FilterChip(
                            selected = selectedOwnerId == owner.id,
                            onClick = { selectedOwnerId = owner.id },
                            label = { Text("${owner.name} (${owner.village})") }
                        )
                    }
                }
            }

            // Species & Gender Selection
            item {
                Text("Species", style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold))
                Spacer(modifier = Modifier.height(4.dp))
                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(speciesList) { sp ->
                        FilterChip(
                            selected = species == sp,
                            onClick = { species = sp },
                            label = { Text(sp) }
                        )
                    }
                }
            }

            item {
                Text("Gender", style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold))
                Spacer(modifier = Modifier.height(4.dp))
                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(genderList) { g ->
                        FilterChip(
                            selected = gender == g,
                            onClick = { gender = g },
                            label = { Text(g) }
                        )
                    }
                }
            }

            item {
                OutlinedTextField(
                    value = tagNumber,
                    onValueChange = { tagNumber = it; errorMessage = null },
                    label = { Text("Animal ID / Tag Number *") },
                    placeholder = { Text("e.g. COW-045, GOAT-018") },
                    modifier = Modifier.fillMaxWidth().testTag("animal_tag_input"),
                    singleLine = true
                )
            }

            item {
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it; errorMessage = null },
                    label = { Text("Animal Name / Nickname *") },
                    placeholder = { Text("e.g. Rani, Manik, Lalbahadur") },
                    modifier = Modifier.fillMaxWidth().testTag("animal_name_input"),
                    singleLine = true
                )
            }

            item {
                OutlinedTextField(
                    value = breed,
                    onValueChange = { breed = it },
                    label = { Text("Breed (জাত)") },
                    placeholder = { Text("e.g. Friesian Cross, Shahiwal, Black Bengal") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )
            }

            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    OutlinedTextField(
                        value = age,
                        onValueChange = { age = it },
                        label = { Text("Age") },
                        placeholder = { Text("e.g. 2.5 Years") },
                        modifier = Modifier.weight(1f),
                        singleLine = true
                    )
                    OutlinedTextField(
                        value = weight,
                        onValueChange = { weight = it },
                        label = { Text("Weight (kg)") },
                        placeholder = { Text("e.g. 320 kg") },
                        modifier = Modifier.weight(1f),
                        singleLine = true
                    )
                }
            }

            item {
                OutlinedTextField(
                    value = color,
                    onValueChange = { color = it },
                    label = { Text("Color / Markings") },
                    placeholder = { Text("e.g. Black & White, Deep Red") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )
            }

            // Health Status
            item {
                Text("Health Status", style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold))
                Spacer(modifier = Modifier.height(4.dp))
                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(healthList) { status ->
                        FilterChip(
                            selected = healthStatus == status,
                            onClick = { healthStatus = status },
                            label = { Text(status) }
                        )
                    }
                }
            }

            // Pregnancy Status
            item {
                Text("Pregnancy Status", style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold))
                Spacer(modifier = Modifier.height(4.dp))
                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(pregnancyList) { p ->
                        FilterChip(
                            selected = pregnancyStatus == p,
                            onClick = { pregnancyStatus = p },
                            label = { Text(p) }
                        )
                    }
                }
            }

            item {
                OutlinedTextField(
                    value = notes,
                    onValueChange = { notes = it },
                    label = { Text("Additional Notes") },
                    modifier = Modifier.fillMaxWidth(),
                    minLines = 2
                )
            }

            item {
                Spacer(modifier = Modifier.height(10.dp))
                Button(
                    onClick = {
                        val owner = owners.find { it.id == selectedOwnerId }
                        if (owner == null) {
                            errorMessage = "Please select an existing owner"
                            return@Button
                        }
                        if (tagNumber.isBlank()) {
                            errorMessage = "Please enter an Animal ID / Tag Number"
                            return@Button
                        }
                        if (name.isBlank()) {
                            errorMessage = "Please enter the animal's name"
                            return@Button
                        }

                        if (existing != null) {
                            val updated = existing.copy(
                                tagNumber = tagNumber.trim(),
                                name = name.trim(),
                                species = species,
                                breed = breed.trim(),
                                gender = gender,
                                age = age.trim(),
                                color = color.trim(),
                                weight = weight.trim(),
                                ownerId = owner.id,
                                ownerName = owner.name,
                                healthStatus = healthStatus,
                                pregnancyStatus = pregnancyStatus,
                                notes = notes.trim()
                            )
                            viewModel.updateAnimal(updated) {
                                onSaved(updated.id)
                            }
                        } else {
                            val newAnimal = AnimalEntity(
                                tagNumber = tagNumber.trim(),
                                name = name.trim(),
                                species = species,
                                breed = breed.trim(),
                                gender = gender,
                                age = age.trim(),
                                color = color.trim(),
                                weight = weight.trim(),
                                ownerId = owner.id,
                                ownerName = owner.name,
                                healthStatus = healthStatus,
                                pregnancyStatus = pregnancyStatus,
                                notes = notes.trim()
                            )
                            viewModel.addAnimal(newAnimal) { id ->
                                onSaved(id)
                            }
                        }
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(50.dp)
                        .testTag("save_animal_button"),
                    colors = ButtonDefaults.buttonColors(containerColor = VetGreenPrimary),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Icon(Icons.Default.Save, contentDescription = null)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Save Animal Record", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                }
            }
        }
    }
}
