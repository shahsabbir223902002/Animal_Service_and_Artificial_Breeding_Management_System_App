package com.example.ui.screens.dashboard

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.R
import com.example.data.entity.ReminderEntity
import com.example.data.entity.TreatmentEntity
import com.example.ui.MainViewModel
import com.example.ui.components.AppHeader
import com.example.ui.components.MetricStatCard
import com.example.ui.components.StatusBadge
import com.example.ui.theme.*
import com.example.util.ActionUtils
import com.example.util.DateUtils

@Composable
fun DashboardScreen(
    viewModel: MainViewModel,
    onNavigateToOwners: () -> Unit,
    onNavigateToAnimals: () -> Unit,
    onNavigateToTreatments: () -> Unit,
    onNavigateToAI: () -> Unit,
    onNavigateToAppointments: () -> Unit,
    onNavigateToVaccinations: () -> Unit,
    onNavigateToDewormings: () -> Unit,
    onNavigateToMonthlySummary: () -> Unit,
    onNavigateToProfile: () -> Unit,
    onAddOwner: () -> Unit,
    onAddAnimal: () -> Unit,
    onAddTreatment: () -> Unit,
    onAddAI: () -> Unit,
    onAddAppointment: () -> Unit,
    onTreatmentDetail: (Long) -> Unit
) {
    val context = LocalContext.current
    val syncState by viewModel.syncState.collectAsStateWithLifecycle()
    val ownerCount by viewModel.ownerCount.collectAsStateWithLifecycle()
    val animalCount by viewModel.animalCount.collectAsStateWithLifecycle()
    val treatmentCount by viewModel.treatmentCount.collectAsStateWithLifecycle()
    val todayTreatmentCount by viewModel.todayTreatmentCount.collectAsStateWithLifecycle()
    val pendingFollowUpCount by viewModel.pendingFollowUpCount.collectAsStateWithLifecycle()
    val aiCount by viewModel.aiCount.collectAsStateWithLifecycle()
    val pendingChecks by viewModel.pendingPregnancyChecks.collectAsStateWithLifecycle()
    val vaccinationCount by viewModel.vaccinationCount.collectAsStateWithLifecycle()
    val dewormingCount by viewModel.dewormingCount.collectAsStateWithLifecycle()

    val pendingReminders by viewModel.pendingReminders.collectAsStateWithLifecycle()
    val recentLogs by viewModel.recentLogs.collectAsStateWithLifecycle()
    val allTreatments by viewModel.allTreatments.collectAsStateWithLifecycle()

    // Monthly treatment calculations for insights (Section 35)
    val startOfThisMonth = DateUtils.getStartOfMonth(0)
    val startOfLastMonth = DateUtils.getStartOfMonth(-1)
    val endOfLastMonth = DateUtils.getEndOfMonth(-1)
    val startOf3Months = DateUtils.getStartOfMonth(-3)
    val startOfYear = DateUtils.getStartOfYear()

    val thisMonthTreatments = allTreatments.filter { it.date >= startOfThisMonth }
    val lastMonthTreatments = allTreatments.filter { it.date in startOfLastMonth..endOfLastMonth }
    val last3MonthsTreatments = allTreatments.filter { it.date >= startOf3Months }
    val thisYearTreatments = allTreatments.filter { it.date >= startOfYear }

    Scaffold(
        topBar = {
            AppHeader(
                title = "Rabby Animals Official",
                subtitle = "Md. Shah Walimullah Rabby • Govt. AI Tech",
                syncState = syncState,
                onSyncClick = { viewModel.triggerSync() },
                onProfileClick = onNavigateToProfile
            )
        }
    ) { paddingValues ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .background(MaterialTheme.colorScheme.background),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Hero Card with Professional Identity & Photo
            item {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("dashboard_hero_card")
                        .clickable { onNavigateToProfile() },
                    shape = RoundedCornerShape(18.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.Transparent),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(18.dp))
                    ) {
                        Image(
                            painter = painterResource(id = R.drawable.livestock_cover),
                            contentDescription = "Farm livestock cow, goat and ox",
                            contentScale = ContentScale.Crop,
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(160.dp)
                        )
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(
                                    Brush.verticalGradient(
                                        colors = listOf(
                                            VetGreenPrimary.copy(alpha = 0.88f),
                                            Color(0xFF0D3310).copy(alpha = 0.96f)
                                        )
                                    )
                                )
                        ) {
                            Column(modifier = Modifier.padding(18.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    // Animal Emblem Avatar
                                    Box(
                                        modifier = Modifier
                                            .size(64.dp)
                                            .clip(CircleShape)
                                            .background(Color.White)
                                            .padding(2.dp)
                                            .clip(CircleShape),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Image(
                                            painter = painterResource(id = R.drawable.ic_app_logo),
                                            contentDescription = "Rabby Animals Official Logo",
                                            contentScale = ContentScale.Crop,
                                            modifier = Modifier.fillMaxSize()
                                        )
                                    }

                                Spacer(modifier = Modifier.width(14.dp))

                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = "Good Morning, Rabby",
                                        style = MaterialTheme.typography.titleMedium.copy(
                                            fontWeight = FontWeight.Bold,
                                            color = Color.White
                                        )
                                    )
                                    Text(
                                        text = "Government AI Technician",
                                        style = MaterialTheme.typography.bodySmall.copy(
                                            color = VetGreenContainer,
                                            fontWeight = FontWeight.Medium
                                        )
                                    )
                                    Text(
                                        text = "Amratali Artificial Breeding Center, Cumilla",
                                        style = MaterialTheme.typography.labelSmall.copy(
                                            color = Color.White.copy(alpha = 0.8f),
                                            fontSize = 11.sp
                                        ),
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.height(14.dp))

                            // Quick contact & map row for field operations
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Button(
                                    onClick = { ActionUtils.callPhone(context, "01845-233917") },
                                    colors = ButtonDefaults.buttonColors(containerColor = Color.White),
                                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                                    shape = RoundedCornerShape(20.dp),
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Call,
                                        contentDescription = "Call",
                                        tint = VetGreenPrimary,
                                        modifier = Modifier.size(16.dp)
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = "01845-233917",
                                        style = MaterialTheme.typography.labelMedium.copy(
                                            fontWeight = FontWeight.Bold,
                                            color = VetGreenPrimary,
                                            fontSize = 11.sp
                                        )
                                    )
                                }

                                OutlinedButton(
                                    onClick = {
                                        ActionUtils.openFacebook(
                                            context,
                                            "https://web.facebook.com/profile.php?id=100066460841802"
                                        )
                                    },
                                    border = ButtonDefaults.outlinedButtonBorder.copy(
                                        brush = Brush.linearGradient(listOf(Color.White, Color.White))
                                    ),
                                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                                    shape = RoundedCornerShape(20.dp),
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Public,
                                        contentDescription = "Facebook",
                                        tint = Color.White,
                                        modifier = Modifier.size(16.dp)
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = "Facebook",
                                        style = MaterialTheme.typography.labelMedium.copy(
                                            fontWeight = FontWeight.Bold,
                                            color = Color.White,
                                            fontSize = 11.sp
                                        )
                                    )
                                }
                            }
                        }
                    }
                }
            }
            }

            // Quick Actions Bar
            item {
                Column(modifier = Modifier.fillMaxWidth()) {
                    Text(
                        text = "Quick Actions",
                        style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        QuickActionButton(
                            icon = Icons.Default.PersonAdd,
                            label = "+ Owner",
                            onClick = onAddOwner,
                            modifier = Modifier.weight(1f),
                            containerColor = VetGreenContainer,
                            contentColor = VetGreenPrimary
                        )
                        QuickActionButton(
                            icon = Icons.Default.Pets,
                            label = "+ Animal",
                            onClick = onAddAnimal,
                            modifier = Modifier.weight(1f),
                            containerColor = VetAmberContainer,
                            contentColor = VetAmberSecondary
                        )
                        QuickActionButton(
                            icon = Icons.Default.MedicalServices,
                            label = "+ Visit",
                            onClick = onAddTreatment,
                            modifier = Modifier.weight(1f),
                            containerColor = Color(0xFFE0F2FE),
                            contentColor = Color(0xFF0369A1)
                        )
                        QuickActionButton(
                            icon = Icons.Default.Biotech,
                            label = "+ AI",
                            onClick = onAddAI,
                            modifier = Modifier.weight(1f),
                            containerColor = Color(0xFFF3E8FF),
                            contentColor = Color(0xFF7E22CE)
                        )
                        QuickActionButton(
                            icon = Icons.Default.Event,
                            label = "+ Appoint",
                            onClick = onAddAppointment,
                            modifier = Modifier.weight(1f),
                            containerColor = Color(0xFFFFEDD5),
                            contentColor = Color(0xFFC2410C)
                        )
                    }
                }
            }

            // Primary Stat Metrics Grid
            item {
                Column(modifier = Modifier.fillMaxWidth()) {
                    Text(
                        text = "Overview & Live Counts",
                        style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Spacer(modifier = Modifier.height(10.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        MetricStatCard(
                            title = "Total Owners",
                            count = ownerCount.toString(),
                            icon = Icons.Default.People,
                            containerColor = Color(0xFFF0FDF4),
                            contentColor = VetGreenPrimary,
                            modifier = Modifier.weight(1f),
                            onClick = onNavigateToOwners
                        )
                        MetricStatCard(
                            title = "Total Animals",
                            count = animalCount.toString(),
                            icon = Icons.Default.Pets,
                            containerColor = Color(0xFFFFFBEB),
                            contentColor = VetAmberSecondary,
                            modifier = Modifier.weight(1f),
                            onClick = onNavigateToAnimals
                        )
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        MetricStatCard(
                            title = "Today's Visits",
                            count = todayTreatmentCount.toString(),
                            icon = Icons.Default.MedicalServices,
                            containerColor = Color(0xFFF0F9FF),
                            contentColor = Color(0xFF0284C7),
                            modifier = Modifier.weight(1f),
                            onClick = onNavigateToTreatments
                        )
                        MetricStatCard(
                            title = "Pending Follow-ups",
                            count = pendingFollowUpCount.toString(),
                            icon = Icons.Default.AssignmentLate,
                            containerColor = Color(0xFFFFF1F2),
                            contentColor = Color(0xFFE11D48),
                            modifier = Modifier.weight(1f),
                            onClick = onNavigateToTreatments
                        )
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        MetricStatCard(
                            title = "AI Cases",
                            count = aiCount.toString(),
                            icon = Icons.Default.Biotech,
                            containerColor = Color(0xFFFAF5FF),
                            contentColor = Color(0xFF9333EA),
                            modifier = Modifier.weight(1f),
                            onClick = onNavigateToAI
                        )
                        MetricStatCard(
                            title = "Pregnancy Checks",
                            count = pendingChecks.size.toString(),
                            icon = Icons.Default.FactCheck,
                            containerColor = Color(0xFFFEFCE8),
                            contentColor = Color(0xFFCA8A04),
                            modifier = Modifier.weight(1f),
                            onClick = onNavigateToAI
                        )
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        MetricStatCard(
                            title = "Vaccines Due",
                            count = vaccinationCount.toString(),
                            icon = Icons.Default.Vaccines,
                            containerColor = Color(0xFFECFDF5),
                            contentColor = Color(0xFF059669),
                            modifier = Modifier.weight(1f),
                            onClick = onNavigateToVaccinations
                        )
                        MetricStatCard(
                            title = "Deworming Due",
                            count = dewormingCount.toString(),
                            icon = Icons.Default.Sanitizer,
                            containerColor = Color(0xFFF5F3FF),
                            contentColor = Color(0xFF7C3AED),
                            modifier = Modifier.weight(1f),
                            onClick = onNavigateToDewormings
                        )
                    }
                }
            }

            // Treatment Insights / Monthly Analytics Card (Section 35)
            item {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("dashboard_treatment_overview_card"),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "Treatment Overview",
                                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            TextButton(onClick = onNavigateToMonthlySummary) {
                                Text("Monthly Summary", color = VetGreenPrimary, fontWeight = FontWeight.Bold)
                            }
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            TreatmentInsightPill("This Month", "${thisMonthTreatments.size} Treated")
                            TreatmentInsightPill("Last Month", "${lastMonthTreatments.size} Treated")
                            TreatmentInsightPill("Last 3 Mo", "${last3MonthsTreatments.size} Treated")
                            TreatmentInsightPill("This Year", "${thisYearTreatments.size} Treated")
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        FilledTonalButton(
                            onClick = onNavigateToTreatments,
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Icon(Icons.Default.History, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("View Treatment History")
                        }
                    }
                }
            }

            // Today's Follow-ups & Reminders
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Today's Schedule & Reminders",
                        style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Text(
                        text = "${pendingReminders.size} Pending",
                        style = MaterialTheme.typography.bodySmall.copy(
                            color = MaterialTheme.colorScheme.primary,
                            fontWeight = FontWeight.SemiBold
                        )
                    )
                }
            }

            if (pendingReminders.isEmpty()) {
                item {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                    ) {
                        Text(
                            text = "No pending reminders for today! You're all caught up.",
                            style = MaterialTheme.typography.bodyMedium.copy(color = Color.Gray),
                            modifier = Modifier.padding(16.dp)
                        )
                    }
                }
            } else {
                items(pendingReminders.take(4)) { reminder ->
                    ReminderItemCard(
                        reminder = reminder,
                        onComplete = { viewModel.toggleReminderCompleted(reminder.id, true) },
                        onCall = { ActionUtils.callPhone(context, "01845-233917") }
                    )
                }
            }

            // Recent Activities
            item {
                Text(
                    text = "Recent Activities",
                    style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                    color = MaterialTheme.colorScheme.onSurface
                )
            }

            items(recentLogs.take(5)) { log ->
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .clip(CircleShape)
                                .background(VetGreenContainer),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = when (log.category) {
                                    "AI" -> Icons.Default.Biotech
                                    "Treatment" -> Icons.Default.MedicalServices
                                    "Animal" -> Icons.Default.Pets
                                    "Owner" -> Icons.Default.Person
                                    else -> Icons.Default.CheckCircle
                                },
                                contentDescription = null,
                                tint = VetGreenPrimary,
                                modifier = Modifier.size(18.dp)
                            )
                        }

                        Spacer(modifier = Modifier.width(12.dp))

                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = log.title,
                                style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold)
                            )
                            Text(
                                text = log.description,
                                style = MaterialTheme.typography.bodySmall.copy(color = MaterialTheme.colorScheme.onSurfaceVariant)
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun QuickActionButton(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    label: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    containerColor: Color,
    contentColor: Color
) {
    Surface(
        modifier = modifier
            .clip(RoundedCornerShape(12.dp))
            .clickable { onClick() },
        color = containerColor,
        shape = RoundedCornerShape(12.dp)
    ) {
        Column(
            modifier = Modifier.padding(vertical = 12.dp, horizontal = 4.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Icon(
                imageVector = icon,
                contentDescription = label,
                tint = contentColor,
                modifier = Modifier.size(22.dp)
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = label,
                style = MaterialTheme.typography.labelSmall.copy(
                    fontWeight = FontWeight.Bold,
                    fontSize = 11.sp,
                    color = contentColor
                ),
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

@Composable
private fun TreatmentInsightPill(title: String, count: String) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier
            .clip(RoundedCornerShape(10.dp))
            .background(VetSurfaceVariant)
            .padding(horizontal = 8.dp, vertical = 6.dp)
    ) {
        Text(
            text = title,
            style = MaterialTheme.typography.labelSmall.copy(fontSize = 10.sp, color = Color.Gray)
        )
        Spacer(modifier = Modifier.height(2.dp))
        Text(
            text = count,
            style = MaterialTheme.typography.bodySmall.copy(
                fontWeight = FontWeight.Bold,
                color = VetGreenPrimary,
                fontSize = 11.sp
            )
        )
    }
}

@Composable
private fun ReminderItemCard(
    reminder: ReminderEntity,
    onComplete: () -> Unit,
    onCall: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    StatusBadge(
                        text = reminder.category,
                        color = when (reminder.category) {
                            "Pregnancy Check" -> Color(0xFFB45309)
                            "Vaccination" -> Color(0xFF047857)
                            "AI Follow-up" -> Color(0xFF6D28D9)
                            else -> VetGreenPrimary
                        },
                        containerColor = when (reminder.category) {
                            "Pregnancy Check" -> VetAmberContainer
                            "Vaccination" -> Color(0xFFD1FAE5)
                            "AI Follow-up" -> Color(0xFFEDE9FE)
                            else -> VetGreenContainer
                        }
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Due: ${DateUtils.formatDisplayDate(reminder.dueDate)}",
                        style = MaterialTheme.typography.labelSmall.copy(color = Color.Gray, fontSize = 11.sp)
                    )
                }
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = reminder.title,
                    style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold)
                )
                Text(
                    text = reminder.description,
                    style = MaterialTheme.typography.bodySmall.copy(color = MaterialTheme.colorScheme.onSurfaceVariant)
                )
            }

            IconButton(onClick = onComplete) {
                Icon(
                    imageVector = Icons.Default.CheckCircleOutline,
                    contentDescription = "Mark Complete",
                    tint = VetGreenPrimary
                )
            }
        }
    }
}
