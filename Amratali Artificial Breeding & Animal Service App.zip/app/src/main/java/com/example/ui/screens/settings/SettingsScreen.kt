package com.example.ui.screens.settings

import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.repository.SyncState
import com.example.ui.MainViewModel
import com.example.ui.components.AppHeader
import com.example.ui.theme.*

@Composable
fun SettingsScreen(
    viewModel: MainViewModel,
    onNavigateBack: () -> Unit,
    onNavigateToProfile: () -> Unit,
    onLogout: () -> Unit
) {
    val context = LocalContext.current
    val syncState by viewModel.syncState.collectAsStateWithLifecycle()
    val language by viewModel.language.collectAsStateWithLifecycle()

    var showChangePinDialog by remember { mutableStateOf(false) }
    var newPinText by remember { mutableStateOf("") }

    BackHandler { onNavigateBack() }

    if (showChangePinDialog) {
        AlertDialog(
            onDismissRequest = { showChangePinDialog = false },
            title = { Text("Change Security PIN") },
            text = {
                Column {
                    Text("Enter a new 4-digit PIN for app access:")
                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedTextField(
                        value = newPinText,
                        onValueChange = { if (it.length <= 6) newPinText = it },
                        label = { Text("New PIN") },
                        singleLine = true
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (newPinText.length >= 4) {
                            viewModel.changePin(newPinText)
                            showChangePinDialog = false
                            Toast.makeText(context, "PIN updated successfully", Toast.LENGTH_SHORT).show()
                        } else {
                            Toast.makeText(context, "PIN must be at least 4 digits", Toast.LENGTH_SHORT).show()
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = VetGreenPrimary)
                ) {
                    Text("Save PIN")
                }
            },
            dismissButton = {
                TextButton(onClick = { showChangePinDialog = false }) { Text("Cancel") }
            }
        )
    }

    Scaffold(
        topBar = {
            AppHeader(
                title = "Settings & Synchronization",
                subtitle = "App Configuration & Backup",
                showBack = true,
                onBack = onNavigateBack
            )
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .background(MaterialTheme.colorScheme.background),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // Profile Card Link
            item {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { onNavigateToProfile() },
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(44.dp)
                                .clip(CircleShape)
                                .background(VetGreenContainer),
                            contentAlignment = Alignment.Center
                        ) {
                            androidx.compose.foundation.Image(
                                painter = androidx.compose.ui.res.painterResource(id = com.example.R.drawable.ic_app_logo),
                                contentDescription = "Rabby Animals Official",
                                contentScale = androidx.compose.ui.layout.ContentScale.Crop,
                                modifier = Modifier.fillMaxSize()
                            )
                        }
                        Spacer(modifier = Modifier.width(14.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text("Md. Shah Walimullah Rabby", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                            Text("Government AI Technician • Amratali Center", style = MaterialTheme.typography.bodySmall.copy(color = Color.Gray))
                        }
                        Icon(Icons.Default.ChevronRight, contentDescription = null, tint = Color.Gray)
                    }
                }
            }

            // Sync Status Card
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text("Offline-First Cloud Sync", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                                Text(
                                    text = when (syncState) {
                                        SyncState.SYNCED -> "All local records backed up and synced"
                                        SyncState.SYNCING -> "Synchronizing records with cloud..."
                                        SyncState.OFFLINE -> "Working offline in field mode"
                                        SyncState.ERROR -> "Sync connection issue"
                                    },
                                    style = MaterialTheme.typography.bodySmall.copy(color = Color.Gray)
                                )
                            }

                            FilledTonalButton(
                                onClick = {
                                    viewModel.triggerSync()
                                    Toast.makeText(context, "Syncing data with cloud...", Toast.LENGTH_SHORT).show()
                                },
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Icon(Icons.Default.Sync, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Sync Now", fontSize = 12.sp)
                            }
                        }
                    }
                }
            }

            // Preferences
            item {
                Text("Preferences & Security", style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold))
            }

            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Column(modifier = Modifier.padding(vertical = 4.dp)) {
                        // Language
                        SettingsItem(
                            icon = Icons.Default.Language,
                            title = "Language / ভাষা",
                            subtitle = if (language == "bn") "বাংলা (Bengali - Default)" else "English",
                            onClick = {
                                val nextLang = if (language == "bn") "en" else "bn"
                                viewModel.setLanguage(nextLang)
                                Toast.makeText(context, "Language switched to $nextLang", Toast.LENGTH_SHORT).show()
                            }
                        )

                        HorizontalDivider(color = VetOutlineVariant, modifier = Modifier.padding(horizontal = 16.dp))

                        // Change PIN
                        SettingsItem(
                            icon = Icons.Default.Lock,
                            title = "Security PIN",
                            subtitle = "Change app lock credentials (Default: 1234)",
                            onClick = { showChangePinDialog = true }
                        )

                        HorizontalDivider(color = VetOutlineVariant, modifier = Modifier.padding(horizontal = 16.dp))

                        // Test Notification
                        SettingsItem(
                            icon = Icons.Default.NotificationsActive,
                            title = "Test Reminder Notification",
                            subtitle = "Trigger field reminder notification on device",
                            onClick = {
                                viewModel.testReminderNotification(
                                    "Field Reminder: Pregnancy Check Due",
                                    "Cow COW-023 (Abdul Karim) - 60 days AI follow-up check due today."
                                )
                                Toast.makeText(context, "Notification posted", Toast.LENGTH_SHORT).show()
                            }
                        )
                    }
                }
            }

            // App Information
            item {
                Text("Application Details", style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold))
            }

            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text("Rabby Animals Official", fontWeight = FontWeight.Bold, color = VetGreenPrimary)
                        Text("Amratali Artificial Breeding & Animal Service", style = MaterialTheme.typography.bodyMedium)
                        Spacer(modifier = Modifier.height(4.dp))
                        Text("Version 1.0.0 (Field Edition)", style = MaterialTheme.typography.bodySmall.copy(color = Color.Gray))
                        Text("Built for Md. Shah Walimullah Rabby, Government AI Technician", style = MaterialTheme.typography.bodySmall.copy(color = Color.Gray))
                        Text("Upazila Prani Sampad Doptor & Veterinary Hospital, Cumilla", style = MaterialTheme.typography.bodySmall.copy(color = Color.Gray))
                    }
                }
            }

            // Logout Action
            item {
                Spacer(modifier = Modifier.height(8.dp))
                OutlinedButton(
                    onClick = {
                        viewModel.logout()
                        onLogout()
                    },
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = StatusAlertRed),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Icon(Icons.Default.Logout, contentDescription = null)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Lock Application / Log Out")
                }
            }
        }
    }
}

@Composable
fun SettingsItem(
    icon: ImageVector,
    title: String,
    subtitle: String,
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() }
            .padding(horizontal = 16.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, contentDescription = null, tint = VetGreenPrimary, modifier = Modifier.size(24.dp))
        Spacer(modifier = Modifier.width(14.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(title, fontWeight = FontWeight.SemiBold, style = MaterialTheme.typography.bodyLarge)
            Text(subtitle, style = MaterialTheme.typography.bodySmall.copy(color = Color.Gray))
        }
        Icon(Icons.Default.ChevronRight, contentDescription = null, tint = Color.Gray)
    }
}
