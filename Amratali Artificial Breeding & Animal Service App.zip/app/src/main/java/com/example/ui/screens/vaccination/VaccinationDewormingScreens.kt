package com.example.ui.screens.vaccination

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.entity.DewormingEntity
import com.example.data.entity.VaccinationEntity
import com.example.ui.MainViewModel
import com.example.ui.components.AppHeader
import com.example.ui.components.EmptyView
import com.example.ui.components.StatusBadge
import com.example.ui.theme.*
import com.example.util.DateUtils

@Composable
fun VaccinationDewormingScreen(
    viewModel: MainViewModel,
    onNavigateBack: () -> Unit,
    onProfileClick: () -> Unit
) {
    val syncState by viewModel.syncState.collectAsStateWithLifecycle()
    val vaccinations by viewModel.allVaccinations.collectAsStateWithLifecycle()
    val dewormings by viewModel.allDewormings.collectAsStateWithLifecycle()
    val animals by viewModel.allAnimals.collectAsStateWithLifecycle()

    var selectedTab by remember { mutableIntStateOf(0) }
    val tabs = listOf("Vaccination (${vaccinations.size})", "Deworming (${dewormings.size})")

    var showAddVaccineDialog by remember { mutableStateOf(false) }
    var showAddDewormingDialog by remember { mutableStateOf(false) }

    BackHandler { onNavigateBack() }

    if (showAddVaccineDialog) {
        AddVaccinationDialog(
            animals = animals,
            onDismiss = { showAddVaccineDialog = false },
            onSave = { v ->
                viewModel.addVaccination(v) {
                    showAddVaccineDialog = false
                }
            }
        )
    }

    if (showAddDewormingDialog) {
        AddDewormingDialog(
            animals = animals,
            onDismiss = { showAddDewormingDialog = false },
            onSave = { d ->
                viewModel.addDeworming(d) {
                    showAddDewormingDialog = false
                }
            }
        )
    }

    Scaffold(
        topBar = {
            AppHeader(
                title = "Preventive Healthcare",
                subtitle = "Vaccination & Deworming Schedules",
                showBack = true,
                onBack = onNavigateBack,
                syncState = syncState,
                onSyncClick = { viewModel.triggerSync() },
                onProfileClick = onProfileClick
            )
        },
        floatingActionButton = {
            FloatingActionButton(
                onClick = {
                    if (selectedTab == 0) showAddVaccineDialog = true
                    else showAddDewormingDialog = true
                },
                containerColor = if (selectedTab == 0) VetGreenPrimary else VetAmberSecondary,
                contentColor = Color.White
            ) {
                Icon(Icons.Default.Add, contentDescription = "Add")
            }
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .background(MaterialTheme.colorScheme.background)
        ) {
            TabRow(selectedTabIndex = selectedTab) {
                tabs.forEachIndexed { index, title ->
                    Tab(
                        selected = selectedTab == index,
                        onClick = { selectedTab = index },
                        text = { Text(title, fontWeight = if (selectedTab == index) FontWeight.Bold else FontWeight.Normal) }
                    )
                }
            }

            when (selectedTab) {
                0 -> {
                    // Vaccination List
                    if (vaccinations.isEmpty()) {
                        EmptyView(
                            icon = Icons.Default.Vaccines,
                            title = "No vaccination records yet",
                            subtitle = "Keep animals protected against FMD, Anthrax, Black Quarter, and PPR.",
                            actionButtonText = "+ Add Vaccine Record",
                            onActionClick = { showAddVaccineDialog = true }
                        )
                    } else {
                        LazyColumn(
                            contentPadding = PaddingValues(16.dp),
                            verticalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            items(vaccinations, key = { it.id }) { v ->
                                Card(
                                    modifier = Modifier.fillMaxWidth(),
                                    shape = RoundedCornerShape(12.dp),
                                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                                    elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
                                ) {
                                    Column(modifier = Modifier.padding(14.dp)) {
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Text(v.vaccineName, style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold, color = VetGreenPrimary))
                                            StatusBadge(text = v.animalTag)
                                        }
                                        Spacer(modifier = Modifier.height(6.dp))
                                        Text("Owner: ${v.ownerName}")
                                        Text("Administered: ${DateUtils.formatDisplayDate(v.dateGiven)} • Dose: ${v.doseInfo}")
                                        Text("Next Due Date: ${DateUtils.formatDisplayDate(v.nextDueDate)}", color = VetAmberSecondary, fontWeight = FontWeight.Bold)
                                        if (v.notes.isNotBlank()) {
                                            Text("Notes: ${v.notes}", style = MaterialTheme.typography.bodySmall.copy(color = Color.Gray))
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
                1 -> {
                    // Deworming List
                    if (dewormings.isEmpty()) {
                        EmptyView(
                            icon = Icons.Default.Sanitizer,
                            title = "No deworming records yet",
                            subtitle = "Maintain scheduled quarterly deworming for optimal growth and milk production.",
                            actionButtonText = "+ Add Deworming Record",
                            onActionClick = { showAddDewormingDialog = true }
                        )
                    } else {
                        LazyColumn(
                            contentPadding = PaddingValues(16.dp),
                            verticalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            items(dewormings, key = { it.id }) { d ->
                                Card(
                                    modifier = Modifier.fillMaxWidth(),
                                    shape = RoundedCornerShape(12.dp),
                                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                                    elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
                                ) {
                                    Column(modifier = Modifier.padding(14.dp)) {
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Text(d.productName, style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold, color = VetAmberSecondary))
                                            StatusBadge(text = d.animalTag, color = VetAmberSecondary, containerColor = VetAmberContainer)
                                        }
                                        Spacer(modifier = Modifier.height(6.dp))
                                        Text("Owner: ${d.ownerName}")
                                        Text("Given: ${DateUtils.formatDisplayDate(d.dateGiven)} • Dose: ${d.doseInfo}")
                                        Text("Next Due Date: ${DateUtils.formatDisplayDate(d.nextDueDate)}", color = VetAmberSecondary, fontWeight = FontWeight.Bold)
                                        if (d.notes.isNotBlank()) {
                                            Text("Notes: ${d.notes}", style = MaterialTheme.typography.bodySmall.copy(color = Color.Gray))
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun AddVaccinationDialog(
    animals: List<com.example.data.entity.AnimalEntity>,
    onDismiss: () -> Unit,
    onSave: (VaccinationEntity) -> Unit
) {
    var selectedAnimalId by remember { mutableStateOf(animals.firstOrNull()?.id ?: 0L) }
    val animal = animals.find { it.id == selectedAnimalId }

    var vaccineName by remember { mutableStateOf("FMD (ক্ষুরারোগ ভ্যাকসিন)") }
    var dateGiven by remember { mutableStateOf(DateUtils.getTodayIso()) }
    var nextDueDate by remember { mutableStateOf(DateUtils.addDaysToDate(dateGiven, 180)) }
    var doseInfo by remember { mutableStateOf("3ml Subcutaneous") }
    var notes by remember { mutableStateOf("") }

    val commonVaccines = listOf(
        "FMD (ক্ষুরারোগ ভ্যাকসিন)",
        "Anthrax (তড়কা)",
        "Black Quarter (BQ)",
        "Hemorrhagic Septicemia (HS - বাদলা)",
        "PPR Vaccine (ছাগল)",
        "Rabies Vaccine"
    )

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Record Vaccination") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("Select Animal", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    items(animals) { a ->
                        FilterChip(
                            selected = selectedAnimalId == a.id,
                            onClick = { selectedAnimalId = a.id },
                            label = { Text("${a.tagNumber} (${a.ownerName})") }
                        )
                    }
                }

                Text("Vaccine Type", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    items(commonVaccines) { v ->
                        FilterChip(
                            selected = vaccineName == v,
                            onClick = { vaccineName = v },
                            label = { Text(v, fontSize = 11.sp) }
                        )
                    }
                }

                OutlinedTextField(
                    value = dateGiven,
                    onValueChange = {
                        dateGiven = it
                        nextDueDate = DateUtils.addDaysToDate(it, 180)
                    },
                    label = { Text("Date Given (yyyy-MM-dd)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = nextDueDate,
                    onValueChange = { nextDueDate = it },
                    label = { Text("Next Due Date (yyyy-MM-dd)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = doseInfo,
                    onValueChange = { doseInfo = it },
                    label = { Text("Dose & Route") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (animal != null) {
                        onSave(
                            VaccinationEntity(
                                animalId = animal.id,
                                animalTag = animal.tagNumber,
                                ownerId = animal.ownerId,
                                ownerName = animal.ownerName,
                                vaccineName = vaccineName,
                                dateGiven = dateGiven,
                                nextDueDate = nextDueDate,
                                doseInfo = doseInfo,
                                notes = notes
                            )
                        )
                    }
                },
                colors = ButtonDefaults.buttonColors(containerColor = VetGreenPrimary)
            ) {
                Text("Save Vaccine")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        }
    )
}

@Composable
fun AddDewormingDialog(
    animals: List<com.example.data.entity.AnimalEntity>,
    onDismiss: () -> Unit,
    onSave: (DewormingEntity) -> Unit
) {
    var selectedAnimalId by remember { mutableStateOf(animals.firstOrNull()?.id ?: 0L) }
    val animal = animals.find { it.id == selectedAnimalId }

    var productName by remember { mutableStateOf("Endex-Vet (Triclabendazole + Levamisole)") }
    var dateGiven by remember { mutableStateOf(DateUtils.getTodayIso()) }
    var nextDueDate by remember { mutableStateOf(DateUtils.addDaysToDate(dateGiven, 90)) }
    var doseInfo by remember { mutableStateOf("1 Bolus oral") }
    var notes by remember { mutableStateOf("") }

    val commonMedicines = listOf(
        "Endex-Vet (Triclabendazole + Levamisole)",
        "Almex-Vet (Albendazole)",
        "Renadex (Fenbendazole)",
        "Ivermectin Injection"
    )

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Record Deworming") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("Select Animal", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    items(animals) { a ->
                        FilterChip(
                            selected = selectedAnimalId == a.id,
                            onClick = { selectedAnimalId = a.id },
                            label = { Text("${a.tagNumber} (${a.ownerName})") }
                        )
                    }
                }

                Text("Anthelmintic Product", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    items(commonMedicines) { m ->
                        FilterChip(
                            selected = productName == m,
                            onClick = { productName = m },
                            label = { Text(m, fontSize = 11.sp) }
                        )
                    }
                }

                OutlinedTextField(
                    value = dateGiven,
                    onValueChange = {
                        dateGiven = it
                        nextDueDate = DateUtils.addDaysToDate(it, 90)
                    },
                    label = { Text("Date Given (yyyy-MM-dd)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = nextDueDate,
                    onValueChange = { nextDueDate = it },
                    label = { Text("Next Due Date (+90 Days)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = doseInfo,
                    onValueChange = { doseInfo = it },
                    label = { Text("Dose & Route") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (animal != null) {
                        onSave(
                            DewormingEntity(
                                animalId = animal.id,
                                animalTag = animal.tagNumber,
                                ownerId = animal.ownerId,
                                ownerName = animal.ownerName,
                                productName = productName,
                                dateGiven = dateGiven,
                                nextDueDate = nextDueDate,
                                doseInfo = doseInfo,
                                notes = notes
                            )
                        )
                    }
                },
                colors = ButtonDefaults.buttonColors(containerColor = VetAmberSecondary)
            ) {
                Text("Save Deworming")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        }
    )
}
