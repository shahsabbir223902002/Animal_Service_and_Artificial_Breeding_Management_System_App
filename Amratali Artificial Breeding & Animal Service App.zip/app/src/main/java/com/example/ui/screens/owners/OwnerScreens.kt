package com.example.ui.screens.owners

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.entity.OwnerEntity
import com.example.ui.MainViewModel
import com.example.ui.components.AppHeader
import com.example.ui.components.EmptyView
import com.example.ui.components.StatusBadge
import com.example.ui.theme.*
import com.example.util.ActionUtils
import com.example.util.DateUtils

@Composable
fun OwnerListScreen(
    viewModel: MainViewModel,
    onNavigateBack: () -> Unit,
    onOwnerClick: (Long) -> Unit,
    onAddOwner: () -> Unit,
    onProfileClick: () -> Unit
) {
    val context = LocalContext.current
    val owners by viewModel.filteredOwners.collectAsStateWithLifecycle()
    val allAnimals by viewModel.allAnimals.collectAsStateWithLifecycle()
    val searchQuery by viewModel.ownerSearchQuery.collectAsStateWithLifecycle()
    val syncState by viewModel.syncState.collectAsStateWithLifecycle()

    BackHandler { onNavigateBack() }

    Scaffold(
        topBar = {
            AppHeader(
                title = "Animal Owners",
                subtitle = "${owners.size} Registered Owners",
                showBack = true,
                onBack = onNavigateBack,
                syncState = syncState,
                onSyncClick = { viewModel.triggerSync() },
                onProfileClick = onProfileClick
            )
        },
        floatingActionButton = {
            FloatingActionButton(
                onClick = onAddOwner,
                containerColor = VetGreenPrimary,
                contentColor = Color.White,
                modifier = Modifier.testTag("add_owner_fab")
            ) {
                Icon(Icons.Default.PersonAdd, contentDescription = "Add Owner")
            }
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .background(MaterialTheme.colorScheme.background)
        ) {
            // Search Input
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { viewModel.ownerSearchQuery.value = it },
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 8.dp)
                    .testTag("owner_search_field"),
                placeholder = { Text("Search by name, phone, village, ID...") },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = "Search") },
                trailingIcon = {
                    if (searchQuery.isNotEmpty()) {
                        IconButton(onClick = { viewModel.ownerSearchQuery.value = "" }) {
                            Icon(Icons.Default.Clear, contentDescription = "Clear")
                        }
                    }
                },
                singleLine = true,
                shape = RoundedCornerShape(12.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = VetGreenPrimary,
                    unfocusedBorderColor = VetOutline
                )
            )

            if (owners.isEmpty()) {
                EmptyView(
                    icon = Icons.Default.PeopleOutline,
                    title = if (searchQuery.isNotBlank()) "No owners found for '$searchQuery'" else "No Owners Registered",
                    subtitle = "Add your first farmer/livestock owner to begin record keeping.",
                    actionButtonText = "+ Add Owner",
                    onActionClick = onAddOwner
                )
            } else {
                LazyColumn(
                    contentPadding = PaddingValues(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    items(owners, key = { it.id }) { owner ->
                        val animalCountForOwner = allAnimals.count { it.ownerId == owner.id }
                        OwnerCardItem(
                            owner = owner,
                            animalCount = animalCountForOwner,
                            onClick = { onOwnerClick(owner.id) },
                            onCall = { ActionUtils.callPhone(context, owner.phone) },
                            onSms = { ActionUtils.sendSms(context, owner.phone) },
                            onMap = { ActionUtils.openMap(context, owner.latitude, owner.longitude, owner.name) }
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun OwnerCardItem(
    owner: OwnerEntity,
    animalCount: Int,
    onClick: () -> Unit,
    onCall: () -> Unit,
    onSms: () -> Unit,
    onMap: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() }
            .testTag("owner_card_${owner.id}"),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(44.dp)
                        .clip(CircleShape)
                        .background(VetGreenContainer),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = owner.name.take(1).uppercase(),
                        fontWeight = FontWeight.Bold,
                        color = VetGreenPrimary,
                        fontSize = 18.sp
                    )
                }

                Spacer(modifier = Modifier.width(12.dp))

                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = owner.name,
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                    )
                    Text(
                        text = "${owner.village}, ${owner.unionName} • ${owner.ownerCode}",
                        style = MaterialTheme.typography.bodySmall.copy(color = MaterialTheme.colorScheme.onSurfaceVariant)
                    )
                }

                StatusBadge(
                    text = "$animalCount Animals",
                    color = VetGreenPrimary,
                    containerColor = VetGreenContainer
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            Text(
                text = "📞 ${owner.phone} ${if (owner.altPhone.isNotBlank()) "• Alt: ${owner.altPhone}" else ""}",
                style = MaterialTheme.typography.bodySmall.copy(color = MaterialTheme.colorScheme.onSurface)
            )

            if (owner.address.isNotBlank()) {
                Text(
                    text = "📍 ${owner.address}",
                    style = MaterialTheme.typography.bodySmall.copy(color = Color.Gray)
                )
            }

            Spacer(modifier = Modifier.height(10.dp))
            HorizontalDivider(color = VetOutlineVariant)
            Spacer(modifier = Modifier.height(8.dp))

            // Contact Action Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.End,
                verticalAlignment = Alignment.CenterVertically
            ) {
                FilledTonalIconButton(
                    onClick = onCall,
                    colors = IconButtonDefaults.filledTonalIconButtonColors(
                        containerColor = VetGreenContainer,
                        contentColor = VetGreenPrimary
                    )
                ) {
                    Icon(Icons.Default.Call, contentDescription = "Call Owner", modifier = Modifier.size(18.dp))
                }
                Spacer(modifier = Modifier.width(8.dp))
                FilledTonalIconButton(
                    onClick = onSms,
                    colors = IconButtonDefaults.filledTonalIconButtonColors(
                        containerColor = Color(0xFFE0F2FE),
                        contentColor = Color(0xFF0369A1)
                    )
                ) {
                    Icon(Icons.Default.Message, contentDescription = "Message Owner", modifier = Modifier.size(18.dp))
                }
                Spacer(modifier = Modifier.width(8.dp))
                FilledTonalIconButton(
                    onClick = onMap,
                    colors = IconButtonDefaults.filledTonalIconButtonColors(
                        containerColor = VetAmberContainer,
                        contentColor = VetAmberSecondary
                    )
                ) {
                    Icon(Icons.Default.LocationOn, contentDescription = "Open Map", modifier = Modifier.size(18.dp))
                }
                Spacer(modifier = Modifier.width(8.dp))
                TextButton(onClick = onClick) {
                    Text("View Profile", fontWeight = FontWeight.Bold, color = VetGreenPrimary)
                }
            }
        }
    }
}

@Composable
fun OwnerDetailScreen(
    ownerId: Long,
    viewModel: MainViewModel,
    onNavigateBack: () -> Unit,
    onEditOwner: (Long) -> Unit,
    onAddAnimalForOwner: (Long) -> Unit,
    onAddVisitForOwner: (Long) -> Unit,
    onAnimalClick: (Long) -> Unit,
    onTreatmentClick: (Long) -> Unit
) {
    val context = LocalContext.current
    val owners by viewModel.allOwners.collectAsStateWithLifecycle()
    val owner = owners.find { it.id == ownerId }
    val allAnimals by viewModel.allAnimals.collectAsStateWithLifecycle()
    val allTreatments by viewModel.allTreatments.collectAsStateWithLifecycle()
    val allAIRecords by viewModel.allAIRecords.collectAsStateWithLifecycle()

    val ownerAnimals = allAnimals.filter { it.ownerId == ownerId }
    val ownerTreatments = allTreatments.filter { it.ownerId == ownerId }
    val ownerAIRecords = allAIRecords.filter { it.ownerId == ownerId }

    var selectedTab by remember { mutableIntStateOf(0) }
    val tabs = listOf("Animals (${ownerAnimals.size})", "Treatments (${ownerTreatments.size})", "AI Records (${ownerAIRecords.size})")

    var showDeleteDialog by remember { mutableStateOf(false) }

    BackHandler { onNavigateBack() }

    if (owner == null) {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Text("Owner not found")
        }
        return
    }

    if (showDeleteDialog) {
        AlertDialog(
            onDismissRequest = { showDeleteDialog = false },
            title = { Text("Delete Owner?") },
            text = { Text("Are you sure you want to delete ${owner.name}? This will remove associated records.") },
            confirmButton = {
                TextButton(
                    onClick = {
                        viewModel.deleteOwner(owner) {
                            showDeleteDialog = false
                            onNavigateBack()
                        }
                    }
                ) {
                    Text("Delete", color = StatusAlertRed)
                }
            },
            dismissButton = {
                TextButton(onClick = { showDeleteDialog = false }) { Text("Cancel") }
            }
        )
    }

    Scaffold(
        topBar = {
            AppHeader(
                title = owner.name,
                subtitle = "Owner Code: ${owner.ownerCode}",
                showBack = true,
                onBack = onNavigateBack,
                actions = {
                    IconButton(onClick = { onEditOwner(owner.id) }) {
                        Icon(Icons.Default.Edit, contentDescription = "Edit")
                    }
                    IconButton(onClick = { showDeleteDialog = true }) {
                        Icon(Icons.Default.Delete, contentDescription = "Delete", tint = StatusAlertRed)
                    }
                }
            )
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .background(MaterialTheme.colorScheme.background),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Profile Card
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(54.dp)
                                    .clip(CircleShape)
                                    .background(VetGreenContainer),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(Icons.Default.Person, contentDescription = null, tint = VetGreenPrimary, modifier = Modifier.size(32.dp))
                            }
                            Spacer(modifier = Modifier.width(14.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(owner.name, style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold))
                                Text("Registered: ${DateUtils.formatDisplayDate(owner.registrationDate)}", style = MaterialTheme.typography.bodySmall.copy(color = Color.Gray))
                            }
                        }

                        Spacer(modifier = Modifier.height(14.dp))
                        HorizontalDivider(color = VetOutlineVariant)
                        Spacer(modifier = Modifier.height(12.dp))

                        DetailRow(icon = Icons.Default.Phone, label = "Mobile", value = owner.phone)
                        if (owner.altPhone.isNotBlank()) {
                            DetailRow(icon = Icons.Default.PhoneIphone, label = "Alt Phone", value = owner.altPhone)
                        }
                        DetailRow(icon = Icons.Default.LocationOn, label = "Village / Union", value = "${owner.village}, ${owner.unionName}")
                        DetailRow(icon = Icons.Default.Map, label = "Upazila & District", value = "${owner.upazila}, ${owner.district}")
                        if (owner.address.isNotBlank()) {
                            DetailRow(icon = Icons.Default.Home, label = "Full Address", value = owner.address)
                        }
                        if (owner.nid.isNotBlank()) {
                            DetailRow(icon = Icons.Default.Badge, label = "NID / ID", value = owner.nid)
                        }
                        if (owner.notes.isNotBlank()) {
                            DetailRow(icon = Icons.Default.Notes, label = "Notes", value = owner.notes)
                        }

                        Spacer(modifier = Modifier.height(14.dp))

                        // Large Call, Message, Map buttons
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Button(
                                onClick = { ActionUtils.callPhone(context, owner.phone) },
                                colors = ButtonDefaults.buttonColors(containerColor = VetGreenPrimary),
                                modifier = Modifier.weight(1f),
                                shape = RoundedCornerShape(10.dp)
                            ) {
                                Icon(Icons.Default.Call, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Call")
                            }
                            OutlinedButton(
                                onClick = { ActionUtils.sendSms(context, owner.phone) },
                                modifier = Modifier.weight(1f),
                                shape = RoundedCornerShape(10.dp)
                            ) {
                                Icon(Icons.Default.Message, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("SMS")
                            }
                            FilledTonalButton(
                                onClick = { ActionUtils.openMap(context, owner.latitude, owner.longitude, owner.name) },
                                colors = ButtonDefaults.filledTonalButtonColors(containerColor = VetAmberContainer),
                                modifier = Modifier.weight(1f),
                                shape = RoundedCornerShape(10.dp)
                            ) {
                                Icon(Icons.Default.LocationOn, contentDescription = null, tint = VetAmberSecondary, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Map", color = VetAmberSecondary)
                            }
                        }
                    }
                }
            }

            // Quick add for this owner
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    FilledTonalButton(
                        onClick = { onAddAnimalForOwner(owner.id) },
                        modifier = Modifier.weight(1f),
                        colors = ButtonDefaults.filledTonalButtonColors(containerColor = VetGreenContainer),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Icon(Icons.Default.Pets, contentDescription = null, tint = VetGreenPrimary, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("+ Add Animal", color = VetGreenPrimary, fontWeight = FontWeight.Bold)
                    }

                    FilledTonalButton(
                        onClick = { onAddVisitForOwner(owner.id) },
                        modifier = Modifier.weight(1f),
                        colors = ButtonDefaults.filledTonalButtonColors(containerColor = Color(0xFFE0F2FE)),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Icon(Icons.Default.MedicalServices, contentDescription = null, tint = Color(0xFF0369A1), modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("+ New Visit", color = Color(0xFF0369A1), fontWeight = FontWeight.Bold)
                    }
                }
            }

            // Tabs for Animals, Treatments, AI
            item {
                TabRow(selectedTabIndex = selectedTab) {
                    tabs.forEachIndexed { index, title ->
                        Tab(
                            selected = selectedTab == index,
                            onClick = { selectedTab = index },
                            text = { Text(title, maxLines = 1, fontWeight = if (selectedTab == index) FontWeight.Bold else FontWeight.Normal) }
                        )
                    }
                }
            }

            when (selectedTab) {
                0 -> {
                    if (ownerAnimals.isEmpty()) {
                        item {
                            EmptyView(
                                icon = Icons.Default.Pets,
                                title = "No animals added for ${owner.name}",
                                actionButtonText = "+ Add Animal",
                                onActionClick = { onAddAnimalForOwner(owner.id) }
                            )
                        }
                    } else {
                        items(ownerAnimals) { animal ->
                            Card(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable { onAnimalClick(animal.id) },
                                shape = RoundedCornerShape(12.dp),
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(14.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .size(40.dp)
                                            .clip(CircleShape)
                                            .background(VetAmberContainer),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Icon(Icons.Default.Pets, contentDescription = null, tint = VetAmberSecondary)
                                    }
                                    Spacer(modifier = Modifier.width(12.dp))
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text("${animal.species} • ${animal.tagNumber}", fontWeight = FontWeight.Bold)
                                        Text("${animal.name} (${animal.breed})", style = MaterialTheme.typography.bodySmall.copy(color = Color.Gray))
                                    }
                                    StatusBadge(text = animal.healthStatus)
                                }
                            }
                        }
                    }
                }
                1 -> {
                    if (ownerTreatments.isEmpty()) {
                        item {
                            EmptyView(
                                icon = Icons.Default.MedicalServices,
                                title = "No treatment records yet",
                                actionButtonText = "+ New Visit",
                                onActionClick = { onAddVisitForOwner(owner.id) }
                            )
                        }
                    } else {
                        items(ownerTreatments) { treatment ->
                            Card(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable { onTreatmentClick(treatment.id) },
                                shape = RoundedCornerShape(12.dp),
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                            ) {
                                Column(modifier = Modifier.padding(14.dp)) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Text(DateUtils.formatDisplayDate(treatment.date), fontWeight = FontWeight.Bold, color = VetGreenPrimary)
                                        StatusBadge(text = treatment.animalTag)
                                    }
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text("Problem: ${treatment.problem}", fontWeight = FontWeight.Medium)
                                    Text("Treatment: ${treatment.treatment}", style = MaterialTheme.typography.bodySmall.copy(color = Color.DarkGray))
                                    if (treatment.followUpDate.isNotBlank()) {
                                        Text("Follow-up: ${treatment.followUpDate}", style = MaterialTheme.typography.bodySmall.copy(color = VetAmberSecondary))
                                    }
                                }
                            }
                        }
                    }
                }
                2 -> {
                    if (ownerAIRecords.isEmpty()) {
                        item {
                            EmptyView(
                                icon = Icons.Default.Biotech,
                                title = "No AI records for this owner"
                            )
                        }
                    } else {
                        items(ownerAIRecords) { ai ->
                            Card(
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(12.dp),
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                            ) {
                                Column(modifier = Modifier.padding(14.dp)) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Text("AI Date: ${ai.aiDate}", fontWeight = FontWeight.Bold)
                                        StatusBadge(text = ai.status, color = Color(0xFF7E22CE), containerColor = Color(0xFFF3E8FF))
                                    }
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text("Animal: ${ai.animalTag} • Breed: ${ai.breed}")
                                    Text("Bull/Semen: ${ai.semenBullInfo}", style = MaterialTheme.typography.bodySmall.copy(color = Color.Gray))
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun AddEditOwnerScreen(
    ownerId: Long? = null,
    viewModel: MainViewModel,
    onNavigateBack: () -> Unit,
    onSaved: (Long) -> Unit
) {
    val owners by viewModel.allOwners.collectAsStateWithLifecycle()
    val existing = owners.find { it.id == ownerId }

    var name by remember { mutableStateOf(existing?.name ?: "") }
    var phone by remember { mutableStateOf(existing?.phone ?: "") }
    var altPhone by remember { mutableStateOf(existing?.altPhone ?: "") }
    var village by remember { mutableStateOf(existing?.village ?: "Amratali") }
    var unionName by remember { mutableStateOf(existing?.unionName ?: "Amratali") }
    var upazila by remember { mutableStateOf(existing?.upazila ?: "Adarsha Sadar") }
    var district by remember { mutableStateOf(existing?.district ?: "Cumilla") }
    var address by remember { mutableStateOf(existing?.address ?: "") }
    var nid by remember { mutableStateOf(existing?.nid ?: "") }
    var notes by remember { mutableStateOf(existing?.notes ?: "") }

    var errorMessage by remember { mutableStateOf<String?>(null) }

    BackHandler { onNavigateBack() }

    Scaffold(
        topBar = {
            AppHeader(
                title = if (existing == null) "Register New Owner" else "Edit Owner",
                showBack = true,
                onBack = onNavigateBack
            )
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .background(MaterialTheme.colorScheme.background),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            if (errorMessage != null) {
                item {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = Color(0xFFFFEBEE)),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Text(
                            text = errorMessage ?: "",
                            color = StatusAlertRed,
                            modifier = Modifier.padding(12.dp),
                            style = MaterialTheme.typography.bodyMedium
                        )
                    }
                }
            }

            item {
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it; errorMessage = null },
                    label = { Text("Owner Name *") },
                    placeholder = { Text("e.g. Abdul Karim") },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("owner_name_input"),
                    singleLine = true
                )
            }

            item {
                OutlinedTextField(
                    value = phone,
                    onValueChange = { phone = it; errorMessage = null },
                    label = { Text("Mobile Number *") },
                    placeholder = { Text("e.g. 01712-345678") },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("owner_phone_input"),
                    singleLine = true
                )
            }

            item {
                OutlinedTextField(
                    value = altPhone,
                    onValueChange = { altPhone = it },
                    label = { Text("Alternative Phone (Optional)") },
                    placeholder = { Text("e.g. 01811-223344") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )
            }

            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    OutlinedTextField(
                        value = village,
                        onValueChange = { village = it },
                        label = { Text("Village / Para") },
                        placeholder = { Text("e.g. Amratali") },
                        modifier = Modifier.weight(1f),
                        singleLine = true
                    )
                    OutlinedTextField(
                        value = unionName,
                        onValueChange = { unionName = it },
                        label = { Text("Union") },
                        placeholder = { Text("e.g. Amratali") },
                        modifier = Modifier.weight(1f),
                        singleLine = true
                    )
                }
            }

            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    OutlinedTextField(
                        value = upazila,
                        onValueChange = { upazila = it },
                        label = { Text("Upazila") },
                        modifier = Modifier.weight(1f),
                        singleLine = true
                    )
                    OutlinedTextField(
                        value = district,
                        onValueChange = { district = it },
                        label = { Text("District") },
                        modifier = Modifier.weight(1f),
                        singleLine = true
                    )
                }
            }

            item {
                OutlinedTextField(
                    value = address,
                    onValueChange = { address = it },
                    label = { Text("Detailed Address / Landmark") },
                    placeholder = { Text("e.g. Near Amratali High School, Ward 3") },
                    modifier = Modifier.fillMaxWidth(),
                    maxLines = 2
                )
            }

            item {
                OutlinedTextField(
                    value = nid,
                    onValueChange = { nid = it },
                    label = { Text("NID / Farmer ID (Optional)") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )
            }

            item {
                OutlinedTextField(
                    value = notes,
                    onValueChange = { notes = it },
                    label = { Text("Notes / Dairy Farm Info") },
                    placeholder = { Text("e.g. Has 4 cows, regular buyer") },
                    modifier = Modifier.fillMaxWidth(),
                    minLines = 2
                )
            }

            item {
                Spacer(modifier = Modifier.height(10.dp))
                Button(
                    onClick = {
                        if (name.isBlank()) {
                            errorMessage = "Please enter the owner's name"
                            return@Button
                        }
                        if (phone.isBlank()) {
                            errorMessage = "Please enter a valid mobile number"
                            return@Button
                        }

                        if (existing != null) {
                            val updated = existing.copy(
                                name = name.trim(),
                                phone = phone.trim(),
                                altPhone = altPhone.trim(),
                                village = village.trim(),
                                unionName = unionName.trim(),
                                upazila = upazila.trim(),
                                district = district.trim(),
                                address = address.trim(),
                                nid = nid.trim(),
                                notes = notes.trim()
                            )
                            viewModel.updateOwner(updated) {
                                onSaved(updated.id)
                            }
                        } else {
                            val newCode = "OWN-${(100..999).random()}"
                            val newOwner = OwnerEntity(
                                ownerCode = newCode,
                                name = name.trim(),
                                phone = phone.trim(),
                                altPhone = altPhone.trim(),
                                village = village.trim(),
                                unionName = unionName.trim(),
                                upazila = upazila.trim(),
                                district = district.trim(),
                                address = address.trim(),
                                nid = nid.trim(),
                                notes = notes.trim(),
                                registrationDate = DateUtils.getTodayIso()
                            )
                            viewModel.addOwner(newOwner) { id ->
                                onSaved(id)
                            }
                        }
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(50.dp)
                        .testTag("save_owner_button"),
                    colors = ButtonDefaults.buttonColors(containerColor = VetGreenPrimary),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Icon(Icons.Default.Save, contentDescription = null)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Save Owner Record", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                }
            }
        }
    }
}

@Composable
fun DetailRow(icon: androidx.compose.ui.graphics.vector.ImageVector, label: String, value: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, contentDescription = null, tint = VetGreenPrimary, modifier = Modifier.size(18.dp))
        Spacer(modifier = Modifier.width(10.dp))
        Column {
            Text(label, style = MaterialTheme.typography.labelSmall.copy(color = Color.Gray))
            Text(value, style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Medium))
        }
    }
}
