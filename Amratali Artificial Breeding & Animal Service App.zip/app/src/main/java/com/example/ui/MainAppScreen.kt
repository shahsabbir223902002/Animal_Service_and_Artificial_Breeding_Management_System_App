package com.example.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ui.components.AppHeader
import com.example.ui.screens.ai.AIDetailScreen
import com.example.ui.screens.ai.AIRecordListScreen
import com.example.ui.screens.ai.AddEditAIRecordScreen
import com.example.ui.screens.animals.AddEditAnimalScreen
import com.example.ui.screens.animals.AnimalDetailScreen
import com.example.ui.screens.animals.AnimalListScreen
import com.example.ui.screens.appointments.AppointmentsScreen
import com.example.ui.screens.auth.LoginScreen
import com.example.ui.screens.dashboard.DashboardScreen
import com.example.ui.screens.owners.AddEditOwnerScreen
import com.example.ui.screens.owners.OwnerDetailScreen
import com.example.ui.screens.owners.OwnerListScreen
import com.example.ui.screens.profile.RabbyProfileScreen
import com.example.ui.screens.reports.ReportsScreen
import com.example.ui.screens.settings.SettingsScreen
import com.example.ui.screens.treatments.AddEditTreatmentScreen
import com.example.ui.screens.treatments.MonthlySummaryScreen
import com.example.ui.screens.treatments.TreatmentDetailScreen
import com.example.ui.screens.treatments.TreatmentHistoryScreen
import com.example.ui.screens.vaccination.VaccinationDewormingScreen
import com.example.ui.theme.*

sealed class Screen {
    object Dashboard : Screen()
    object Owners : Screen()
    data class OwnerDetail(val ownerId: Long) : Screen()
    data class AddEditOwner(val ownerId: Long? = null) : Screen()
    object Animals : Screen()
    data class AnimalDetail(val animalId: Long) : Screen()
    data class AddEditAnimal(val animalId: Long? = null, val preselectedOwnerId: Long? = null) : Screen()
    object Treatments : Screen()
    data class TreatmentDetail(val treatmentId: Long) : Screen()
    data class AddEditTreatment(
        val treatmentId: Long? = null,
        val preselectedOwnerId: Long? = null,
        val preselectedAnimalId: Long? = null
    ) : Screen()
    object MonthlySummary : Screen()
    object AIRecords : Screen()
    data class AIDetail(val aiId: Long) : Screen()
    data class AddEditAI(val aiId: Long? = null, val preselectedAnimalId: Long? = null) : Screen()
    object VaccinationDeworming : Screen()
    object Appointments : Screen()
    object Reports : Screen()
    object RabbyProfile : Screen()
    object Settings : Screen()
    object MoreMenu : Screen()
}

@Composable
fun MainApp(viewModel: MainViewModel) {
    val isLoggedIn by viewModel.isLoggedIn.collectAsStateWithLifecycle()
    val navStack = remember { mutableStateListOf<Screen>(Screen.Dashboard) }
    val currentScreen = navStack.lastOrNull() ?: Screen.Dashboard

    fun navigateTo(screen: Screen) {
        navStack.add(screen)
    }

    fun popBack() {
        if (navStack.size > 1) {
            navStack.removeAt(navStack.size - 1)
        }
    }

    fun switchTab(screen: Screen) {
        navStack.clear()
        navStack.add(screen)
    }

    if (!isLoggedIn) {
        LoginScreen(
            viewModel = viewModel,
            onLoginSuccess = {
                navStack.clear()
                navStack.add(Screen.Dashboard)
            }
        )
        return
    }

    val isRootTab = currentScreen is Screen.Dashboard ||
            currentScreen is Screen.Owners ||
            currentScreen is Screen.Animals ||
            currentScreen is Screen.Treatments ||
            currentScreen is Screen.MoreMenu

    Scaffold(
        bottomBar = {
            if (isRootTab) {
                NavigationBar(
                    containerColor = MaterialTheme.colorScheme.surface,
                    tonalElevation = 6.dp
                ) {
                    NavigationBarItem(
                        selected = currentScreen is Screen.Dashboard,
                        onClick = { switchTab(Screen.Dashboard) },
                        icon = { Icon(Icons.Default.Dashboard, contentDescription = "Dashboard") },
                        label = { Text("Dashboard", fontSize = 11.sp) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = VetGreenPrimary,
                            selectedTextColor = VetGreenPrimary,
                            indicatorColor = VetGreenContainer
                        )
                    )
                    NavigationBarItem(
                        selected = currentScreen is Screen.Owners,
                        onClick = { switchTab(Screen.Owners) },
                        icon = { Icon(Icons.Default.People, contentDescription = "Owners") },
                        label = { Text("Owners", fontSize = 11.sp) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = VetGreenPrimary,
                            selectedTextColor = VetGreenPrimary,
                            indicatorColor = VetGreenContainer
                        )
                    )
                    NavigationBarItem(
                        selected = currentScreen is Screen.Animals,
                        onClick = { switchTab(Screen.Animals) },
                        icon = { Icon(Icons.Default.Pets, contentDescription = "Animals") },
                        label = { Text("Animals", fontSize = 11.sp) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = VetGreenPrimary,
                            selectedTextColor = VetGreenPrimary,
                            indicatorColor = VetGreenContainer
                        )
                    )
                    NavigationBarItem(
                        selected = currentScreen is Screen.Treatments,
                        onClick = { switchTab(Screen.Treatments) },
                        icon = { Icon(Icons.Default.MedicalServices, contentDescription = "Treatments") },
                        label = { Text("Treatments", fontSize = 11.sp) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = VetGreenPrimary,
                            selectedTextColor = VetGreenPrimary,
                            indicatorColor = VetGreenContainer
                        )
                    )
                    NavigationBarItem(
                        selected = currentScreen is Screen.MoreMenu,
                        onClick = { switchTab(Screen.MoreMenu) },
                        icon = { Icon(Icons.Default.Menu, contentDescription = "More") },
                        label = { Text("More", fontSize = 11.sp) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = VetGreenPrimary,
                            selectedTextColor = VetGreenPrimary,
                            indicatorColor = VetGreenContainer
                        )
                    )
                }
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            when (currentScreen) {
                is Screen.Dashboard -> DashboardScreen(
                    viewModel = viewModel,
                    onNavigateToOwners = { switchTab(Screen.Owners) },
                    onNavigateToAnimals = { switchTab(Screen.Animals) },
                    onNavigateToTreatments = { switchTab(Screen.Treatments) },
                    onNavigateToAI = { navigateTo(Screen.AIRecords) },
                    onNavigateToAppointments = { navigateTo(Screen.Appointments) },
                    onNavigateToVaccinations = { navigateTo(Screen.VaccinationDeworming) },
                    onNavigateToDewormings = { navigateTo(Screen.VaccinationDeworming) },
                    onNavigateToMonthlySummary = { navigateTo(Screen.MonthlySummary) },
                    onNavigateToProfile = { navigateTo(Screen.RabbyProfile) },
                    onAddOwner = { navigateTo(Screen.AddEditOwner()) },
                    onAddAnimal = { navigateTo(Screen.AddEditAnimal()) },
                    onAddTreatment = { navigateTo(Screen.AddEditTreatment()) },
                    onAddAI = { navigateTo(Screen.AddEditAI()) },
                    onAddAppointment = { navigateTo(Screen.Appointments) },
                    onTreatmentDetail = { id -> navigateTo(Screen.TreatmentDetail(id)) }
                )

                is Screen.Owners -> OwnerListScreen(
                    viewModel = viewModel,
                    onNavigateBack = { switchTab(Screen.Dashboard) },
                    onOwnerClick = { id -> navigateTo(Screen.OwnerDetail(id)) },
                    onAddOwner = { navigateTo(Screen.AddEditOwner()) },
                    onProfileClick = { navigateTo(Screen.RabbyProfile) }
                )

                is Screen.OwnerDetail -> OwnerDetailScreen(
                    ownerId = currentScreen.ownerId,
                    viewModel = viewModel,
                    onNavigateBack = { popBack() },
                    onEditOwner = { id -> navigateTo(Screen.AddEditOwner(id)) },
                    onAddAnimalForOwner = { id -> navigateTo(Screen.AddEditAnimal(preselectedOwnerId = id)) },
                    onAddVisitForOwner = { id -> navigateTo(Screen.AddEditTreatment(preselectedOwnerId = id)) },
                    onAnimalClick = { id -> navigateTo(Screen.AnimalDetail(id)) },
                    onTreatmentClick = { id -> navigateTo(Screen.TreatmentDetail(id)) }
                )

                is Screen.AddEditOwner -> AddEditOwnerScreen(
                    ownerId = currentScreen.ownerId,
                    viewModel = viewModel,
                    onNavigateBack = { popBack() },
                    onSaved = { _ -> popBack() }
                )

                is Screen.Animals -> AnimalListScreen(
                    viewModel = viewModel,
                    onNavigateBack = { switchTab(Screen.Dashboard) },
                    onAnimalClick = { id -> navigateTo(Screen.AnimalDetail(id)) },
                    onAddAnimal = { navigateTo(Screen.AddEditAnimal()) },
                    onProfileClick = { navigateTo(Screen.RabbyProfile) }
                )

                is Screen.AnimalDetail -> AnimalDetailScreen(
                    animalId = currentScreen.animalId,
                    viewModel = viewModel,
                    onNavigateBack = { popBack() },
                    onEditAnimal = { id -> navigateTo(Screen.AddEditAnimal(animalId = id)) },
                    onOwnerClick = { id -> navigateTo(Screen.OwnerDetail(id)) },
                    onAddTreatment = { aId, oId -> navigateTo(Screen.AddEditTreatment(preselectedAnimalId = aId, preselectedOwnerId = oId)) },
                    onAddAI = { aId -> navigateTo(Screen.AddEditAI(preselectedAnimalId = aId)) },
                    onTreatmentClick = { id -> navigateTo(Screen.TreatmentDetail(id)) }
                )

                is Screen.AddEditAnimal -> AddEditAnimalScreen(
                    animalId = currentScreen.animalId,
                    preselectedOwnerId = currentScreen.preselectedOwnerId,
                    viewModel = viewModel,
                    onNavigateBack = { popBack() },
                    onSaved = { _ -> popBack() }
                )

                is Screen.Treatments -> TreatmentHistoryScreen(
                    viewModel = viewModel,
                    onNavigateBack = { switchTab(Screen.Dashboard) },
                    onTreatmentClick = { id -> navigateTo(Screen.TreatmentDetail(id)) },
                    onAddTreatment = { navigateTo(Screen.AddEditTreatment()) },
                    onMonthlySummaryClick = { navigateTo(Screen.MonthlySummary) },
                    onProfileClick = { navigateTo(Screen.RabbyProfile) }
                )

                is Screen.TreatmentDetail -> TreatmentDetailScreen(
                    treatmentId = currentScreen.treatmentId,
                    viewModel = viewModel,
                    onNavigateBack = { popBack() },
                    onEditTreatment = { id -> navigateTo(Screen.AddEditTreatment(treatmentId = id)) },
                    onOwnerClick = { id -> navigateTo(Screen.OwnerDetail(id)) },
                    onAnimalClick = { id -> navigateTo(Screen.AnimalDetail(id)) }
                )

                is Screen.AddEditTreatment -> AddEditTreatmentScreen(
                    treatmentId = currentScreen.treatmentId,
                    preselectedOwnerId = currentScreen.preselectedOwnerId,
                    preselectedAnimalId = currentScreen.preselectedAnimalId,
                    viewModel = viewModel,
                    onNavigateBack = { popBack() },
                    onSaved = { _ -> popBack() }
                )

                is Screen.MonthlySummary -> MonthlySummaryScreen(
                    viewModel = viewModel,
                    onNavigateBack = { popBack() },
                    onNavigateToHistory = { switchTab(Screen.Treatments) }
                )

                is Screen.AIRecords -> AIRecordListScreen(
                    viewModel = viewModel,
                    onNavigateBack = { popBack() },
                    onAIClick = { id -> navigateTo(Screen.AIDetail(id)) },
                    onAddAI = { navigateTo(Screen.AddEditAI()) },
                    onProfileClick = { navigateTo(Screen.RabbyProfile) }
                )

                is Screen.AIDetail -> AIDetailScreen(
                    aiId = currentScreen.aiId,
                    viewModel = viewModel,
                    onNavigateBack = { popBack() },
                    onEditAI = { id -> navigateTo(Screen.AddEditAI(aiId = id)) },
                    onAnimalClick = { id -> navigateTo(Screen.AnimalDetail(id)) },
                    onOwnerClick = { id -> navigateTo(Screen.OwnerDetail(id)) }
                )

                is Screen.AddEditAI -> AddEditAIRecordScreen(
                    aiId = currentScreen.aiId,
                    preselectedAnimalId = currentScreen.preselectedAnimalId,
                    viewModel = viewModel,
                    onNavigateBack = { popBack() },
                    onSaved = { _ -> popBack() }
                )

                is Screen.VaccinationDeworming -> VaccinationDewormingScreen(
                    viewModel = viewModel,
                    onNavigateBack = { popBack() },
                    onProfileClick = { navigateTo(Screen.RabbyProfile) }
                )

                is Screen.Appointments -> AppointmentsScreen(
                    viewModel = viewModel,
                    onNavigateBack = { popBack() },
                    onProfileClick = { navigateTo(Screen.RabbyProfile) }
                )

                is Screen.Reports -> ReportsScreen(
                    viewModel = viewModel,
                    onNavigateBack = { popBack() },
                    onProfileClick = { navigateTo(Screen.RabbyProfile) }
                )

                is Screen.RabbyProfile -> RabbyProfileScreen(
                    viewModel = viewModel,
                    onNavigateBack = { popBack() }
                )

                is Screen.Settings -> SettingsScreen(
                    viewModel = viewModel,
                    onNavigateBack = { popBack() },
                    onNavigateToProfile = { navigateTo(Screen.RabbyProfile) },
                    onLogout = {
                        navStack.clear()
                    }
                )

                is Screen.MoreMenu -> MoreMenuScreen(
                    viewModel = viewModel,
                    onNavigateBack = { switchTab(Screen.Dashboard) },
                    onOpenAI = { navigateTo(Screen.AIRecords) },
                    onOpenAppointments = { navigateTo(Screen.Appointments) },
                    onOpenVaccines = { navigateTo(Screen.VaccinationDeworming) },
                    onOpenReports = { navigateTo(Screen.Reports) },
                    onOpenMonthlySummary = { navigateTo(Screen.MonthlySummary) },
                    onOpenProfile = { navigateTo(Screen.RabbyProfile) },
                    onOpenSettings = { navigateTo(Screen.Settings) }
                )
            }
        }
    }
}

@Composable
fun MoreMenuScreen(
    viewModel: MainViewModel,
    onNavigateBack: () -> Unit,
    onOpenAI: () -> Unit,
    onOpenAppointments: () -> Unit,
    onOpenVaccines: () -> Unit,
    onOpenReports: () -> Unit,
    onOpenMonthlySummary: () -> Unit,
    onOpenProfile: () -> Unit,
    onOpenSettings: () -> Unit
) {
    val syncState by viewModel.syncState.collectAsStateWithLifecycle()

    BackHandler { onNavigateBack() }

    Scaffold(
        topBar = {
            AppHeader(
                title = "Field Services & Tools",
                subtitle = "Veterinary Management Modules",
                showBack = false,
                syncState = syncState,
                onSyncClick = { viewModel.triggerSync() },
                onProfileClick = onOpenProfile
            )
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .background(MaterialTheme.colorScheme.background),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                Text("Specialized Modules", style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold))
            }

            item {
                MoreMenuCard(
                    title = "Artificial Insemination (AI)",
                    subtitle = "Bull records, heat signs, and auto pregnancy timelines",
                    icon = Icons.Default.Biotech,
                    color = Color(0xFF7E22CE),
                    containerColor = Color(0xFFF3E8FF),
                    onClick = onOpenAI
                )
            }

            item {
                MoreMenuCard(
                    title = "Monthly Treatment Summary",
                    subtitle = "Historical period analytics (This month, 2-3 months ago)",
                    icon = Icons.Default.Analytics,
                    color = VetGreenPrimary,
                    containerColor = VetGreenContainer,
                    onClick = onOpenMonthlySummary
                )
            }

            item {
                MoreMenuCard(
                    title = "Field Appointments",
                    subtitle = "Manage scheduled farmer visits and emergency calls",
                    icon = Icons.Default.Event,
                    color = Color(0xFFC2410C),
                    containerColor = Color(0xFFFFEDD5),
                    onClick = onOpenAppointments
                )
            }

            item {
                MoreMenuCard(
                    title = "Vaccination & Deworming",
                    subtitle = "FMD, Anthrax, PPR schedules, and anthelmintic doses",
                    icon = Icons.Default.Vaccines,
                    color = Color(0xFF047857),
                    containerColor = Color(0xFFD1FAE5),
                    onClick = onOpenVaccines
                )
            }

            item {
                MoreMenuCard(
                    title = "Reports & PDF Export",
                    subtitle = "Download official service reports & performance stats",
                    icon = Icons.Default.PictureAsPdf,
                    color = Color(0xFF0284C7),
                    containerColor = Color(0xFFE0F2FE),
                    onClick = onOpenReports
                )
            }

            item {
                Spacer(modifier = Modifier.height(4.dp))
                Text("Technician & App Info", style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold))
            }

            item {
                MoreMenuCard(
                    title = "About Md. Shah Walimullah Rabby",
                    subtitle = "Government AI Technician Profile, Contacts, Facebook & Map",
                    icon = Icons.Default.Badge,
                    color = VetGreenPrimary,
                    containerColor = VetGreenContainer,
                    onClick = onOpenProfile
                )
            }

            item {
                MoreMenuCard(
                    title = "Settings & Synchronization",
                    subtitle = "Language, PIN change, Cloud sync status",
                    icon = Icons.Default.Settings,
                    color = Color(0xFF4B5563),
                    containerColor = Color(0xFFF3F4F6),
                    onClick = onOpenSettings
                )
            }
        }
    }
}

@Composable
fun MoreMenuCard(
    title: String,
    subtitle: String,
    icon: ImageVector,
    color: Color,
    containerColor: Color,
    onClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() },
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(46.dp)
                    .clip(CircleShape)
                    .background(containerColor),
                contentAlignment = Alignment.Center
            ) {
                Icon(icon, contentDescription = null, tint = color, modifier = Modifier.size(24.dp))
            }
            Spacer(modifier = Modifier.width(14.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(title, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                Text(subtitle, style = MaterialTheme.typography.bodySmall.copy(color = Color.Gray))
            }
            Icon(Icons.Default.ChevronRight, contentDescription = null, tint = Color.Gray)
        }
    }
}
