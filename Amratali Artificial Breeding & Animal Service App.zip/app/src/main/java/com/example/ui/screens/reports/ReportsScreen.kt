package com.example.ui.screens.reports

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ui.MainViewModel
import com.example.ui.components.AppHeader
import com.example.ui.components.MetricStatCard
import com.example.ui.theme.*
import com.example.util.ActionUtils
import com.example.util.DateUtils
import com.example.util.PdfReportGenerator

@Composable
fun ReportsScreen(
    viewModel: MainViewModel,
    onNavigateBack: () -> Unit,
    onProfileClick: () -> Unit
) {
    val context = LocalContext.current
    val syncState by viewModel.syncState.collectAsStateWithLifecycle()
    val allTreatments by viewModel.allTreatments.collectAsStateWithLifecycle()
    val allAIRecords by viewModel.allAIRecords.collectAsStateWithLifecycle()
    val allAnimals by viewModel.allAnimals.collectAsStateWithLifecycle()
    val allOwners by viewModel.allOwners.collectAsStateWithLifecycle()
    val allVaccines by viewModel.allVaccinations.collectAsStateWithLifecycle()
    val allDewormings by viewModel.allDewormings.collectAsStateWithLifecycle()

    var selectedPeriod by remember { mutableStateOf("This Month") }
    val periods = listOf("Today", "This Week", "This Month", "This Year", "All Time")

    val today = DateUtils.getTodayIso()
    val startOfWeek = DateUtils.getStartOfWeek()
    val startOfMonth = DateUtils.getStartOfMonth(0)
    val startOfYear = DateUtils.getStartOfYear()

    val filteredTreatments = remember(selectedPeriod, allTreatments) {
        allTreatments.filter {
            when (selectedPeriod) {
                "Today" -> it.date == today
                "This Week" -> it.date >= startOfWeek && it.date <= today
                "This Month" -> it.date >= startOfMonth && it.date <= today
                "This Year" -> it.date >= startOfYear && it.date <= today
                else -> true
            }
        }
    }

    val totalCows = allAnimals.count { it.species.equals("Cow", ignoreCase = true) }
    val totalGoats = allAnimals.count { it.species.equals("Goat", ignoreCase = true) }
    val totalBuffalos = allAnimals.count { it.species.equals("Buffalo", ignoreCase = true) }
    val totalOthers = allAnimals.size - (totalCows + totalGoats + totalBuffalos)

    val pregnantAICount = allAIRecords.count { it.pregnancyCheckResult == "Pregnant" || it.status == "Pregnant" }

    BackHandler { onNavigateBack() }

    Scaffold(
        topBar = {
            AppHeader(
                title = "Reports & Analytics",
                subtitle = "Official Veterinary Performance",
                showBack = true,
                onBack = onNavigateBack,
                syncState = syncState,
                onSyncClick = { viewModel.triggerSync() },
                onProfileClick = onProfileClick
            )
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .background(MaterialTheme.colorScheme.background),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Period selector
            item {
                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(periods) { p ->
                        FilterChip(
                            selected = selectedPeriod == p,
                            onClick = { selectedPeriod = p },
                            label = { Text(p) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = VetGreenPrimary,
                                selectedLabelColor = Color.White
                            )
                        )
                    }
                }
            }

            // Summary Stats Grid
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    MetricStatCard(
                        title = "Treatments ($selectedPeriod)",
                        count = filteredTreatments.size.toString(),
                        icon = Icons.Default.MedicalServices,
                        containerColor = VetGreenContainer,
                        contentColor = VetGreenPrimary,
                        modifier = Modifier.weight(1f)
                    )
                    MetricStatCard(
                        title = "Total AI Inseminations",
                        count = allAIRecords.size.toString(),
                        icon = Icons.Default.Biotech,
                        containerColor = Color(0xFFF3E8FF),
                        contentColor = Color(0xFF7E22CE),
                        modifier = Modifier.weight(1f)
                    )
                }
            }

            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    MetricStatCard(
                        title = "Confirmed Pregnant",
                        count = pregnantAICount.toString(),
                        icon = Icons.Default.CheckCircle,
                        containerColor = Color(0xFFFEF3C7),
                        contentColor = VetAmberSecondary,
                        modifier = Modifier.weight(1f)
                    )
                    MetricStatCard(
                        title = "Vaccines & Deworming",
                        count = (allVaccines.size + allDewormings.size).toString(),
                        icon = Icons.Default.Vaccines,
                        containerColor = Color(0xFFE0F2FE),
                        contentColor = Color(0xFF0284C7),
                        modifier = Modifier.weight(1f)
                    )
                }
            }

            // Animal Species Distribution (Chart Bar)
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(
                            text = "Livestock Species Distribution",
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                        )
                        Spacer(modifier = Modifier.height(14.dp))

                        val total = if (allAnimals.isNotEmpty()) allAnimals.size else 1
                        ProgressBarItem("Cattle / Cows ($totalCows)", totalCows.toFloat() / total, VetGreenPrimary)
                        ProgressBarItem("Goats ($totalGoats)", totalGoats.toFloat() / total, VetAmberSecondary)
                        ProgressBarItem("Buffaloes ($totalBuffalos)", totalBuffalos.toFloat() / total, Color(0xFF0284C7))
                        if (totalOthers > 0) {
                            ProgressBarItem("Other Animals ($totalOthers)", totalOthers.toFloat() / total, Color.Gray)
                        }
                    }
                }
            }

            // Monthly Trend Chart Card (Section 36)
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(
                            text = "Monthly Treatment Activity (Past 4 Months)",
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                        )
                        Spacer(modifier = Modifier.height(14.dp))

                        for (i in -3..0) {
                            val mName = DateUtils.getMonthName(i)
                            val startM = DateUtils.getStartOfMonth(i)
                            val endM = DateUtils.getEndOfMonth(i)
                            val count = allTreatments.count { it.date in startM..endM }
                            val maxTreatments = 60f
                            ProgressBarItem(
                                label = "$mName - $count Treatments",
                                fraction = (count.toFloat() / maxTreatments).coerceIn(0.05f, 1f),
                                color = if (i == 0) VetGreenPrimary else Color(0xFF4B5563)
                            )
                        }
                    }
                }
            }

            // Export Actions (PDF & CSV)
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(
                            text = "Export Official Records",
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                        )
                        Text(
                            text = "Export comprehensive treatment and AI records as printable PDF or CSV for government reporting.",
                            style = MaterialTheme.typography.bodySmall.copy(color = Color.Gray)
                        )
                        Spacer(modifier = Modifier.height(14.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Button(
                                onClick = {
                                    val pdf = PdfReportGenerator.generateTreatmentReport(
                                        context = context,
                                        treatments = filteredTreatments,
                                        reportTitle = "Official Veterinary & AI Activity Report ($selectedPeriod)",
                                        periodName = selectedPeriod
                                    )
                                    if (pdf != null) PdfReportGenerator.sharePdf(context, pdf)
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = VetGreenPrimary),
                                shape = RoundedCornerShape(10.dp),
                                modifier = Modifier.weight(1f)
                            ) {
                                Icon(Icons.Default.PictureAsPdf, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Export PDF")
                            }

                            OutlinedButton(
                                onClick = {
                                    val csv = PdfReportGenerator.generateCsvReport(filteredTreatments)
                                    ActionUtils.shareText(context, csv, "Share Treatment Records CSV")
                                },
                                shape = RoundedCornerShape(10.dp),
                                modifier = Modifier.weight(1f)
                            ) {
                                Icon(Icons.Default.Share, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Export CSV")
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun ProgressBarItem(label: String, fraction: Float, color: Color) {
    Column(modifier = Modifier.padding(vertical = 4.dp)) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(label, style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.SemiBold))
            Text("${(fraction * 100).toInt()}%", style = MaterialTheme.typography.bodySmall.copy(color = Color.Gray))
        }
        Spacer(modifier = Modifier.height(4.dp))
        LinearProgressIndicator(
            progress = { fraction },
            modifier = Modifier
                .fillMaxWidth()
                .height(8.dp)
                .clip(RoundedCornerShape(4.dp)),
            color = color,
            trackColor = color.copy(alpha = 0.15f)
        )
    }
}
